import pandas as pd
import sys
import datetime
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.ProcessInput import ProcessInput
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.ProcessIn import ProcessIn
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava import CNORunner
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.SeleniumJava import java_generator
#from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumPython.SeleniumPython import \
    #python_generator
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.TextProcessing.ManualTCProcessing import \
    create_timestamp_filename, categorize_line, merge_to_camel_case
#from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.WebCrawlerCraft.WebPageCrawlerCraft import \
    #WebPageCrawlerCraft


def generate(file_content):
    # inter_file_path = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/data/intermediatory_files/data_2023-09-01_02-34-41.csv"
    # df_inter = pd.read_csv(r"C:\Users\COG22K\Downloads\GenAI_MVP_2\GenAI_MVP_2\src\data_2023-10-19_15-19-28.csv")
    df_inter = pd.read_csv(file_content, index_col=False)
    print(df_inter)
    java_generator(df_inter)


arguments = sys.argv
runner_file = arguments[0]
input_file = arguments[1]

if __name__ == '__main__':
    start = datetime.datetime.now()
    pri = ProcessInput()
    next_in = ProcessIn()
    # input_file = "C:/Users/COG22K/Documents/LRAT-6111_TestPlan_v1.xlsx"
    in_df = pd.read_excel(input_file)
    # extracted_entities_csv = pri.Extract_action_entities(in_df)
    extracted_data, out_df = next_in.Extract_action_entities(in_df)
    # print('extracted_entities_csv: ',extracted_entities_csv)
    print('extracted_data : ', extracted_data)
    # Login_bot_partial.txt
    # login_scenario.txt
    # file_path = "C:/Users/SRJSNGFST/Documents/Login_bot_partial.txt"
    # read_inter = "C:/Users/COG22K/Downloads/extraction_data_v2.csv"
    #
    # read_inter = r"C:\Users\COG22K\Downloads\GenAI_MVP_2\action_and_entities12.csv"
    # print('extracted_entities_csv: ', read_inter)
    inter_file = CNORunner.read_and_categorize_file(extracted_data)
    generate(inter_file)
    end = datetime.datetime.now()
    time_taken = end - start
    print('Time Taken : ', time_taken)
