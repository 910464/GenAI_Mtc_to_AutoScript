from langchain.prompts.prompt import PromptTemplate
from langchain import LLMChain
from langchain.chat_models import AzureChatOpenAI
import xml.etree.ElementTree as ET
import pandas as pd


class ScriptCreator:
    def __init__(self):
        self.OPENAI_API_TYPE = "azure"
        self.OPENAI_API_VERSION = "2024-02-15-preview"
        self.OPENAI_API_BASE = "https://cno-openai-dev-eu2-qa-automation.openai.azure.com/"
        self.OPENAI_API_KEY = "f5ee12416c914b92b2b06787f1a3428d"

    def Extract_action_entities(self, sentences, example, multiobject_correlation_example):
        jmeter_script_prompt = """
        I am giving you some example sentences and example of actions and entities extracted and correlated from them
        example sentences: {example}
        entities extracted and correlated from example sentences: {multiobject_correlation_example}
        similar to this I am giving you another set of sentences so make similar table as example for those
        sentences: {sentences}
        Ensure:
            1. correlate the action and entities and one action should be correlated with all related entities to that action
            2. entity column should strictly only contain the actual entity name detected from sentence
            3. Data column should contain the data mentioned in sentence to fill any fields
            4. Do not add any extra action words only take action words extracted from sentences
        """
        complete_prompt_jmeter = PromptTemplate(
            input_variables=["sentences", "example", "multiobject_correlation_example"],
            template=jmeter_script_prompt)
        jmeter_llm = LLMChain(
            llm=AzureChatOpenAI(deployment_name="cno-openai-dev-eu2-qa-automation-35-turbo-16k", model_name="gpt-35-turbo-16k", temperature=0.3,
                                openai_api_key="f5ee12416c914b92b2b06787f1a3428d",
                                openai_api_base="https://cno-openai-dev-eu2-qa-automation.openai.azure.com/",
                                openai_api_version="2024-02-15-preview"),
            prompt=complete_prompt_jmeter)
        output_jmeter_llm = jmeter_llm.run({'sentences': sentences, 'example': example,
                                            'multiobject_correlation_example': multiobject_correlation_example})
        out_path_c = r"action_and_entities.csv"
        with open(out_path_c, "w") as file:
            file.write(output_jmeter_llm)


def read_jmx(jmx_file_path):
    tree = ET.parse(jmx_file_path)
    root = tree.getroot()

    jmx_string = ET.tostring(root, encoding='utf8', method='xml').decode()

    return jmx_string


jm_script = ScriptCreator()

sentences = '''
    "Launch the colonialpenn website https://uat.colonialpenn.com/.",
    "Select GBL product and navigate to GBL quote page.",
    "Enter all mandatory fields in quote page and Click on Get quote page.",
    "Select coverage amount in quote results page and click on Apply now button",
    "Validate your coverage page is not displayed.",
    "Validate user navigates to Additional information page.",
    "Enter  all mandatory fields and click on continue button."
    "Enter all mandatory fields and click on continue button"
    "Validate ADR pop up is displayed."
    "Select NO thanks and validate user navigates to payment page."
    "Verify no ADR amount is added in Payment page header."
    '''

example = '''
"Launch the colonialpenn website."
"Select GBL product and navigate to GBL Getquote page."
"Enter all mandatory fields in Getquote page."
"Note : CA state Zipcode"
"Click on Getquote button and user navigate to Quote results page."
"Enter all mandatory fields and proceed to Your Address page."
"Validate the policy lapse content is displayed as follows",
"Would you like to designate someone to be notified if your insurance policy is in danger of lapsing due to non-payment of premium?."
'''

multiobject_correlation_example = pd.read_excel(r"multiobject_correlation.xlsx")

jm_script.Extract_action_entities(sentences, example, multiobject_correlation_example)

