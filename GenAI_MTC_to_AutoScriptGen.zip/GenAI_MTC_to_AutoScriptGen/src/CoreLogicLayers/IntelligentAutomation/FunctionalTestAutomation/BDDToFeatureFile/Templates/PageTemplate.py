import os

from src.Constants import DBConstants
from src.DAOLayer.MongoReadWrite import mongoReadWrite
from src.EncryptionLayer.Decryption import FileDecryptor

from src.LLMLayer.LLM import LLM


class PageTemplate:

    def generate(self, input_param, data, df):
        # mongo_obj = mongoReadWrite()
        # file_decryptor = FileDecryptor()
        #
        # private_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION, "private_key.pem")
        # encryption_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION,
        #                                                         "encryption_key.bin")
        #
        # template_header = file_decryptor.decrypt_file("../PromptLayer", "APIScriptGeneration.py", private_key,
        #                                               encryption_key)
        #
        # template_header = template_header.decode('utf-8', errors='ignore').split("'''")[1]

        pageClass_script_prompt = '''
                As a test engineer expert, write a java page class of reusable methods required for below feature file's 'step definition class'
                {feature}
                Take the full xpath from below details and make variables and call them in all respective 'By.xpath' methods to find the elements 
                {df}
                Ensure:
                1. Declare package as com.cognizant.pages
                2. Import all necessary things from selenium
                3. Take class name as PageClass
                4. Page class should extent the 'MasterSteps' class and it should be imported from 'com.cognizant.steps.MasterSteps'
                5. Declare a private variable for 'WebDriver' and make a public object method for driver of name same as class name for example:
                    -->>"public pageClassName(WebDriver driver) 
                            this.driver = driver;
                            this.driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(240));
                            PageFactory.initElements(this.driver, this);
                        "
                6. Use 'PageFactory' from selenium while making a public object method for driver
                7. Make all common possible reusable methods for selenium refer below example methods:
                    -->> "@FindBy(how = How.ID, using = "login2")
                        public WebElement logInLink;

                    -->> @FindBy(how = How.XPATH, using = "//a[text()='Cart']")
                        public WebElement cartLink;

                    -->> public void clickOnLoginLink() 
                            logInLink.click();


                    -->> public void clickOnCartLink() 
                            cartLink.click();
                        "
                8. JAVA DOC comment in top of file with content 'Generated with Azure OPENAI'
                9. Return ONLY JAVA code

                '''

        model = LLM()

        output_qa_prompt_page = model.send_request(input_param, pageClass_script_prompt, ["feature", "df"], {'feature': data, 'df': df})

        if not os.path.exists(
                "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft/pages"):
            os.makedirs(
                "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft/pages")

        out_path_c = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft" \
                     "/pages/PageClass.java "

        with open(out_path_c, "w") as file:
            file.write(output_qa_prompt_page)

        print('page class generated')

        return output_qa_prompt_page
