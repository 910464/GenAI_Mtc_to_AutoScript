import os.path

from src.Constants import DBConstants
from src.DAOLayer.MongoReadWrite import mongoReadWrite
from src.EncryptionLayer.Decryption import FileDecryptor
from src.LLMLayer.LLM import LLM


class StepDefTemplate:

    def generate_craft(self, input_param, data, page_class, driver_manager_library, settings, util_library, web_driver_util):

        # mongo_obj = mongoReadWrite()
        # file_decryptor = FileDecryptor()
        #
        # private_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION, "private_key.pem")
        # encryption_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION,
        #                                                         "encryption_key.bin")
        #
        # template_step_definition = file_decryptor.decrypt_file("../PromptLayer", "APIScriptGeneration.py",
        #                                                        private_key,
        #                                                        encryption_key)
        #
        # template_step_definition = template_step_definition.decode('utf-8', errors='ignore').split('"""')[
        # 1].strip()

        template_step_definition = '''
        As a test engineer expert, generate complete Java Selenium Cucumber step definition for this feature file:
        {data}
        Use these reusable methods from these below classes to write the step definition
        {driver_manager_library}
        {settings}
        {util_library}
        {web_driver_util}
        This is the 'Page class' for the Step definition that you have to generate
        {pageClass}
        Ensure:
        1. Declare package as com.cognizant.steps
        2. Take class name as StepDefsCraft
        3. Import all necessary things from selenium and other libraries as needed
        4. Step Definition class should extent the 'MasterSteps' class
        5. Write 'Given,' 'When,' 'Then,' 'And' methods for all scenarios as mentioned in the feature file.
        6. Import the 'Page class' from 'com.cognizant.pages.' path.
        7. Use all reusable methods from page class and use "Page Object Model" design pattern.
        8. Generate full, executable Java code inside the methods.
        9. Ensure that no method is empty.
        10. JAVA DOC comment in top of file with content 'Generated with Azure OPENAI'
        '''

        model = LLM()

        output_qa_prompt_step_defs = model.send_request(input_param, template_step_definition,
                                                        ["data", "pageClass", "driver_manager_library", "settings",
                                                         "util_library", "web_driver_util"],
                                                        {'data': data,
                                                         'pageClass': page_class,
                                                         'driver_manager_library': driver_manager_library,
                                                         'settings': settings,
                                                         'util_library': util_library,
                                                         'web_driver_util': web_driver_util
                                                         })

        if not os.path.exists("../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft/stepdefinitions"):
            os.makedirs("../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft/stepdefinitions")

        out_path_c = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft" \
                     "/stepdefinitions/StepDefsCraft.java "

        with open(out_path_c, "w") as file:
            file.write(output_qa_prompt_step_defs)

        print('Step definition file generated')

    def generate_selenium(self, input_param, data, df):
        template_stepDef = '''
                        As a test engineer expert, generate complete Java Selenium Cucumber step definitions for this feature file:
                        {data}
                        Take the full xpath from below details and make variables and call them in all respective By.xpath methods to find the elements 
                        {df}
                        Ensure:
                        1. Write 'Given,' 'When,' 'Then,' 'And' methods for all scenarios as mentioned in the feature file.
                        2. Use clickElement() method instead of .click() method
                        3. Strictly do not initialize or close the driver or do not set the properties in step definition code
                        4. Generate full, executable Java code inside the methods.
                        5. Ensure that no method is empty.
                        '''

        model = LLM()

        output_qa_prompt_stepDef = model.send_request(input_param, template_stepDef,
                                                      ["data", "df"],
                                                      {'data': data, 'df': df})

        if not os.path.exists("../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium"):
            os.makedirs(
                "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium")

            os.makedirs("../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium/stepdefinitions")

        elif not os.path.exists("../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium/stepdefinitions"):
            os.makedirs(
                "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium/stepdefinitions")

        out_path_c = f"../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile" \
                     f"/selenium/stepdefinitions/StepDefs.java "

        with open(out_path_c, "w") as file:
            file.write(output_qa_prompt_stepDef)

        print('Step definition file generated')
