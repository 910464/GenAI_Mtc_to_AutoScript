/**
 * Generated with Azure OPENAI
 */

package com.cognizant.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

public class PageClass extends MasterSteps {

    private WebDriver driver;

    public PageClass(WebDriver driver) {
        this.driver = driver;
        this.driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(240));
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(how = How.XPATH, using = "html/body/div[1]/header/div/div[5]/div[2]/div/div/a[5]")
    public WebElement mobilesLink;

    @FindBy(how = How.XPATH, using = "html/body/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/ul/li[3]/span/a/span")
    public WebElement mobileAccessoriesLink;

    @FindBy(how = How.XPATH, using = "html/body/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/ul/li[7]/span/a/span")
    public WebElement cablesAndAdaptersLink;

    @FindBy(how = How.XPATH, using = "html/body/div[1]/div[1]/div[2]/div[3]/div[1]/div/div/div/div[1]/div[1]/h2[text()='Highly rated']")
    public WebElement productName;

    public void clickOnMobilesLink() {
        mobilesLink.click();
    }

    public void clickOnMobileAccessoriesLink() {
        mobileAccessoriesLink.click();
    }

    public void clickOnCablesAndAdaptersLink() {
        cablesAndAdaptersLink.click();
    }

    public String getProductNameText() {
        return productName.getText();
    }
}
