/**
 * Generated with Azure OPENAI
 */

package com.cognizant.steps;

import com.cognizant.pages.PageClass;
import com.cucumbercraft.framework.DriverManager;
import com.cucumbercraft.framework.Settings;
import com.cucumbercraft.framework.Util;
import com.cucumbercraft.framework.WebDriverUtil;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class StepDefsCraft extends MasterSteps {

    private WebDriver driver;
    private PageClass page;

    public StepDefsCraft() {
        this.driver = DriverManager.getWebDriver();
        this.page = new PageClass(driver);
    }

    @Given("^I launch the (.*)$")
    public void launchWebsite(String url) {
        driver.get(url);
    }

    @Given("^click on Mobiles it will go to mobiles page$")
    public void clickOnMobiles() {
        page.clickOnMobilesLink();
    }

    @Given("^click on Mobile Accessories on mobiles page$")
    public void clickOnMobileAccessories() {
        page.clickOnMobileAccessoriesLink();
    }

    @When("^click on Cables & Adapters$")
    public void clickOnCablesAndAdapters() {
        page.clickOnCablesAndAdaptersLink();
    }

    @Then("^verify (.*) should come at top$")
    public void verifyProductName(String name) {
        String productName = page.getProductNameText();
        Assert.assertEquals(name, productName);
    }

    @Then("^verify <name> should come at top$")
    public void verifyProductName(Map<String, String> data) {
        String name = data.get("product name");
        String productName = page.getProductNameText();
        Assert.assertEquals(name, productName);
    }
}