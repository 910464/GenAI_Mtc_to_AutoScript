import os
import pandas as pd

from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.BDDToFeatureFile.Templates.PageTemplate import PageTemplate
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.BDDToFeatureFile.Templates.StepDefTemplate import \
    StepDefTemplate
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.TextProcessing.ManualTCProcessing import \
    create_timestamp_filename
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.WebCrawlerCraft.WebPageCrawlerCraft import \
    WebPageCrawlerCraft
from src.CoreLogicLayers.TestPlanning.FormattedTestCaseGeneration.Src.BDDToFormattedTestCase import generate
from src.DAOLayer.ChromaDBConnector import ChromaDBConnector
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.Parsers.parseClassCodeToCsv import \
    ParseClassCodeToCsv


class BDDToFeatureFileGenerator:

    def generate_scripts(self, data, input_param):
        stepDefTemplate = StepDefTemplate()
        pageTemplate = PageTemplate()

        if not os.path.exists(
                "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/intermediatory_files"):
            os.makedirs(
                "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/intermediatory_files")

        inter_file = create_timestamp_filename(
            "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/intermediatory_files",
            ".csv")

        df = generate(data, input_param)

        crawler = WebPageCrawlerCraft('https://www.google.co.in/')

        try:
            crawler.start('chrome', headless=True)
            crawler.crawl(df, inter_file, input_param)
        except:
            crawler.start('chrome', headless=False)
            crawler.crawl(df, inter_file, input_param)

        df_xpath = pd.read_csv(inter_file)

        field_details = "Details of all actions on web element objects with test data and Xpath given below in the " \
                        "form of " \
                        "'Action - Object - Test data - Xpath'. Create one method of each action - object pair." \
                        "Do not create any other methods other than available details.\n"
        for _, row in df_xpath.iterrows():
            field_details += str(row['action']) + " - " + str(row['object']) + " - " + str(row['data']) + " - " + str(
                row['Xpath']) + "\n"

        if input_param['isCRAFT']:

            if input_param['isPageObjectModel']:

                if not os.path.exists(
                        "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/csv_data"):
                    os.makedirs(
                        "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/csv_data")
                    parser = ParseClassCodeToCsv()
                    parser.parse_data(
                        "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/craft/com/cognizant/core",
                        "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/csv_data")

                db = ChromaDBConnector(
                    "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/craft/com/cognizant/core")
                db.vectordb_store_dir(
                    "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/csv_data")

                if input_param['isBDD']:
                    q1 = "Get all methods of Driver Manager class"
                    q2 = "Get all methods of Settings class"
                    q3 = "Get all methods of Util class"
                    q4 = "Get all methods of Web Driver Util class"

                    driver_manager_class = db.retrieval(q1, 5)[0]
                    settings_class = db.retrieval(q2, 5)[0]
                    util_class = db.retrieval(q3, 5)[0]
                    web_driver_util_class = db.retrieval(q4, 5)[0]

                    driver_manager_library = driver_manager_class.page_content.split('Documentation:')[0]
                    settings = settings_class.page_content.split('Documentation:')[0]
                    util_library = util_class.page_content.split('Documentation:')[0]
                    web_driver_util = web_driver_util_class.page_content.split('Documentation:')[0]

                    page_class = pageTemplate.generate(input_param, data, field_details)

                    stepDefTemplate.generate_craft(input_param, data, page_class, driver_manager_library,
                                                   settings, util_library, web_driver_util)

        else:
            if input_param['isBDD']:
                stepDefTemplate.generate_selenium(input_param, data, field_details)
