import os
import shutil
from datetime import datetime

from src.Constants import DBConstants
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.BDDToFeatureFile.main.BDDToFeatureFileToStepDefGenerator import \
    BDDToFeatureFileGenerator

from src.DAOLayer.MongoReadWrite import mongoReadWrite
import time
import pandas as pd

from src.Utilities.FileHandling.FileHandling import create_zip

mongo_obj = mongoReadWrite()


def generate_stepDef_scripts(processing_json):
    start = time.time()
    print(processing_json['jobID'])
    execution_details = {'jobID': processing_json['jobID'], 'description': 'Not decided yet',
                         'useCaseName': processing_json['useCaseName'],
                         'generationOption': str(processing_json), 'input': 1, 'output': 'N/A',
                         'executedOn': datetime.now().strftime("%dth %b, %Y %H:%M:%S"), 'timeTaken': 0,
                         'executedBy': processing_json['executedBy'], 'executionStatus': 'Generating',
                         'projectID': processing_json['projectID']}

    timestamp = execution_details['executedOn'].replace(' ', '').replace(':', '')
    execution_details_df = pd.DataFrame(execution_details, index=[0])
    mongo_obj.write_data('ExecutionSummary', execution_details_df)

    try:
        content = mongo_obj.read_filecontent_from_gridfs(DBConstants.FILES_COLLECTION, processing_json['fileName'])
        BDDToFeatureFileGenerator.generate_scripts(BDDToFeatureFileGenerator, content.decode(), processing_json)

        execution_details['executionStatus'] = 'Completed'
        if processing_json['isCRAFT']:
            folder_path = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft/stepdefinitions"
        else:
            folder_path = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium/stepdefinitions"
        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]

        file_count = len(files)
        execution_details['output'] = file_count
        execution_details['timeTaken'] = (time.time() - start).__round__()
        execution_details_df = pd.DataFrame(execution_details, index=[0])
        mongo_obj.update_data_based_on_jobid('ExecutionSummary', execution_details_df, execution_details['jobID'])

        # if processing_json['isCRAFT']:
        #     shutil.copytree(
        #         "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/data/craft/com",
        #         "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft",
        #         dirs_exist_ok=True)

        if not os.path.exists("../dataupload/"):
            os.makedirs("../dataupload/")

        if processing_json['isCRAFT']:
            create_zip(
                f"../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/cucumbercraft",
                f"../dataupload/{processing_json['fileName']}{timestamp}.zip")
        else:
            create_zip(
                f"../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/BDDToFeatureFile/selenium",
                f"../dataupload/{processing_json['fileName']}{timestamp}.zip")

        mongo_obj.store_zip_in_mongodb(DBConstants.BDD_TO_SETPDEFS_SCRIPTS_COLLECTION,
                                       f"../dataupload/{processing_json['fileName']}{timestamp}.zip",
                                       execution_details['jobID'])

        # Clean up: remove the temporary ZIP file
        os.remove(f"../dataupload/{processing_json['fileName']}{timestamp}.zip")

        return {"message": "Script generated successfully"}

    except Exception as e:
        execution_details['executionStatus'] = 'Failed'
        execution_details['timeTaken'] = (time.time() - start).__round__()
        execution_details_df = pd.DataFrame(execution_details, index=[0])
        mongo_obj.update_data_based_on_jobid('ExecutionSummary', execution_details_df, execution_details['jobID'])
        print(e)
        return {"message": "Script generation failed"}
