import pandas as pd
from src.WebCrawlerCraft.WebPageCrawlerCraft import WebPageCrawlerCraft
import datetime
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.ProcessInput import ProcessInput
import re
from urllib.parse import urlparse

def create_timestamp_filename(extension=".csv"):
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"data_{timestamp}{extension}"
    return filename


def remove_prefix(text, prefix):
    if text.startswith(prefix):
        return text[len(prefix):].strip()
    return text.strip()


def categorize_line(line):
    action = ""
    obj = ""
    test_data = ""

    start_obj = line.find('[')
    end_obj = line.find(']')
    start_test_data = line.rfind('(')
    end_test_data = line.rfind(')')

    if line.strip().endswith(':'):
        return action, obj, test_data

    if start_obj != -1 and end_obj != -1:
        action = line[:start_obj].strip()
        obj = line[start_obj + 1:end_obj].strip()

    if start_test_data != -1 and end_test_data != -1:
        if not action:
            action = line[:start_test_data].strip()
        test_data = line[start_test_data + 1:end_test_data].strip()
        if test_data.startswith("enter data:"):
            test_data = test_data[len("enter data:"):].strip()

    test_data = remove_prefix(test_data, "enter data:")
    test_data = remove_prefix(test_data, "stage Link:")

    if action.count(' ') > 0 and not action.startswith('Navigate'):
        test_data = obj
        action, obj = action.split(' ', 1)

    return action, obj, test_data


def merge_to_camel_case(line):
    words = line.strip().split()
    camel_case = words[0].capitalize() + ''.join(word.capitalize() for word in words[1:])
    return camel_case


def read_and_categorize_file(file_path):
    data_src = pd.read_csv(file_path, index_col=False)
    print(data_src)
    data_src['page'] = 'landing_page'
    print(data_src)
    inter_file = create_timestamp_filename()
    data = {'PageClass': [], 'Action': [], 'Object': [], 'Test Data': []}
    # Action, Object, Data, Conditions, Condition Value, page
    # df = pd.DataFrame(data)
    crawler = WebPageCrawlerCraft('https://qualityinsights.cognizant.com/qualityinsightbots/#/',
                                  r'C:/Users/SRJSNGFST/Documents/login_scenario.txt')
    crawler.start('chrome', True)
    crawler.crawl(data_src, inter_file)
    # print(df)
    # inter_file_path = inter_file
    # inter_file_path = "C:/Users/SRJSNGFST/Desktop/ScriptGenAi/AIScriptGeneratorMVP/src/data_2023-07-21_13-45-00.csv"
    # df_inter = pd.read_csv(file_path, index_col=False)
    # print(df_inter)
    # each group by will be individual page class
    # generate prompt for each group for Component, Page and Script Class
    # page_wise = df_inter.groupby("page", sort=False)
    component_class_data = []
    # for page_name, page_data in page_wise:
    #     print(f"Processing Group '{page_name}':")
    #     print(page_data)
    #     component_class = CraftAsureConnect.code_generation(CraftAsureConnect, page_name, page_data)
    #     component_class_data.append(component_class)
    # CraftAsureConnect.code_generation_test_script(CraftAsureConnect, 'Runner', component_class_data)
    return inter_file


# if __name__ == "__main__":
#     pri = ProcessInput()
#     input_file_manual_testcase = "C:/Users/COG22K/Documents/LRAT-6111_TestPlan_v1.xlsx"
#     in_df = pd.read_excel(input_file_manual_testcase)
#     extracted_entities_csv = pri.Extract_action_entities(in_df)
#     # Login_bot_partial.txt
#     # login_scenario.txt
#     # file_path = "C:/Users/SRJSNGFST/Documents/Login_bot_partial.txt"
#     read_inter = "C:/Users/COG22K/Downloads/extraction_data_v2.csv"
#
#     inter_file = read_and_categorize_file(read_inter)
