#from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.ReusabilityUtils.RetrievalLayer import \
#    retrieve_exist_code
from src.Utilities.FileHandling.FileHandling import write_code_to_file
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.LLMs.AzureOpenAI import AzureOpenAI
#from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.Parsers.parseMethodToCsv import ParseMethodToCsv
from src.DAOLayer.ChromaDBConnector import ChromaDBConnector
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.Templates.PageClassTemplate import PageClassTemplate
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.Templates.ComponentClassTemplate import ComponentClassTemplate
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.Templates.TestScriptTemplate import TestScriptTemplate
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.ReusabilityUtils.MergeSameClassCode import MergeSameClassCode


class NexusAsureConnect:

    def __init__(self):
        build_llm = AzureOpenAI()
        self.llm = build_llm.load_openai_model()
        self.extn = "java"
        self.seleJavaPath = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava"

    def page_comp_code_generation(self, page_name, page_data):

        pg_generator = PageClassTemplate(self.llm)
        comp_generator = ComponentClassTemplate(self.llm)


        # db = ChromaDBConnector(f"{self.seleJavaPath}/data/embed_data_gen/csv")
        # parser = ParseMethodToCsv()
        #
        # db2 = ChromaDBConnector(f"{self.seleJavaPath}/data/embed_data_gen/code")

        # page_content = ""
        # exist_page_name = set()
        # non_exist_methods = pd.DataFrame()

        # for _, row in page_data.iterrows():
        #     method_content = ""
        #     if row['action'] == "Select" and not pd.isna(row['data']):
        #         method_content = db.retrieval(f"Get method details for '{row['action']} {row['object']} {row['data']}' inside class {row['page']}", 3)
        #     else:
        #         method_content = db.retrieval(f"Get method details for '{row['action']} {row['object']}' inside class {row['page']}", 3)
        #     validation_text = ""
        #     if pd.isna(row['object']):
        #         validation_text = f"{str(row['action']).lower().replace(' ', '')}"
        #     else:
        #         validation_text = f"{str(row['action']).lower().replace(' ', '')}{str(row['object']).lower().replace(' ', '')}"
        #     for i in range(len(method_content)):
        #         if validation_text in method_content[i].page_content.lower():
        #             page_content += method_content[i].page_content
        #
        #             pattern = r'Class:\s*(\w+)'
        #             match = re.search(pattern, page_content)
        #             if match:
        #                 exist_page_name.add(match.group(1))
        #             break
        #     else:
        #         non_exist_methods = non_exist_methods.append(row, ignore_index=True)

        # non_exist_methods, exist_page_code = retrieve_exist_code(page_name, page_data)
        #
        # print(non_exist_methods)
        # print(exist_page_code)
        # # print(page_content)
        # # print(exist_page_name)
        #
        # # exist_page_code = ""
        # exist_comp_code = ""
        # # if len(exist_page_name) == 1:
        # #     exist_page_code = validate_word_in_content(db2.retrieval(f"Get Page Class code for {list(exist_page_name)[0]} where locators and method defined for action on page elements", 3),
        # #                                                "package pages").page_content
        # #     print(exist_page_code)
        # #     exist_comp_code = validate_word_in_content(db2.retrieval(f"Get Component Class code for {list(exist_page_name)[0].replace('Page','Component')} where validation method defined and calling methods from page class", 3),
        # #                                                "package businesscomponents").page_content
        # if exist_page_code != "":
        #     # exist_comp_code = validate_source_in_content(db2.retrieval(f"Get Component Class code for {exist_page_name.replace('Page','Component')} where validation method defined and calling methods from page class", 3),
        #     #                                            exist_page_name.replace('Page', 'Component')).page_content
        #     exist_comp_code = db2.get_doc_by_id(page_name+'Component')['documents'][0]
        #     print(exist_comp_code)
        #
        # if len(non_exist_methods) == 0:
        #     print("All methods are presented")
        #     return exist_comp_code

        # elif len(non_exist_methods) == len(page_data):
        pg_code = pg_generator.generate(page_name, page_data)
        write_code_to_file(pg_code, r"Output/", r"pages/",
                           page_name + f"Page.{self.extn}")
        # parser.parse_data(f"{self.seleJavaPath}/{input_param['language']}Output/pages",
        #                   f"{self.seleJavaPath}/data/gen_code_csv/pages")
        # db.vectordb_store_doc(f"{self.seleJavaPath}/data/gen_code_csv/pages/{page_name}Page.csv")
        # db2.vectordb_store_code(pg_code, page_name+"Page")

        comp_code = comp_generator.generate(page_name, page_data, pg_code)
        write_code_to_file(comp_code, r"Output/", r"components/",
                           page_name + f"Component.{self.extn}")
        # parser.parse_data(f"{self.seleJavaPath}/{input_param['language']}Output/businesscomponents",
        #                   f"{self.seleJavaPath}/data/gen_code_csv/businesscomponents")
        # db.vectordb_store_doc(f"{self.seleJavaPath}/data/gen_code_csv/businesscomponents/{page_name}Component.csv")
        # db2.vectordb_store_code(comp_code, page_name+"Component")
        return comp_code
        #return ""

        # else:
        #     merger = MergeSameClassCode()
        #
        #     pg_code = pg_generator.generate(page_name, non_exist_methods)
        #     merged_code = merger.merge_java_code(exist_page_code, pg_code)
        #     write_code_to_file(merged_code, f"{self.seleJavaPath}/", f"{input_param['language']}Output/pages/",
        #                        page_name + f"Page.{self.extn}")
        #     parser.parse_data(f"{self.seleJavaPath}/{input_param['language']}Output/pages",
        #                       f"{self.seleJavaPath}/data/gen_code_csv/pages")
        #     db.vectordb_store_doc(f"{self.seleJavaPath}/data/gen_code_csv/pages/{page_name}Page.csv")
        #     db2.vectordb_store_code(merged_code, page_name+"Page")
        #
        #     comp_code = comp_generator.generate(page_name, non_exist_methods, pg_code)
        #     merged_code = merger.merge_java_code(exist_comp_code, comp_code)
        #     write_code_to_file(merged_code, f"{self.seleJavaPath}/",
        #                        f"{input_param['language']}Output/businesscomponents/",
        #                        page_name + f"Component.{self.extn}")
        #     parser.parse_data(f"{self.seleJavaPath}/{input_param['language']}Output/businesscomponents",
        #                       f"{self.seleJavaPath}/data/gen_code_csv/businesscomponents")
        #     db.vectordb_store_doc(f"{self.seleJavaPath}/data/gen_code_csv/businesscomponents/{page_name}Component.csv")
        #     db2.vectordb_store_code(merged_code, page_name+"Component")
        #     return merged_code

    def test_script_code_generation(self, page_name, comp_classes, comp_code):

        script_generator = TestScriptTemplate(self.llm)
        # db = ChromaDBConnector(f"{self.seleJavaPath}/data/embed_data_gen/code")

        # component_methods = ""
        # for comp in comp_classes:
        #     component_methods += db.retrieval(f"Get {comp}Component class code", 3)[0].page_content + "\n\n"
        component_methods = comp_code

        tc_script_code = script_generator.generate(page_name, component_methods, comp_classes)
        write_code_to_file(tc_script_code, r"Output", r"testscripts",
                           page_name + f"TestScript.{self.extn}")
