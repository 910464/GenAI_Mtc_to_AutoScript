from langchain.prompts.prompt import PromptTemplate
from langchain import LLMChain
from langchain.chat_models import AzureChatOpenAI
import xml.etree.ElementTree as ET
import pandas as pd
import datetime


class ProcessIn:
    def __init__(self):
        self.OPENAI_API_TYPE = "azure"
        self.OPENAI_API_VERSION = "2024-02-15-preview"
        self.OPENAI_API_BASE = "https://cno-openai-dev-eu2-qa-automation.openai.azure.com/"
        self.OPENAI_API_KEY = "f5ee12416c914b92b2b06787f1a3428d"

    def create_timestamp_filename(self, data='data', extension=".csv"):
        now = datetime.datetime.now()
        timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"{data}_{timestamp}{extension}"
        return filename

    def Extract_action_entities(self, in_df):
        print(in_df)
        # sentences = in_df['Description (Design Steps)'].str.cat(sep='\n')
        for i in range(0, len(in_df['Description (Design Steps)']), 5):
            print(in_df['Description (Design Steps)'][i:i + 5])

        sentences_rem_n = in_df['Description (Design Steps)'].str.replace('\n', '')
        sentences = sentences_rem_n.str.cat(sep='\n')
        print('sentences:\n', sentences)
        # sentences = '''
        #     "Launch the colonialpenn website https://uat.colonialpenn.com/.",
        #     "Select GBL product and navigate to GBL quote page.",
        #     "Enter all mandatory fields in Getquote page."
        #     '''
        multiobject_correlation_example = pd.read_csv(
            r"C:\Users\COGUD4\Desktop\CNO_ScriptGen\CNO_ScriptGen\multiobject_correlation_updated.csv")
        example = '''
            "Navigate to extc website https://extc-uat-dtge.com/",
            "Click on Outage Menu from secondary navigation bar",
            "Click on 'REPORT A STREETLIGHT OUTAGE' from Electric Outage section",
            "Click on 'VISIT STREETLIGHT OUTAGE REPORTING' link from Submit an online report section.",
            "Check whether the below details are getting displayed to the user on 'Report multiple streetlight outages' page.",
            "Check for the mandatory fields are displayed with Astrik suffixed (*) and try to enter information incorrect or partially filled, check for the error message.",
            "Validate the policy lapse content is displayed as follows, Would you like to designate someone to be notified if your insurance policy is in danger of lapsing due to non-payment of premium?."
            "Enter all the information in 'Report multiple streetlight outages' page and click on submit button."
        '''
        cno_script_prompt = """
        Using the input line provided: '{sentences}', follow the instructions below to identify and extract the following components:
        1. **Action:** Identify the verb or action word that indicates the primary operation. 
        This is strictly single word phrase only. This is what the statement is trying to achieve.
        2. **Object:** Determine the main subject or object of the action. 
        This represents the primary focus of the statement. i.e. phrase on which Action supposed to execute.
        3. **Condition:** Find the phrase or words that indicate the state or circumstance under which the action occurs. 
        Look for conditions such as 'is displayed,' 'navigates to,' or 'in' followed by page name, 
        multiple conditional phrases can be found in single statement. Ensure that condition phrases are listed below 'Condition' column.
        4. **Condition_Value:** Extract the specific information or content associated with the identified Condition. 
        This represents the detailed context or criteria, for e.g. in statement 'Verify that header content is displayed in a XY Page as below: minimum duration added' the condition is 'is displayed in a XY Page' and condition value is 'minimum duration added'. Ensure that condition_value phrases are listed below 'Condition_' column.
        5. **Data*:** So these statements are basically steps in manual test case to execute on web application, so in that context, any value which is available in statement can be used to fill/update in web page can be extracted as Data.
        Please provide your findings for each component based on the given instructions.
        Make sure you return entire extracted data with comma separated format only and not the truncated dotted format response.
        Maintain the CSV table sequence as below:
        Action,Object,Data,Condition,Condition_Value.
        Strictly put relevant data under extracted columns and keep empty entry in case extracted info is not available.
        """
        complete_prompt_cno = PromptTemplate(
            input_variables=["sentences"],
            template=cno_script_prompt)
        cno_llm = LLMChain(
            llm=AzureChatOpenAI(deployment_name="cno-openai-dev-eu2-qa-automation-35-turbo-16k", model_name="gpt-35-turbo-16k",
                                temperature=0,
                                openai_api_key="f5ee12416c914b92b2b06787f1a3428d",
                                openai_api_base="https://cno-openai-dev-eu2-qa-automation.openai.azure.com/",
                                openai_api_version="2024-02-15-preview"),
            prompt=complete_prompt_cno)
        output_cno_llm = cno_llm.run({'sentences': sentences})

        validation_check = """
        This is the input :'{sentences}'
        LLM gave this response when asked to extract Action, Object, Data, Condition, Condition_Value :'{output_cno_llm}'
        I want you to validate this output given by LLM and do any corrections if needed and return CSV data in same format.
        To validate you can refer below guidelines:
        1. Action: This should have only one keyword extracted from sentence.
        2. Object: This is Noun Phrase in sentence
        3. Data: This represents test data to enter in web application in that step
        4. Condition: This is represents condition mentioned in step. for e.g. is displayed is condition
        5. Condition_Value: This is value of condition to check for e.g. is displayed is condition followed by any reference is condition_value'"""

        validate_prompt = PromptTemplate(
            input_variables=["sentences", "output_cno_llm"],
            template=validation_check)
        cno_llm_validate = LLMChain(
            llm=AzureChatOpenAI(deployment_name="cno-openai-dev-eu2-qa-automation-35-turbo-16k", model_name="gpt-35-turbo-16k",
                                temperature=0,
                                openai_api_key="f5ee12416c914b92b2b06787f1a3428d",
                                openai_api_base="https://cno-openai-dev-eu2-qa-automation.openai.azure.com/",
                                openai_api_version="2024-02-15-preview"),
            prompt=validate_prompt)
        validation_res = cno_llm_validate.run({'sentences': sentences, 'output_cno_llm': output_cno_llm})
        print('extracted data: \n', output_cno_llm)
        print('validation_res: \n', validation_res)

        inter_file = self.create_timestamp_filename('action_and_entities')
        out_path_c = inter_file
        with open(out_path_c, "w") as file:
            file.write(output_cno_llm)
        return out_path_c, output_cno_llm


def read_jmx(jmx_file_path):
    tree = ET.parse(jmx_file_path)
    root = tree.getroot()

    jmx_string = ET.tostring(root, encoding='utf8', method='xml').decode()

    return jmx_string


jm_script = ProcessIn()
