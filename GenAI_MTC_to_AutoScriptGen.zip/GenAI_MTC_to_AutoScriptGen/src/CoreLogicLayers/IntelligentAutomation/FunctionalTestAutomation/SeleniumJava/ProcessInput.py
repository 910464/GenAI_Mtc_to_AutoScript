from langchain.prompts.prompt import PromptTemplate
from langchain import LLMChain
from langchain.chat_models import AzureChatOpenAI
import xml.etree.ElementTree as ET
import pandas as pd
import datetime


class ProcessInput:
    def __init__(self):
        self.OPENAI_API_TYPE = "azure"
        self.OPENAI_API_VERSION = "2024-02-15-preview"
        self.OPENAI_API_BASE = "https://cno-openai-dev-eu2-qa-automation.openai.azure.com/"
        self.OPENAI_API_KEY = "f5ee12416c914b92b2b06787f1a3428d"

    def create_timestamp_filename(self,data = 'data', extension=".csv"):
        now = datetime.datetime.now()
        timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"{data}_{timestamp}{extension}"
        return filename

    def Extract_action_entities(self, in_df):
        print(in_df)
        # sentences = in_df['Description (Design Steps)'].str.cat(sep='\n')
        for i in range(0, len(in_df['Description (Design Steps)']), 5):
            print(in_df['Description (Design Steps)'][i:i + 5])

        sentences_rem_n = in_df['Description (Design Steps)'].str.replace('\n', '')
        sentences = sentences_rem_n.str.cat(sep='\n')
        print('sentences:\n', sentences)
        # sentences = '''
        #     "Launch the colonialpenn website https://uat.colonialpenn.com/.",
        #     "Select GBL product and navigate to GBL quote page.",
        #     "Enter all mandatory fields in Getquote page."
        #     '''
        multiobject_correlation_example = pd.read_csv(
            r"C:\Users\COGUD4\Desktop\CNO_ScriptGen\CNO_ScriptGen\multiobject_correlation_updated.csv")
        example = '''
            "Navigate to extc website https://extc-uat-dtge.com/",
            "Click on Outage Menu from secondary navigation bar",
            "Click on 'REPORT A STREETLIGHT OUTAGE' from Electric Outage section",
            "Click on 'VISIT STREETLIGHT OUTAGE REPORTING' link from Submit an online report section.",
            "Check whether the below details are getting displayed to the user on 'Report multiple streetlight outages' page.",
            "Check for the mandatory fields are displayed with Astrik suffixed (*) and try to enter information incorrect or partially filled, check for the error message.",
            "Validate the policy lapse content is displayed as follows, Would you like to designate someone to be notified if your insurance policy is in danger of lapsing due to non-payment of premium?."
            "Enter all the information in 'Report multiple streetlight outages' page and click on submit button."
        '''
        cno_script_prompt = """
        First I am setting the context - the input which is given below consist of specific structure, and the structure is as follows:
        Action, Entity, Data, Condition, Conditional Value
        Now the goal is to extract above fields from each statement/line, in order to do that I am giving you some guidelines as below.
        Make sure you follow the guideline and ensure that each statement/line should have Action and Entity in it. 
        I am giving you some example sentences and example of actions and entities extracted and correlated from them
        example: {example}
        entities extracted and correlated from example: {multiobject_correlation_example}
        similar to this I am giving you set of sentences so make similar CSV table 
        sentences: {sentences}
        I need to store returned data directly in csv file, 
        so strictly return only comma separated data only.
        Maintain the CSV table sequence as below:
        Action,Object,Data,Condition,Condition_value
        Ensure:
            1. correlate the action and entities and one action should be correlated with all related entities to that action
            2. entity column should strictly only contain the actual entity name detected from sentence
            3. Data column should contain the data mentioned in sentence to fill any fields.
            4. Do not add any extra action words only take action words extracted from sentences example Note is not an action value it should be extracted as data.
            5. In the Condition column, if there is any condition mentioned (e.g., "is displayed" for actions like "validate" or "check"), write it in the condition column. Additionally, if there are any entities asked to validate or display, write those entities in the Condition Values column. If there are no entities mentioned, write "NA" in the Condition Values column.
            6. If a condition is mentioned such as validate or check and it has any entities associated with it, extract those entities and place them in the conditional value column. If there are no associated entities, write "NA" in the conditional value column.
            7. Ensure conditional value and condition should be in the same line for that action.
            8. Ensure that you did not include the example sentences extracted in the output csv file.
            9. for each statement/line there should be one output row unless multiple statements/lines are there in input.
        Make sure you return entire extracted data with comma separated format only and not the truncated dotted format response.
        """
        complete_prompt_cno = PromptTemplate(
            input_variables=["sentences", "example", "multiobject_correlation_example"],
            template=cno_script_prompt)
        cno_llm = LLMChain(
            llm=AzureChatOpenAI(deployment_name="cno-openai-dev-eu2-qa-automation-35-turbo-16k", model_name="gpt-35-turbo-16k",
                                temperature=0.1,
                                openai_api_key="f5ee12416c914b92b2b06787f1a3428d",
                                openai_api_base="https://cno-openai-dev-eu2-qa-automation.openai.azure.com/",
                                openai_api_version="2024-02-15-preview"),
            prompt=complete_prompt_cno)
        output_cno_llm = cno_llm.run({'sentences': sentences, 'example': example,
                                      'multiobject_correlation_example': multiobject_correlation_example})
        inter_file = self.create_timestamp_filename('action_and_entities')
        out_path_c = inter_file
        print(output_cno_llm)
        with open(out_path_c, "w") as file:
            file.write(output_cno_llm)
        return out_path_c


def read_jmx(jmx_file_path):
    tree = ET.parse(jmx_file_path)
    root = tree.getroot()

    jmx_string = ET.tostring(root, encoding='utf8', method='xml').decode()

    return jmx_string


jm_script = ProcessInput()
