from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SeleniumJava.NexusAzureConnect import NexusAsureConnect
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.Utils.Parsers.parseClassCodeToCsv import \
    ParseClassCodeToCsv
from src.DAOLayer.ChromaDBConnector import ChromaDBConnector

seleJavaPath = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava"

def java_generator(df_inter):
    if True:

        # parser = ParseClassCodeToCsv()

        # parser.parse_data(r"C:\Users\COGUD4\Downloads\CP_COM_NEXUS\CP_COM_NEXUS\QA-TestNG-Framework\src\main\java\com\cnoinc\qa\accelerators",
        #               r"C:\Users\COGUD4\PycharmProjects\CNOScriptGen\src\CoreLogicLayers\IntelligentAutomation\FunctionalTestAutomation\SeleniumJava\data\csv_data")
        # parser.parse_data(
        #     r"C:\Users\COGUD4\Downloads\CP_COM_DEV\CP_COM_DEV\DotComWebsites-CPL-QE\src\test\java\testScripts",
        #     r"C:\Users\COGUD4\PycharmProjects\CNOScriptGen\src\CoreLogicLayers\IntelligentAutomation\FunctionalTestAutomation\SeleniumJava\data\csv_data")
        # parser.parse_data(
        #     f"{seleJavaPath}/data/craft/com/cognizant/framework",
        #     f"{seleJavaPath}/data/csv_data")
        # parser.parse_data(
        #     f"{seleJavaPath}/data/craft/com/cognizant/framework/selenium",
        #     f"{seleJavaPath}/data/csv_data")
        db = ChromaDBConnector(r"C:\Users\COGUD4\Desktop\CNO_ScriptGen\CNO_ScriptGen\src\CoreLogicLayers\IntelligentAutomation\FunctionalTestAutomation\SeleniumJava\data\embed_data_core")
        db.vectordb_store_dir(r"C:\Users\COGUD4\Desktop\CNO_ScriptGen\CNO_ScriptGen\src\CoreLogicLayers\IntelligentAutomation\FunctionalTestAutomation\SeleniumJava\data\csv_data")

        page_wise = df_inter.groupby("page", sort=False)
        comp_code = ""
        component_classes = []
        connector = NexusAsureConnect()
        for page_name, page_data in page_wise:
            print(f"Processing Group '{page_name}':")
            print(page_data)
            NexusAsureConnect()
            comp_code += connector.page_comp_code_generation(page_name, page_data)
            comp_code += "\n\n\n\n"
            component_classes.append(page_name)
        connector.test_script_code_generation('Runner', component_classes, comp_code)
