/**
 * Package containing reusable libraries which are specific on Selenium
 *
 * @author HCL
 */
package com.cnoinc.qa.accelerators;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * accelerator package contains framework specific Java classes
 *
 * @author Test Engineer
 */

import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cnoinc.qa.support.ReportEvent;
import com.cnoinc.qa.support.StatusReport;

/**
 * This class contains actions that a performed against the page/DOM
 */
public class ActionEngine extends ActionLibrary {
	private static final Logger LOGGER = LogManager.getLogger(ActionEngine.class.getName());
	public static final int NUMBER_OF_CYCLES = 30;

	/**
	 * Switch to an Alert/Pop-up and click on the Yes/Ok button.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and/or
	 *                      enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the alert was selected and clicked on, false if an error
	 *         occurred.
	 */
	public static boolean acceptAlertOrPopUp(String passedComment, String failedComment) {
		boolean b = acceptAlertOrPopUp();
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Click on the element specified and log the appropriate passed or failed
	 * comment in the report.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object referencing the element which should receive
	 *                      the click.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the click was successful.
	 * @param failedComment comment to log if the click was not successful.
	 *
	 * @return true if the click was successful, otherwise false.
	 */
	public static boolean click(By locator, String passedComment, String failedComment) {
		boolean b = click(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Retrieve the text from the element and verify it matches the expected value.
	 * (case-sensitive)
	 *
	 * @param driver
	 *
	 * @DataType :WebDriver Selenium WebDriver controlling the browser.
	 *
	 * @param locator
	 *
	 * @DataType :By By object describing the element whose text should be
	 *           retrieved.
	 *
	 * @param expected
	 *
	 * @DataType :String the value expected to be present in the element.
	 *           (case-sensitive)
	 *
	 * @param testcase
	 *
	 * @DataType :String name of the test case being executed.
	 *
	 * @param passedComment
	 *
	 * @DataType :String comment to log if the comparison was successful.
	 *
	 * @param failedComment
	 *
	 * @DataType :String comment to log if the comparison was not successful.
	 *
	 * @return true if the text matches, false on error or mismatch. {@link String }
	 */
	public static boolean compareText(By locator, String expected, String passedComment, String failedComment) {
		boolean b = compareText(locator, expected);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Switch to an Alert/Pop-up and click on the No/Cancel button.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and/or
	 *                      enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the alert was selected and clicked on, false if an error
	 *         occurred.
	 */
	public static boolean dismissAlertOrPopUp(String passedComment, String failedComment) {
		boolean b = dismissAlertOrPopUp();
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Click twice on an element.
	 *
	 * @param driver  Selenium WebDriver controlling the browser.
	 * @param locator WebElement to receive the click.
	 *
	 * @return true if the element was clicked, false otherwise.
	 */
	protected static boolean doubleClick(By locator) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				Actions action = new Actions(objdriver.getDriver());
				WebElement ele = objdriver.getDriver().findElement(locator);
				action.doubleClick(ele).build().perform();
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to double-click on element.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Click twice on an element.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element to receive the click.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the double click was
	 *                      successful.
	 * @param failedComment comment to log in the report if the double click was not
	 *                      successful.
	 *
	 * @return true if the double click was successful, false otherwise.
	 */
	public static boolean doubleClick(By locator, String passedComment, String failedComment) {
		boolean b = doubleClick(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Click and the source element, drag it to the destination element, and release
	 * the element.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param srcLocator    WebElement to grab.
	 * @param dstLocator    WebElement to drop the specified element upon.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the drag and drop was
	 *                      successful.
	 * @param failedComment comment to log in the report if the drag and drop was
	 *                      not successful.
	 *
	 * @return true if the drag and drop was successful, false otherwise.
	 */
	public static boolean dragAndDrop(By srcLocator, By dstLocator, String passedComment, String failedComment) {
		boolean b = dragAndDrop(srcLocator, dstLocator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Wait for an element to appear in the DOM
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element to wait for DOM
	 *                      presence.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element appearance was successful.
	 * @param failedComment comment to log if the element appearance was not
	 *                      successful.
	 *
	 * @return true if the element is found within the timeout period, false
	 *         otherwise.
	 */
	public static boolean explicitWaitForElementToAppear(By locator, String passedComment, String failedComment) {
		boolean b = explicitWaitForElementToAppear(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	public static String getResponse(String appID, String safeID, String objectID, String returnValueType) {
		String output = null;
		try {

			String cyberArkURL = "https://aam.cnoinc.com/AIMWebService/api/Accounts?AppID=" + appID + "&Safe=" + safeID
					+ "&Object=" + encodePath(objectID);

			URL url = new URL(cyberArkURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				report.updateTestLogWithNoSS("Cyber Ark response", "Failed HTTP error code " + conn.getResponseCode(),
						StatusReport.FAIL);
				throw new UserdefinedException("Cyber Ark response -Failed HTTP error " + returnValueType);
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			StringBuilder response = new StringBuilder();
			while ((output = br.readLine()) != null) {
				response.append(output);
			}
			br.close();
			JSONObject myresponse = new JSONObject(response.toString());

			output = myresponse.getString(returnValueType);
			if (output == null) {
				report.updateTestLogWithNoSS("Unable to found CyberArk Object based on ", returnValueType, StatusReport.FAIL);
			} else {
				report.updateTestLogWithNoSS("CyberArk Object found", returnValueType + " and fetched successfully",
						StatusReport.PASS);

			}
			conn.disconnect();
		} catch (Exception e) {
			report.updateTestLogWithNoSS("No CyberArk Object found", e.getMessage(), StatusReport.FAIL);
		}
		return output;
	}

	private static String encodePath(String path) {
		try {
			path = URLEncoder.encode(path, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			LOGGER.error("Error encoding parameter {}", e.getMessage(), e);
		}
		return path;
	}

	/**
	 * Retrieve the text inside the element identified.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element whose text should be
	 *                      retrieved.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the retrieving of the element's text
	 *                      was successful.
	 * @param failedComment comment to log if the retrieving of the element's text
	 *                      was not successful.
	 *
	 * @return a string containing the text of the element or an empty string.
	 */
	public static String getText(By locator, String passedComment, String failedComment) {
		String s = getText(locator);
		if (s.length() > 0) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return s;
	}

	/**
	 * Verify element is displayed on the page and highlight the specified element.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element to be highlighted.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the highlighting of the element's text
	 *                      was successful.
	 * @param failedComment comment to log if the highlighting of the element's text
	 *                      was not successful.
	 *
	 * @return true on success, false on failure.
	 */
	public static boolean highlight(By locator, String passedComment, String failedComment) {
		boolean b = highlight(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Check if the element is present on the page.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object referencing the element to test for
	 *                      visibility.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element was located successful.
	 * @param failedComment comment to log if the element was not located
	 *                      successful.
	 *
	 * @return true if the element is present in the DOM, false if not found or an
	 *         error occurred.
	 */
	public static boolean isElementPresent(By locator, String passedComment, String failedComment) {
		boolean b = isElementPresent(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Verify the element is currently selected.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object of the element to be tested for selection.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is selected.
	 * @param failedComment comment to log if the element is not selected.
	 *
	 * @return true if the element is selected, false if not or an error is
	 *         encountered.
	 */
	public static boolean isSelected(By locator, String passedComment, String failedComment) {
		boolean b = isSelected(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Click on an element, wait for the another element to appears, then use
	 * JavaScript to click on it.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator1      By Object describing the element to receive the first
	 *                      click.
	 * @param locator2      By Object describing the element to receive the first
	 *                      click.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the click was
	 *                      successful.
	 * @param failedComment comment to log in the report if the click was not
	 *                      successful.
	 *
	 * @return true if the click was successful, false otherwise.
	 */
	public static boolean jMenuClick(By locator1, By locator2, String passedComment, String failedComment) {
		boolean b = jMenuClick(locator1, locator2);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Click on the element specified using Java Script executor.
	 *
	 * @param driver  Selenium WebDriver controlling the browser.
	 * @param locator By locator referencing the element to be targeted.
	 *
	 * @return true if the element is clicked, false if an error occurred.
	 */
	protected static boolean jsclick(By locator) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				WebElement element = objdriver.getDriver().findElement(locator);
				JavascriptExecutor js = (JavascriptExecutor) objdriver.getDriver();
				js.executeScript("arguments[0].focus();", element);
				js.executeScript("arguments[0].click();", element);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to click on element.", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Click on the element using java script executor specified and log the
	 * appropriate passed or failed comment in the report.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By locator referencing the element to be targeted.
	 * @param testcase      name of the test case being executed
	 * @param passedComment comment to log if the click was successful.
	 * @param failedComment comment to log if the click was not successful.
	 *
	 * @return true if the click was successful, otherwise false.
	 */
	public static boolean jsclick(By locator, String passedComment, String failedComment) {
		boolean b = jsclick(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Check if an element is present in the DOM of the loaded page.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element to be tested for
	 *                      presence.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element was located successful.
	 * @param failedComment comment to log if the element was not located
	 *                      successful.
	 *
	 * @return true if at least one elemet described by the XPath is present, false
	 *         otherwise.
	 */
	public static boolean jsIsElementExist(By locator, String passedComment, String failedComment) {
		boolean b = jsIsElementExist(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Scroll down into the view.
	 *
	 * @param driver Selenium WebDriver controlling the browser.
	 *
	 * @return true if the scrolldown is done successfully.
	 */
	public static boolean jsScrolldown(WebDriver driver) {
		boolean b = false;
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			threadSleep();
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to Scrolldown to the page", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Click on an element, wait 2 seconds, click on another element. This method
	 * can be used for selecting the sub menu Item from Menu.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator1      description of the first element to be clicked.
	 * @param locator2      description of the second element to be clicked..
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the click was
	 *                      successful.
	 * @param failedComment comment to log in the report if the click was not
	 *                      successful.
	 *
	 * @return true if both items were clicked successfully, false otherwise.
	 */
	public static boolean menuClick(By locator1, By locator2, String passedComment, String failedComment) {
		boolean b = menuClick(locator1, locator2);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Move to an element, wait 3 seconds, move to second element, click on it. This
	 * method can be used for selecting the sub menu Item from Menu.
	 *
	 * @param driver   Selenium WebDriver controlling the browser.
	 * @param locator1 By Object describing the first element to be clicked.
	 * @param locator2 By Object describing the second element to be clicked.
	 *
	 * @return true when both elements are successfully clicked.
	 */
	protected static boolean mouseHover(By locator1, By locator2) {
		boolean b = false;
		try {
			if (isElementPresent(locator1)) {
				WebElement element = objdriver.getDriver().findElement(locator1);
				Actions action = new Actions(objdriver.getDriver());
				action.moveToElement(element).build().perform();
				threadSleep();
				action.moveToElement(objdriver.getDriver().findElement(locator2)).click().build().perform();
				threadSleep();
				action.release(element);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to hover mouse over element.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Move to an element, wait 3 seconds, move to second element, click on it. This
	 * method can be used for selecting the sub menu Item from Menu.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator1      By Object describing the first element to be clicked.
	 * @param locator2      By Object describing the second element to be clicked.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the click was
	 *                      successful.
	 * @param failedComment comment to log in the report if the click was not
	 *                      successful.
	 *
	 * @return true when both elements are successfully clicked.
	 */
	public static boolean mouseHover(By locator1, By locator2, String passedComment, String failedComment) {
		boolean b = mouseHover(locator1, locator2);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Move the mouse pointer over the middle of the specified element.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object referencing the element which the pointer
	 *                      shall be moved over.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the cursor was moved
	 *                      successful.
	 * @param failedComment comment to log in the report if the cursor was not moved
	 *                      successful.
	 *
	 * @return true if the cursor is moved successfully, false if an error occurred.
	 */
	public static boolean mouseOver(By locator, String passedComment, String failedComment) {
		boolean b = mouseOverOnELement(locator);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Select an element from a drop-down list based upon its location in the list.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object pointing to the select element to be targeted.
	 * @param index         the numeric index of the desired selection in the list.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the index is available and select, false if not present or an
	 *         error occurred.
	 */
	public static boolean selectByIndex(By locator, int index, String passedComment, String failedComment) {
		boolean b = selectByIndex(locator, index);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Select an element from a drop-down list based upon its value property.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object pointing to the select element to be targeted.
	 * @param value         the value of the value property in the option tag to be
	 *                      selected.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the value is found and selected, false if the value is not
	 *         found or an error occurred.
	 */
	public static boolean selectByValue(By locator, String value, String passedComment, String failedComment) {
		boolean b = selectByValue(locator, value);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Select and element from a drop-down list based upon its visible text.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object pointing to the select element to be targeted.
	 * @param text          inner text of the tag which to base the selection upon.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the element is found and selected, false if the element was
	 *         not found or an error occurred.
	 */
	public static boolean selectByVisibleText(By locator, String text, String passedComment, String failedComment) {
		boolean b = selectByVisibleText(locator, text);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Enter text into a text field by clearing the existing text.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object referencing the element which should receive
	 *                      the text.
	 * @param text          Text to enter into field.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the text is entered into the element
	 *                      was successfully.
	 * @param failedComment comment to log if the text is entered into the element
	 *                      was not successfully.
	 *
	 * @return true if the text was successfully entered, false if an error
	 *         occurred.
	 */
	public static boolean sendKeysToTextField(By locator, String text, String passedComment, String failedComment) {
		boolean b = sendKeysToTextField(locator, text);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Switch to the default frame within the current page.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and/or
	 *                      enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the frame is successfully focused, false otherwise.
	 */
	public static boolean switchToDefaultFrame(String passedComment, String failedComment) {
		boolean b = switchToDefaultFrame();
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Switch to the default frame within the current page.
	 *
	 * @param driver Selenium WebDriver controlling the browser.
	 *
	 * @return true if the frame is successfully focused, false otherwise.
	 */
	public static boolean switchToDefaultFrame() {
		boolean b = false;
		try {
			objdriver.getDriver().switchTo().defaultContent();
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to switch to default frame.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Switch to a frame within the page based upon the WebElement of the frame.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param WebElement    Web Element representing the frame which should be
	 *                      focused.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and/or
	 *                      enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if able to focus the specified frame, false otherwise.
	 */
	public static boolean switchToFrameByFrameElement(WebElement element, String passedComment, String failedComment) {
		boolean b = switchToFrameByFrameElement(element);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Switch to a frame within the page based upon the index of the frame.
	 *
	 * @param driver Selenium WebDriver controlling the browser.
	 * @param index  integer representing the frame which should be focused.
	 *
	 * @return true if able to focus the specified frame, false otherwise.
	 */
	public static boolean switchToFrameByIndex(int index) {
		boolean b = false;
		try {
			objdriver.getDriver().switchTo().frame(index);
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to switch to frame index.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Switch to a frame within the page based upon the index of the frame.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param index         integer representing the frame which should be focused.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and/or
	 *                      enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if able to focus the specified frame, false otherwise.
	 */
	public static boolean switchToFrameByIndex(int index, String passedComment, String failedComment) {
		boolean b = switchToFrameByIndex(index);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Switch to a frame within the page based upon the name of the frame.
	 *
	 * @param driver Selenium WebDriver controlling the browser.
	 * @param name   a string matching the named frame to bring into focus.
	 *
	 * @return true if able to focus the specified frame, false otherwise.
	 */
	protected static boolean switchToFrameByName(String name) {
		boolean b = false;
		try {
			objdriver.getDriver().switchTo().frame(name);
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to switch to frame name.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Switch to a frame within the page based upon the name of the frame.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param name          a string matching the named frame to bring into focus.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and/or
	 *                      enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if able to focus the specified frame, false otherwise.
	 */
	public static boolean switchToFrameByName(String name, String passedComment, String failedComment) {
		boolean b = switchToFrameByName(name);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Switch to an open window with the specified title.
	 *
	 * @param driver Selenium WebDriver controlling the browser.
	 * @param title  string representing the title of the window which should become
	 *               active.
	 *
	 * @return true if the window was found and brought into focus, false if an
	 *         error occurred.
	 */
	public static boolean switchToWindowBasedOnTitle(String title) {
		boolean b = false;
		try {
			Set<String> allHandles = objdriver.getDriver().getWindowHandles();
			LOGGER.debug("Count of windows:" + allHandles.size());
			for (String handle : allHandles) {
				objdriver.getDriver().switchTo().window(handle);
				String tit = objdriver.getDriver().getTitle();
				LOGGER.debug(objdriver.getDriver().getTitle());
				if (tit.contains(title)) {
					objdriver.getDriver().getWindowHandle();
					maximizeWindow(objdriver.getDriver());
					b = true;
					break;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Unable to switch to the window based on title.", e.getMessage());
			b = false;
		}
		return b;
	}

	// </editor-fold>
	/**
	 * Upload the file using sendKeys method.
	 *
	 * @param driver   Selenium WebDriver controlling the browser.
	 * @param locator  By object referencing the element
	 * @param filepath Describing the file path
	 *
	 * @return true if the file is uploaded successfully.
	 */
	public static boolean uploadFile(By locator, String filepath) {
		boolean b = false;
		try {
			objdriver.getDriver().findElement(locator).sendKeys(filepath);
			threadSleep();
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to upload a file", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Move the mouse pointer over the middle of the specified element.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object referencing the element
	 * @param filepath      Describing the file path
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log in the report if the cursor was moved
	 *                      successful.
	 * @param failedComment comment to log in the report if the cursor was not moved
	 *                      successful.
	 *
	 * @return true if the file is uploaded successfully, false if an error
	 *         occurred.
	 */
	public static boolean uploadFile(By locator, String filepath, String passedComment, String failedComment) {
		boolean b = uploadFile(locator, filepath);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Verify an element is displayed on the page and scroll the window so the
	 * element is in view.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By locator describing the element which is being
	 *                      verified.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element is displayed and enabled.
	 * @param failedComment comment to log if the element is not displayed and/or
	 *                      enabled.
	 *
	 * @return true if the element is displayed and successfully scrolled into view,
	 *         false otherwise.
	 */
	public static boolean verifyElementEnabled(By locator, String passedComment, String failedComment) {
		boolean b = verifyElementEnabled(locator);
		if (b)
			ReportEvent.testStepReport("pass", passedComment);
		else
			ReportEvent.testStepReport("fail", failedComment);
		return b;
	}

	/**
	 * Verify the text value of the element contains the specified string.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element which is being
	 *                      verified.
	 * @param text          string expected to be contained in the text of the
	 *                      element.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element contains the expected
	 *                      text. (whitespace trimmed)
	 * @param failedComment comment to log if the element does not contain the
	 *                      expected text. (whitespace trimmed)
	 *
	 * @return true if the string is present in the element's text, false if not or
	 *         an error occurred.
	 */
	public static boolean verifyTextContains(By locator, String text, String passedComment, String failedComment) {
		boolean b = verifyTextContains(locator, text);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}

	/**
	 * Verify the text value of the element present the specified string.
	 *
	 * @param driver        Selenium WebDriver controlling the browser.
	 * @param locator       By object describing the element which is being
	 *                      verified.
	 * @param text          string expected to be contained in the text of the
	 *                      element.
	 * @param testcase      name of the test case being executed.
	 * @param passedComment comment to log if the element contains the expected
	 *                      text. (whitespace trimmed)
	 * @param failedComment comment to log if the element does not contain the
	 *                      expected text. (whitespace trimmed)
	 *
	 * @return true if the string is present in the element's text, false if not or
	 *         an error occurred.
	 */
	public static boolean verifyTextPresent(By locator, String text, String passedComment, String failedComment) {
		boolean b = verifyTextPresent(locator, text);
		if (b) {
			ReportEvent.testStepReport("pass", passedComment);
		} else {
			ReportEvent.testStepReport("fail", failedComment);
		}
		return b;
	}
}
// No newline at end of file
