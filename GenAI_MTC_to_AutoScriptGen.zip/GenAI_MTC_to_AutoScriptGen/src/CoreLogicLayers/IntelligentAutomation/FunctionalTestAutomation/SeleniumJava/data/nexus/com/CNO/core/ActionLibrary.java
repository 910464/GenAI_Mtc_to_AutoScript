/**
 * Package containing reusable libraries which are specific on Selenium
 *
 * @author HCL
 */
package com.cnoinc.qa.accelerators;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cnoinc.qa.support.ReportEvent;

/**
 * @author HCLYP5
 */
public class ActionLibrary extends TestEngine {
	private static final Logger LOGGER = LogManager.getLogger(ActionLibrary.class.getName());
	private static String exceptionMessageText = "Exception message: ";
	private static String actualValueText = "Actual value: ";
	private static String expectedValueText = "Expected value: ";
	public static int exactRow = 0;
	public static final int THREADTIME = 2500;
	public static String replaceme = "<<REPLACE ME1>>";

	/**
	 * Switch to an Alert/Pop-up and click on the Yes/Ok button.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 *
	 * @return true if the alert was selected and clicked on, false if an error
	 *         occurred.
	 */
	public static boolean acceptAlertOrPopUp() {
		boolean b = false;
		try {
			if (switchToAlertOrPopUp()) {
				objdriver.getDriver().switchTo().alert().accept();
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to accept alert/pop-up.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Validate the specified table header contains the expected text.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By Object describing the element to be targeted.
	 * @param text                  text expected to be present in the cell.
	 *
	 * @return true if the expected text is present in the cell, false if the cell
	 *         isn't found or the text does not match.
	 */
	public static boolean checkingLabels(By locator, String text) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				List<WebElement> labels = objdriver.getDriver().findElements(locator);
				for (WebElement label : labels) {
					String labelText = label.getText().trim();
					if (labelText.equalsIgnoreCase(text)) {
						b = true;
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Unable to validate the table headers.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Click on the element specified.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object referencing the element which should
	 *                              receive the click.
	 *
	 * @return true if the element is clicked, false if an error occurred.
	 */
	protected static boolean click(By locator) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				mouseOverOnELement(locator);
				objdriver.getDriver().findElement(locator).click();
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to click on element.", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Retrieve the text from the element and verify it matches the expected value.
	 * (case-sensitive)
	 *
	 * @param objdriver.getDriver() -
	 *
	 * @DataType :Webobjdriver.getDriver() Selenium Webobjdriver.getDriver()
	 *           controlling the browser.
	 *
	 * @param locator
	 *
	 * @DataType :By By object describing the element whose text should be
	 *           retrieved.
	 *
	 * @param expected
	 *
	 * @DataType :String the value expected to be present in the element.
	 *           (case-sensitive)
	 *
	 * @return true if the text matches, false on error or mismatch. {@link boolean
	 *         }
	 */
	protected static boolean compareText(By locator, String expected) {
		boolean b = false;
		try {
			String s = getText(locator);
			if (s.equals(expected)) {
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to compare text on element.", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Cancel the pop-up if it exists..
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 *
	 * @return true if the alert was selected and clicked on, false if an error
	 *         occurred.
	 */
	public static boolean dismissAlertOrPopUp() {
		boolean b = false;
		try {
			if (switchToAlertOrPopUp()) {
				objdriver.getDriver().switchTo().alert().dismiss();
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to dismiss alert/pop-up.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Click and the source element, drag it to the destination element, and release
	 * the element.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param srcLocator            WebElement to grab.
	 * @param destLocator           WebElement to drop the source element upon.
	 *
	 * @return true if the elements were found and the drag/drop action was
	 *         successful, false otherwise.
	 */
	protected static boolean dragAndDrop(By srcLocator, By destLocator) {
		boolean b = false;
		try {
			WebElement source;
			WebElement destination;
			if (isElementPresent(srcLocator) && isElementPresent(destLocator)) {
				source = objdriver.getDriver().findElement(srcLocator);
				destination = objdriver.getDriver().findElement(destLocator);
				Actions action = new Actions(objdriver.getDriver());
				action.dragAndDrop(source, destination).build().perform();
				b = true;
			} else {
				LOGGER.error("dragAndDrop: Unable to find the source and/or destination element.");
			}
		} catch (Exception e) {
			LOGGER.error("Unable to drag and drop element.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Wait for an element to appear in the DOM
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element to wait for DOM
	 *                              presence.
	 *
	 * @return true if the element is found within the timeout period, false
	 *         otherwise.
	 */
	protected static boolean explicitWaitForElementToAppear(By locator) {
		boolean b = false;
		for (int i = 1; i < 30; i++) {
			try {
				if (!objdriver.getDriver().findElements(locator).isEmpty()) {
					LOGGER.debug("Element is Present : " + locator.toString());
					b = true;
					break;
				}
				threadSleep();
			} catch (NoSuchElementException e) {
				LOGGER.debug("Element not found - continue waiting.");
			} catch (Exception e) {
				LOGGER.error("Unable to wait for element to appear.", e);
				throw new UserdefinedException(exceptionMessageText + e.getMessage());
			}
		}
		return b;
	}

	/**
	 * Retrieve a list of table headers from the specified table.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By locator describing the table from which to
	 *                              retrieve the headers.
	 * @param headerlocator         By locator locating the header of the table
	 *
	 * @return A list containing the text of the table headers discovered.
	 */
	public static List<String> fetchingTableHeaders(By locator, By headerlocator) {
		List<String> allHeadersText = new ArrayList<>();
		try {
			if (isElementPresent(locator)) {
				WebElement table = objdriver.getDriver().findElement(locator);
				List<WebElement> headers = table.findElements(headerlocator);
				for (WebElement header : headers) {
					allHeadersText.add(header.getText());
				}
			}
		} catch (Exception e) {
			LOGGER.error("Unable to fetch table headers.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return allHeadersText;
	}

	/**
	 * Retrieve the attribute of the element identified.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element whose text
	 *                              should be retrieved.
	 *
	 * @return a string containing the attribute value of the element or an empty
	 *         string.
	 */
	protected static String getAttributeValue(By locator, String attribute) {
		String s = "";
		try {
			if (isElementPresent(locator)) {
				s = objdriver.getDriver().findElement(locator).getAttribute(attribute);
			}
			LOGGER.trace(s);
		} catch (Exception e) {
			LOGGER.error("Unable to get Attribute value of element(by)", e.getMessage());
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return s;
	}

	/**
	 * Retrieve the number of elements that are in the specified drop-down list.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object pointing to the select element to be
	 *                              targeted.
	 *
	 * @return an integer representing the number of elements in the drop-down list.
	 *         0 if the drop-down list isn't found.
	 */
	public static int getDropdownList(By locator) {
		int size = 0;
		try {
			if (isElementPresent(locator)) {
				Select s = new Select(objdriver.getDriver().findElement(locator));
				size = s.getOptions().size();
			}
		} catch (Exception e) {
			LOGGER.error("Unable to get the number of elements within dropdown.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return size;
	}

	/**
	 * Get the selected value form a drop-down list.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By element describing the element of the
	 *                              drop-down.
	 *
	 * @return a string containing the text of the selected element in the
	 *         drop-down. null if no text found.
	 */
	public static String getSelectedValue(By locator) {
		String sSelected = null;
		try {
			if (isElementPresent(locator)) {
				Select s = new Select(objdriver.getDriver().findElement(locator));
				sSelected = s.getFirstSelectedOption().getText();
			}
		} catch (Exception e) {
			LOGGER.error("Unable to get selected value from dropdown.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return sSelected;
	}

	/**
	 * Return the number of columns present in a table.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object referencing the table to be examined.
	 * @param collocator            By object referencing the table column to be
	 *                              examined
	 *
	 * @return an integer representing the number of columns present in the
	 *         specified table. 0 if the table is not found or an error occurred.
	 */
	public static int getTableColumnCount(By locator, By collocator) {
		int count = 0;
		try {
			if (isElementPresent(locator)) {
				WebElement table = objdriver.getDriver().findElement(locator);
				List<WebElement> columns = table.findElements(collocator);
				count = columns.size();
				LOGGER.debug("getTableColumnCount: Total column count is : " + count);
			}
		} catch (Exception e) {
			LOGGER.error("Unable to get table column count.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return count;
	}

	/**
	 * Return the number of rows present in a table.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object referencing the table to be examined.
	 * @param rowlocator            describing the tag name of the rows
	 *
	 * @return an integer representing the number of rows present in the specified
	 *         table. 0 if the table is not found or an error occurred.
	 */
	public static int getTableRowCount(By locator, By rowlocator) {
		int count = 0;
		try {
			if (isElementPresent(locator)) {
				WebElement table = objdriver.getDriver().findElement(locator);
				List<WebElement> rows = table.findElements(rowlocator);
				count = rows.size();
			}
		} catch (Exception e) {
			LOGGER.error("Unable to get table row count.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return count;
	}

	/**
	 * Retrieve the text inside the element identified.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element whose text
	 *                              should be retrieved.
	 *
	 * @return a string containing the text of the element or an empty string.
	 */
	protected static String getText(By locator) {
		String s = "";
		try {
			if (isElementPresent(locator)) {
				s = objdriver.getDriver().findElement(locator).getText().trim();
			}
		} catch (Exception e) {
			LOGGER.error("Unable extract element text.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return s;
	}

	/**
	 * Retrieve a list of WebElement matching the supplied pattern.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By element describing the elements to be
	 *                              searched for in the DOM.
	 *
	 * @return a List of WebElements matching the pattern, null if none were found
	 *         or an error occurred.
	 */
	public static List<WebElement> getWebElements(By locator) {
		List<WebElement> webElements = null;
		try {
			if (isElementPresent(locator)) {
				webElements = objdriver.getDriver().findElements(locator);
			}
		} catch (Exception e) {
			LOGGER.error("Unable to get elements matching pattern.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return webElements;
	}

	/**
	 * Verify element is displayed on the page and highlight the specified element.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element to be
	 *                              highlighted.
	 *
	 * @return true on success, false on failure.
	 */
	protected static boolean highlight(By locator) {
		boolean b = false;
		try {
			WebElement element = objdriver.getDriver().findElement(locator);
			if (element.isDisplayed() && objdriver.getDriver() instanceof JavascriptExecutor) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript("arguments[0].style.border='4px solid green'", element);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to highlight element.", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Check if the element is present on the page.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object referencing the element to test for
	 *                              visibility.
	 *
	 * @return true if the element is present in the DOM, false if not found or an
	 *         error occurred.
	 */
	protected static boolean isElementPresent(By locator) {
		boolean b = false;
		try {
			if (objdriver.getDriver().findElement(locator).isDisplayed()) {
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to verify element is present.", e);
			throw new UserdefinedException("Unable to verify element is present.");
		}
		return b;
	}

	/**
	 * Verify the element is currently selected.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object of the element to be tested for
	 *                              selection.
	 *
	 * @return true if the element is selected, false if not or an error is
	 *         encountered.
	 */
	protected static boolean isSelected(By locator) {
		boolean b;
		try {
			b = objdriver.getDriver().findElement(locator).isSelected();
		} catch (Exception e) {
			LOGGER.error("Unable to verify element is selected.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Click on an element, wait for the another element to appears, then use
	 * JavaScript to click on it.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator1              By Object describing the element to receive the
	 *                              first click.
	 * @param locator2              By Object describing the element to receive the
	 *                              first click.
	 *
	 * @return true if the buttons are clicks correctly, false otherwise.
	 */
	protected static boolean jMenuClick(By locator1, By locator2) {
		boolean b = false;
		try {
			if (isElementPresent(locator1)) {
				WebElement element = objdriver.getDriver().findElement(locator1);
				Actions action = new Actions(objdriver.getDriver());
				action.moveToElement(element).click().build().perform();
				WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 20);
				wait.until(ExpectedConditions.visibilityOfElementLocated(locator2));
				WebElement e = objdriver.getDriver().findElement(locator2);
				threadSleep();
				JavascriptExecutor js = (JavascriptExecutor) objdriver.getDriver();
				js.executeScript("arguments[0].click();", e);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to click on menu item.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Check if an element is present in the DOM of the loaded page.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element to be tested
	 *                              for presence.
	 *
	 * @return true if at least one element described by the XPath is present, false
	 *         otherwise.
	 */
	protected static boolean jsIsElementExist(By locator) {
		boolean b = false;
		try {
			WebElement element = objdriver.getDriver().findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) objdriver.getDriver();
			js.executeScript("arguments[0].scrollIntoView(true)", element);
			js.executeScript("arguments[0].focus();", element);
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to find the element", e.getMessage());
			b = false;
		}
		return b;
	}

	/**
	 * Click on an element, wait 2 seconds, click on another element.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator1              description of the first element to be clicked.
	 * @param locator2              description of the second element to be clicked.
	 *
	 * @return true when both elements are successfully clicked.
	 */
	protected static boolean menuClick(By locator1, By locator2) {
		boolean b = false;
		try {
			if (isElementPresent(locator1)) {
				Actions action = new Actions(objdriver.getDriver());
				WebElement element = objdriver.getDriver().findElement(locator1);
				action.click(element).build().perform();
				threadSleep();
				action.click(objdriver.getDriver().findElement(locator2)).build().perform();
				threadSleep();
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to click on menu element.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Move the mouse pointer over the middle of the specified element.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object referencing the element which the
	 *                              pointer shall be moved over.
	 *
	 * @return true if the cursor is moved successfully.
	 */
	protected static boolean mouseOverOnELement(By locator) {
		boolean b = false;
		try {
			WebElement ele = objdriver.getDriver().findElement(locator);
			Actions action = new Actions(objdriver.getDriver());
			action.moveToElement(ele).build().perform();
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to move mouse to element.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Scrolldown to locator
	 *
	 * @param message   is a instance of Webobjdriver.getDriver() which is
	 *                  controlling a browser
	 * @param byElement to scrolldown to particular element/locator
	 */
	public static void scrollToElement(By byElement) {
		try {
			WebElement element = objdriver.getDriver().findElement(byElement);
			((JavascriptExecutor) objdriver.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			LOGGER.error("Unable to Scrolldown to the element in a page", e);
		}
	}

	/**
	 * Select an element from a drop-down list based upon its location in the list.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object pointing to the select element to be
	 *                              targeted.
	 * @param index                 the numeric index of the desired selection in
	 *                              the list.
	 *
	 * @return true if the index is available and select, false if not present or an
	 *         error occurred.
	 */
	public static boolean selectByIndex(By locator, int index) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				Select s = new Select(objdriver.getDriver().findElement(locator));
				s.selectByIndex(index);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to select index within dropdown.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Select an element from a drop-down list based upon its value property.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object pointing to the select element to be
	 *                              targeted.
	 * @param value                 the value of the value property in the option
	 *                              tag to be selected.
	 *
	 * @return true if the value is found and selected, false if the value is not
	 *         found or an error occurred.
	 */
	public static boolean selectByValue(By locator, String value) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				Select s = new Select(objdriver.getDriver().findElement(locator));
				s.selectByValue(value);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to select value within dropdown.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Select and element from a drop-down list based upon its visible text.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object pointing to the select element to be
	 *                              targeted.
	 * @param text                  inner text of the tag which to base the
	 *                              selection upon.
	 *
	 * @return true if the element is found and selected, false if the element was
	 *         not found or an error occurred.
	 */
	public static boolean selectByVisibleText(By locator, String text) {
		boolean b = false;
		try {
			if (isElementPresent(locator)) {
				Select s = new Select(objdriver.getDriver().findElement(locator));
				s.selectByVisibleText(text);
				b = true;
			}
		} catch (Exception e) {
			LOGGER.error("Unable to select visible text within dropdown.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Enter text into a text field by clearing the existing text.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object referencing the element which should
	 *                              receive the text.
	 * @param text                  Text to enter into field.
	 *
	 * @return true if the text was successfully entered, false if an error
	 *         occurred.
	 */
	protected static boolean sendKeysToTextField(By locator, String text) {
		boolean b = false;
		try {
			b = mouseOverOnELement(locator);
			if (b) {
				objdriver.getDriver().findElement(locator).click();
				objdriver.getDriver().findElement(locator).clear();
				objdriver.getDriver().findElement(locator).sendKeys(text);
			}
		} catch (Exception e) {
			LOGGER.error("Unable to send keys to text field.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Switch the active window to an alert/pop-up.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 *
	 * @return true if the objdriver.getDriver() was able to switch to the alert,
	 *         false if an error occurred.
	 */
	public static boolean switchToAlertOrPopUp() {
		boolean b = false;
		try {
			objdriver.getDriver().switchTo().alert();
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to switch to alert/pop-up.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Switch to a frame within the page based upon the Web element of the frame.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param index                 Web element representing the frame which should
	 *                              be focused.
	 *
	 * @return true if able to focus the specified frame, false otherwise.
	 */
	public static boolean switchToFrameByFrameElement(WebElement element) {
		boolean b = false;
		try {
			objdriver.getDriver().switchTo().frame(element);
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to switch to frame Web Element.", e);
			b = false;
		}
		return b;
	}

	/**
	 * @Java -Wait Thread Sleep
	 */
	public static void threadSleep() {
		try {
			Thread.sleep(THREADTIME);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public static void threadSleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	/**
	 * Verify the table Key based on value and select a row from the table
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param testcase              name of the test case being executed.
	 * @param gridID                Table id from the grid
	 * @param givenTableValue       To find a row fom the grid ,key(column index)
	 *                              based on value(Column Value)
	 *
	 * @return row number,column no, WebElement of the column
	 */
	public static void verfyGridTable(int mint, WebElement gridID, HashMap<Integer, String> givenTableValue) {
		threadSleep();
		int rowGrid = 0;
		String givenValueInGrid = null;
		boolean matchFound = false;
		try {
			WebElement table = gridID;
			List<WebElement> tblRows = table.findElements(By.cssSelector("tr"));
			int tblRowsCount = tblRows.size();
			for (rowGrid = 1; rowGrid < tblRowsCount; rowGrid++) {
				List<WebElement> actualTblData = tblRows.get(rowGrid).findElements(By.cssSelector("td"));
				int tblDataCount = actualTblData.size();
				if (tblDataCount <= mint) {
					continue;
				}
				matchFound = true;
				Set<Integer> keys = givenTableValue.keySet();
				for (Integer key : keys) {
					givenValueInGrid = givenTableValue.get(key);
					LOGGER.debug("Column(key) no's :" + key + " value(text) of the column's :"
							+ actualTblData.get(key).getText());
					LOGGER.debug("Actual is match with expected which is " + givenValueInGrid);
					if (!givenValueInGrid.trim().equals(actualTblData.get(key).getText())) {
						matchFound = false;
						break;
					}
				}
				if (matchFound) {
					LOGGER.debug("Record has been show properly :" + matchFound);
					exactRow = rowGrid;
					break;
				}
			}
			if (!matchFound) {
				givenTableValue.clear();
				ReportEvent.testStepReport("fail", "Not able to find the value in the grid" + givenValueInGrid);
				table.click();
			}
			givenTableValue.clear();
		} catch (Exception e) {
			LOGGER.error("enterValueAndKeysTab :", e.getMessage());
			throw new UserdefinedException("enterValueAndKeysTab :" + e.getMessage());
		}
	}

	/**
	 * Verify an element is displayed on the page and scroll the window so the
	 * element is in view.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By locator reference describing the element
	 *                              which is being verified.
	 *
	 * @return true if the element is displayed and successfully scrolled into view,
	 *         false otherwise.
	 */
	protected static boolean verifyElementEnabled(By locator) {
		boolean b = false;
		try {
			WebElement element = objdriver.getDriver().findElement(locator);
			if (element.isDisplayed()) {
				((JavascriptExecutor) objdriver.getDriver()).executeScript("arguments[0].scrollIntoView(true)",
						element);
				b = objdriver.getDriver().findElement(locator).isEnabled();
			}
		} catch (NoSuchElementException e) {
			LOGGER.debug("Element not found on page.");
		} catch (Exception e) {
			LOGGER.error("Unable to verify the element is enabled.", e);
			throw new UserdefinedException(exceptionMessageText + e.getMessage());
		}
		return b;
	}

	/**
	 * Verify the text value of the element contains the specified string.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element which is being
	 *                              verified.
	 * @param text                  string expected to be contained in the text of
	 *                              the element.
	 *
	 * @return true if the string is present in the element's text, false if not or
	 *         an error occurred.
	 */
	protected static boolean verifyTextContains(By locator, String text) {
		boolean b;
		try {
			LOGGER.debug(expectedValueText + text);
			String actual = getText(locator);
			LOGGER.debug(actualValueText + actual);
			b = actual.trim().contains(text.trim());
		} catch (Exception e) {
			LOGGER.error("Unable to verify text contents.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Verify the text value of the element equals the specified string.
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 * @param locator               By object describing the element which is being
	 *                              verified.
	 * @param text                  string expected to be equals in the text of the
	 *                              element.
	 *
	 * @return true if the string is present in the element's text, false if not or
	 *         an error occurred.
	 */
	protected static boolean verifyTextPresent(By locator, String text) {
		boolean b;
		try {
			LOGGER.debug(expectedValueText + text);
			String actual = getText(locator);
			LOGGER.debug(actualValueText + actual);
			b = actual.trim().equalsIgnoreCase(text.trim());
		} catch (Exception e) {
			LOGGER.error("Unable to verify text contents.", e);
			b = false;
		}
		return b;
	}

	/**
	 * Default Constructor Library
	 */
	ActionLibrary() {
	}

	/**
	 * @Description: To convert Date to String in M/d/yyyy format
	 */
	public String convertDatetoString_SpecifedFormat(Date date) {
		String currentDate = new SimpleDateFormat("M/d/yyyy").format(date);
		return currentDate;
	}

	/**
	 * Validate the existence of a pop-up
	 *
	 * @param objdriver.getDriver() Selenium Webobjdriver.getDriver() controlling
	 *                              the browser.
	 *
	 * @return true if pop-up exist otherwise return false
	 */
	public boolean isAlertPresent() {
		boolean b = false;
		try {
			objdriver.getDriver().switchTo().alert();
			b = true;
		} catch (Exception e) {
			LOGGER.error("Unable to determine if alert is present.", e);
			b = false;
		}
		return b;
	}
}
