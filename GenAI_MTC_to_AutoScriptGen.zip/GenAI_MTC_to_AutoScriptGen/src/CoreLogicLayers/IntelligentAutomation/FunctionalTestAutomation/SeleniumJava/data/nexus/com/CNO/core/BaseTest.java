package testScripts;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import com.cnoinc.qa.accelerators.ReusableLibrary;
import com.cnoinc.qa.accelerators.TestEngine;
import com.cnoinc.qa.support.ExtentManager;
import com.cnoinc.qa.support.ImageReportGenerator;
import com.cnoinc.qa.support.LogUtil;
import com.cnoinc.qa.support.ReportEvent;
import com.cnoinc.qa.support.StatusReport;
import com.cnoinc.qa.utilities.ReadDataExcel;
import com.cnoinc.qa.utilities.ReadDataSQL;

public class BaseTest extends ReusableLibrary {
	protected static String testEnvironment;
	protected String commonData = "dbo.MI_APP_156_DotComWebsites_CPL_Common_Testdata_QE";
	protected static final String GET_INFORMATION = "dbo.MI_APP_156_DotComWebsites_CPL_GetInformation_QE";
	protected static final String MOBILE_AUTOMATION = configProps.getProperty("MobileAutomation");
	protected static ReadDataSQL rd = null;
	protected static Logger LOGGER = LogManager.getLogger(BaseTest.class.getName());
	protected ReadDataExcel rE = new ReadDataExcel(TestEngine.configProps.getProperty("runManagerPath"));
	private static final String ENDING_TEST = "Ending the test ";
	protected String RUN_MANAGER = "RunManager";
	private static final String UNABLETO_CONNECTDB="Unable to connect to DB: ";
	private static final String LOG_PROJECT_NAME = "ProjectName";
	private static final String LOG_APP_ID = "AppID";
	private static final String LOG_PARAENT_UNIQUEID = "ParentUniqueId";
	private static final String WINDOW_SCROLLBY_0 = "window.scrollBy(0,";
	/**
	 * Function to Find the first {@link WebElement}, also take screen shot and
	 * wait until the specified element is visible
	 *
	 * @param by
	 *            The locator used to identify the element {@link WebDriver}
	 */
	public WebElement findElementnTakescreenShot(By arg0) {
		WebElement element;
		if (objdriver.getDriver().findElement(arg0).isDisplayed() || isElementVisible(arg0)) {
			report.updateTestLog("Action", "Action Performed Successfully",
					StatusReport.PASS);
			element = objdriver.getDriver().findElement(arg0);
		} else {
			report.updateTestLog("Action",
					"Action Failed to Perform, please check the Locators",
					StatusReport.FAIL);
			element = null;
		}
		return element;
	}

	/**
	 * Function to wait until the specified element is visible
	 *
	 * @param by
	 *            The locator used to identify the element {@link WebDriver}
	 */
	public boolean isElementVisible(By arg0) {
		boolean elementVisible = false;
		try {
			(new WebDriverWait(objdriver.getDriver(), 60)).until(ExpectedConditions
					.visibilityOfElementLocated(arg0));
			elementVisible = true;

		} catch (TimeoutException ex) {
			elementVisible = false;
		}
		return elementVisible;
	}

	/**
	 * Read the Environment.properties, get the username and password, start a
	 * connection.
	 *
	 * @return a ReadData object connected to the database of choice
	 *
	 * @throws SQLException
	 * @throws NumberFormatException
	 */
	protected static ReadDataSQL connectDatabase() throws NumberFormatException, SQLException {
		LOGGER.debug("Connecting to the database.");
		bootstrap();
		String dbServer = TestEngine.loadEnvironment(testEnvironment, ".dbHost");
		String dbPort = TestEngine.loadEnvironment(testEnvironment, ".dbPort");
		String dbDatabase = TestEngine.loadEnvironment(testEnvironment, ".dbDatabase");
		String dbUser = System.getenv("TD_USER");
		String dbPass = System.getenv("TD_PASS");
		if (dbPass == null || dbUser == null)
			errOut("The database user and/or password was not supplied. Exiting.", null);
		return new ReadDataSQL(dbServer, Integer.parseInt(dbPort), dbUser, dbPass, dbDatabase);
	}

	/**
	 * Get information about the environment under test.
	 */
	private static void bootstrap() {
		if (System.getProperty("test.env") != null)
			testEnvironment = System.getProperty("test.env");
		else {
			errOut("System property 'test.env' is not set but required. Exiting.", null);
		}
	}

	/**
	 * Handle errors.
	 *
	 * @param message
	 *                    error message to output to the LOGGER.
	 * @param e
	 *                    exception.
	 */
	private static void errOut(String message, Exception e) {
		if (e == null)
			LOGGER.error(message);
		else
			LOGGER.error(message, e);
		System.exit(1);
	}

	/**
	 * Driver instance set without thread
	 *
	 * @throws SQLException
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	@BeforeMethod
	public void dbconnectivity() throws NumberFormatException, SQLException {
		/**
		 * Extract the Test Data
		 */
		String uuid = null;
		errorcount = 0;
		uuid = LogUtil.getTraceID().toString();
		objdriver.setUuid(uuid);
		rd = connectDatabase();
	}

	/**
	 * TestCase name :@objdriver.getTestCaseName(),@testCaseID Application
	 * URL: @url launch the browser
	 */
	public void launchingbrowser(String appURL) throws IOException {
		//validateTestcase(suiteName);
		String suiteName;
		if (configProps.getProperty("RunConfiguration").equalsIgnoreCase("")) {
			suiteName = "RunManager";
		} else {
			suiteName = configProps.getProperty("RunConfiguration");
		}
		String browser = rE.getCellBasedOnHeader(suiteName, "Browser", objdriver.getTestCaseName());
		LogUtil.startTestCase(objdriver.getTestCaseName(), configProps.getProperty(LOG_PROJECT_NAME),
				objdriver.getUuid(), configProps.getProperty(LOG_APP_ID), configProps.getProperty(LOG_PARAENT_UNIQUEID),
				configProps.getProperty("SequenceNumber"),"NA");

		ReportEvent.testStepReport("Info",
				"Starting the " + objdriver.getTestCaseName() + " test in " + browser + " browser");
		getBrowser(appURL, browser);
		implicitWait(objdriver.getDriver(), 20);
	}

	public void validateTestcase() {
		String suiteName;
		if (configProps.getProperty("RunConfiguration").equalsIgnoreCase("")) {
			suiteName = "RunManager";
		} else {
			suiteName = configProps.getProperty("RunConfiguration");
		}
		String tExecute = rE.getCellBasedOnHeader(suiteName, "Execute", objdriver.getTestCaseName());
		if (!tExecute.equalsIgnoreCase("Yes") && !tExecute.equalsIgnoreCase("Y")) {
			String reportPrint = rE.getCellBasedOnHeader(suiteName, "Report", objdriver.getTestCaseName());
			if (reportPrint.equalsIgnoreCase("Yes") || reportPrint.equalsIgnoreCase("Y")) {
				ReportEvent.testStepReport("SKIP", "Skipping the test for " + objdriver.getTestCaseName());
				ReportEvent.testStepReport("END", null);
			}
			objdriver.closeTestCase();
			throw new SkipException("Skipping the test");
		}
	}

	@Override
	public void fullpage_scroll_Screenshot(String pageTopic) {
		((JavascriptExecutor) objdriver.getDriver()).executeScript("window.scrollTo(0,0)");
		ajaxFluentPredicateWait();
		float height = ((Number) ((JavascriptExecutor) objdriver.getDriver())
				.executeScript("return window.innerHeight")).floatValue() - 100;
		float totalheight = ((Number) ((JavascriptExecutor) objdriver.getDriver())
				.executeScript("return document.body.scrollHeight")).floatValue();
		float numberofScrolls;
		int scrolls;
		if ((totalheight % height) == 0) {
			numberofScrolls = (totalheight / height);
		} else {
			numberofScrolls = (totalheight / height) + 1;
		}
		scrolls = (int) numberofScrolls;
		for (int s = 1; s <= scrolls; s++) {
			report.updateTestLog(pageTopic + " Page", pageTopic + " Page; Part " + s, StatusReport.SCREENSHOT);
			ajaxFluentPredicateWait();
			((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLLBY_0 + height + ");");
		}
	}

	@AfterMethod
	public void quitBrowser() {
		LOGGER.debug("Close the Browser from the instance");
		ReportEvent.testStepReport("ReportEnd", null);
		try {
			if (objdriver.getDriver() != null) {
				ReportEvent.testStepReport("Info", ENDING_TEST + objdriver.getTestCaseName());
				if (errorcount != 0) {
					LogUtil.endTestCase(objdriver.getTestCaseName(), configProps.getProperty(LOG_PROJECT_NAME),
							objdriver.getUuid(), configProps.getProperty(LOG_APP_ID),
							configProps.getProperty(LOG_PARAENT_UNIQUEID), configProps.getProperty("SequenceNumber"), "Fail");
				} else {
					LogUtil.endTestCase(objdriver.getTestCaseName(), configProps.getProperty(LOG_PROJECT_NAME),
							objdriver.getUuid(), configProps.getProperty(LOG_APP_ID),
							configProps.getProperty(LOG_PARAENT_UNIQUEID), configProps.getProperty("SequenceNumber"), "Pass");
				}

				ReportEvent.testStepReport("END", null);
				objdriver.closeDriver();
				objdriver.closeTestCase();
				objdriver.closeUuid();
			}
			LOGGER.trace("thread -- completed " + Thread.currentThread().getName());
		} finally {
			ReportEvent.testStepReport("CLOSE", null);
			ExtentManager.htmlReportPathWithTime(stdTimeStamp);
		}
	}

	@AfterSuite(alwaysRun = true)
	public void teardown() throws Throwable {
		ReportEvent.testStepReport("CLOSE", null);
		try {
			rd.closeConnection();

		} finally {
			ImageReportGenerator.HTMLImagereport();
			ExtentManager.htmlReportPathWithTime(stdTimeStamp);
		}
	}
}
