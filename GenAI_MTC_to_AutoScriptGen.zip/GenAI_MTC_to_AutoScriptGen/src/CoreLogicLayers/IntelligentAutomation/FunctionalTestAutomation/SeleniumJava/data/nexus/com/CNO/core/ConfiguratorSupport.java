/**
 * Package: Manage the getting and setting of a properties file.
 *
 * @author HCL 05 May,2022
 */
package com.cnoinc.qa.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
/**
 * IOException is a Unchecked Java exception that occurs when an IO operation
 * fails
 */
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cnoinc.qa.accelerators.UserdefinedException;

/**
 * Manage the getting and setting of a properties file.
 */
public class ConfiguratorSupport {
	static Properties props = new Properties();
	private static final Logger LOGGER = LogManager.getLogger(ConfiguratorSupport.class.getName());
	String strFileName; // Filename of the configuration file

	/**
	 * Creates a new configuration support object with the specified file.
	 *
	 * @param strFileName configuration file to use.
	 */
	public ConfiguratorSupport(String strFileName) {
		this.strFileName = strFileName;
	}

	/**
	 * Clear the loaded properties.
	 */
	public void clean() {
		props.clear();
	}

	/**
	 * Retrieve the value for the specified key from the configuration file. <br>
	 * <br>
	 * This method will first attempt to load the properties file verbatim as
	 * provided during construction. In the typical scenario this has been the file
	 * named "config.properties" and is located in the root of the project. If that
	 * file is not found, an attempt is then made to load the file from the
	 * resources directory. When attempting to load the file from the resources
	 * directory, all path information is discarded the filename is loaded from the
	 * resources directory. <br>
	 * <br>
	 * Please note the resources directory is relative to where the code is placed
	 * in the project hierarchy. If the code is in src/main/java/ the resources are
	 * loaded from src/main/resources. Likewise, if the code is in src/test/java the
	 * resources are loaded from src/test/resources. <br>
	 * <br>
	 * The best practice is to place the project configuration files in the proper
	 * resources directory.
	 *
	 * @param strKey key which for which to search within the properties file.
	 *
	 * @return a string containing the value of the key if found, null if the key is
	 *         not found.
	 */
	public String getProperty(String strKey) {
		if (strKey == null) {
			throw new UserdefinedException("Request key was not set.");
		}
		// Loading value for configuration key " + strKey + " from " + strFileName);
		try (FileInputStream fin = new FileInputStream(new File(strFileName))) {
			// attempt to load from legacy location (root of project)
			props.load(fin);
			fin.close();
		} catch (SecurityException e) {
			LOGGER.error("Unable to read " + strFileName, e);
			throw new UserdefinedException("Unable to read " + strFileName);
		} catch (IOException e) {
			LOGGER.error("An error occurred reading " + strFileName, e);
			throw new UserdefinedException("An error occurred reading " + strFileName);
		} catch (Exception e) {
			LOGGER.info("Configuration file not found in legacy location, using Classloader." + e);
		}
		return props.getProperty(strKey);
	}

	/**
	 * Remove the key/value pair from the configuration file.
	 *
	 * @param strKey key of the key/value pair to remove from the configuration
	 *               file.
	 *
	 * @throws RuntimeException an error occurred while attempting to delete the
	 *                          key/value pair from the file.
	 *
	 * @deprecated no longer supported.
	 */
	@Deprecated
	public void removeProperty(String strKey) {
		// Removing property " + strKey + " from " + strFileName);
		try (FileInputStream in = new FileInputStream(new File(strFileName))) {
			props.load(in);
			props.remove(strKey);
			FileOutputStream out = new FileOutputStream(strFileName);
			props.store(out, null);
			in.close();
			out.close();
		} catch (Exception e) {
			LOGGER.error("Unable to delete key/value pair.", e);
			throw new UserdefinedException("Unable to delete the key/value pair from the configuration file.");
		}
	}

	/**
	 * Set the key/value pair in the configuration file.
	 *
	 * @param strKey   key to store in the configuration file.
	 * @param strValue value of the key to store in the configuration file.
	 *
	 * @deprecated no longer supported.
	 */
	@Deprecated
	public void setProperty(String strKey, String strValue) {
		// Setting property " + strKey + " with value " + strValue + " in " +
		// strFileName);
		try (FileInputStream in = new FileInputStream(new File(strFileName))) {
			props.load(in);
			props.setProperty(strKey, strValue);
			FileOutputStream out = new FileOutputStream(strFileName);
			props.store(out, null);
			in.close();
			out.close();
		} catch (Exception e) {
			LOGGER.error("Unable to write key/value pair.", e);
			throw new UserdefinedException("Unable to write the key/value pair to the configuration file.");
		}
	}
}
