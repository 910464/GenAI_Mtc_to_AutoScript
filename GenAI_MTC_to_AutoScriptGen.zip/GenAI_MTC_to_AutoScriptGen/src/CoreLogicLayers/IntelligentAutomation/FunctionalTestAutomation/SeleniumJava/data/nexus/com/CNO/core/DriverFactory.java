/**
 * Package: DriverFactory Purpose: Individual Thread instance creation
 *
 * @author HCL 05 May,2022
 */
package com.cnoinc.qa.accelerators;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.AppiumDriver;

/**
 * @author HCLX2L Apr 29, 2022
 */
public class DriverFactory {
	private static DriverFactory instance = new DriverFactory();

	/**
	 * Method Description : getInstance
	 *
	 * @return
	 */
	public static DriverFactory getInstance() {
		return instance;
	}

	ThreadLocal<WebDriver> driver = new ThreadLocal<>();
	ThreadLocal<AppiumDriver> appiumdriver = new ThreadLocal<>();
	ThreadLocal<String> testCaseName = new ThreadLocal<>();
	ThreadLocal<String> uuid = new ThreadLocal<>();
	ThreadLocal<Integer> uuidCount = new ThreadLocal<>();
	ThreadLocal<Integer> stepCount = new ThreadLocal<>();
	public DriverFactory() {
		// Do Nothing ... Do not allow to initialize this class from outside
	}

	/**
	 * Method Description : closeDriver
	 */
	public void closeDriver() {
		getInstance().driver.get().quit();
		getInstance().driver.remove();
	}
	
	public void closeAppiumDriver() {
		getInstance().appiumdriver.get().closeApp();
		getInstance().appiumdriver.get().quit();
		getInstance().appiumdriver.remove();
	}

	public void closeTestCase() {
		getInstance().testCaseName.remove();
	}
	
	public void closeUuid() {
		getInstance().uuid.remove();
	}
	public void closeUuidCount() {
		getInstance().uuidCount.remove();
	}
	
	
	
	

	/**
	 * Method Description : getDriver
	 *
	 * @return
	 */

	public WebDriver getDriver() {
		return getInstance().driver.get();
	}
	
	public AppiumDriver getAppiumDriver() {
		return getInstance().appiumdriver.get();
	}
	
	public String getUuid() {
		return getInstance().uuid.get().trim();
	}
	public Integer getUuidCount() {
		return getInstance().uuidCount.get();
	}

	public String getTestCaseName() {
		return getInstance().testCaseName.get().trim();
	}

	/**
	 * Method Description : setDriver
	 *
	 * @param driverParam
	 */
	public void setDriver(WebDriver driverParam) {
		getInstance().driver.set(driverParam);
	}
	
	public void setAppiumDriver(AppiumDriver driverParam) {
		getInstance().appiumdriver.set(driverParam);
	}

	public void setTestCaseName(String testCaseName) {
		getInstance().testCaseName.set(testCaseName);
	}
	public void setUuid(String uuid) {
		getInstance().uuid.set(uuid);
	}
	public void setUuidCount(Integer count) {
		getInstance().uuidCount.set(count);
	}
	
	public int getStepCount() {
		return getInstance().stepCount.get();
	}
	
	public void setStepCount(int stepNum) {
		getInstance().stepCount.set(stepNum);
	}
}
