/**
 * Package containing reusable synchronized libraries methods for Extent Manager
 * which support for report Mechanism
 *
 * @author HCL
 */
package com.cnoinc.qa.support;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * org.apache.logging.log4j Class LogManager
 */
import org.apache.logging.log4j.LogManager;
/**
 * org.apache.logging.log4j Interface Logger
 */
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.cnoinc.qa.utilities.Utility;

/**
 * A class containing methods used to interface with the Extent report engine.
 */
public class ExtentManager {
	private static final Logger LOGGER = LogManager.getLogger(ExtentManager.class.getName());
	static ExtentReports extent;
	static ExtentSparkReporter htmlReporter;
	public static String dynamicHtmlReportPath;
	public static final String USER_DIR = "user.dir";
	private static String reportConfig = System.getProperty(USER_DIR) + File.separator + "ReportsConfig.xml";
	private static String resultsPath = System.getProperty(USER_DIR) + File.separator + "Results" + File.separator;
	private static String htmlreportspath = System.getProperty(USER_DIR) + Utility.fnReadPropFile("testResultsReport");
	private static String testApplicationName;
	private static String testApplicationType;
	private static String testAutomationTool;
	private static String testBrowser;
	private static String testEnvironment;
	private static String unknown = "Unknown";
	private static String logreportspath = System.getProperty(USER_DIR) + Utility.fnReadPropFile("logReport");
	private static final String HISTORYREPORT_PATH = "\\Results\\TestResult_";
	// <editor-fold desc="Constructors">

	public static File dynamictestResultFolder(String strDataNow) {
		File dir = new File(System.getProperty(USER_DIR) + HISTORYREPORT_PATH
				+ strDataNow.toString().replace("/", "_").replace(":", "_").replace(" ", "_"));
		if (!dir.mkdirs()) {
			// Failed to create the Test Results directory with Time stamp" + dir
		}
		return dir;
	}

	/**
	 * Create a new Folder to store the past execution report
	 *
	 * @return path to the newly created report, or null on error.
	 */
	/**
	 * Create a new Folder to store the past execution report
	 *
	 * @return path to the newly created report, or null on error.
	 */
	public static String dynamicTimeStamp() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		String formatDateTime = now.format(format);
		SimpleDateFormat sdf1 = new SimpleDateFormat();
		sdf1.applyPattern("MM/dd/yyyy HH:mm:ss");
		Date date = null;
		try {
			date = sdf1.parse(formatDateTime);
		} catch (java.text.ParseException e) {
			LOGGER.info(e);
		}
		return sdf1.format(date);
	}

	/**
	 * Load the report configuration from the xml file and add the test environment
	 * details to the report.
	 * <p>
	 * The report configuration will be searched in the root of the project first.
	 * If the configuration is not found it will attempt to load it from the
	 * resources directory. If a package is being created, please be sure to place
	 * the configuration in the proper resources directory.
	 * <p>
	 *
	 * @return the updated extent report object.
	 */
	public static synchronized ExtentReports getInstance() {
		if (extent == null) {
			dynamicHtmlReportPath = htmlReportPath();
			// creating a constructor of file class and parsing an XML file
			File file = new File(reportConfig);
			if (!file.exists()) {
				// Report config not found in legacy location, using
				// Classloader");
				URL furl = Thread.currentThread().getContextClassLoader().getResource(file.getName());
				if (furl == null) {
					throw new IllegalArgumentException("Unable to locate report configuration xml file.");
				}
				readXMLfile(file);
			} else {
				readXMLfile(file);
			}

			setReportAdditionalSystemInfo(extent);

		}
		return extent;
	}
	/** 
	 * Read Reports Configuration xml file
	 * @param file
	 */
	private static void readXMLfile(File file) {
		try {

			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
			NodeList nodeList = doc.getElementsByTagName("configuration");
			// nodeList is not iterable, so we are using for loop
			for (int itr = 0; itr < nodeList.getLength(); itr++) {
				Node node = nodeList.item(itr);
				//System.out.println("\nNode Name :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					htmlReporter.config()
							.setDocumentTitle(eElement.getElementsByTagName("documentTitle").item(0).getTextContent());
					htmlReporter.config()
							.setReportName(eElement.getElementsByTagName("reportName").item(0).getTextContent());
					htmlReporter.config().setTheme(Theme.STANDARD);
					htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Get the location of the Extent XML configuration file.
	 *
	 * @return string representing the full path of the Extent XML configuration
	 *         file.
	 */
	public static synchronized String getReportConfig() {
		return reportConfig;
	}

	/**
	 * Get the base directory to which test reports shall be written.
	 *
	 * @return a string representing the location on the local filesystem where
	 *         tests shall be written.
	 */
	public static synchronized String getReportPath() {
		return resultsPath;
	}

	/**
	 * Get the name of the application under test.
	 *
	 * @return a string containing the name of the application under test.
	 */
	public static synchronized String getTestApplicationName() {
		String name;
		if (testApplicationName != null) {
			name = testApplicationName;
		} else if (Utility.fnReadPropFile("name_of_aut") != null) {
			name = Utility.fnReadPropFile("name_of_aut");
		} else {
			name = unknown;
		}
		return name;
	}

	/**
	 * Get the type of application being tested (Desktop, Web, etc).
	 *
	 * @return a string containing the type of application being tested.
	 */
	public static synchronized String getTestApplicationType() {
		String type;
		if (testApplicationType != null) {
			type = testApplicationType;
		} else if (Utility.fnReadPropFile("nature_of_aut") != null) {
			type = Utility.fnReadPropFile("nature_of_aut");
		} else {
			type = unknown;
		}
		return type;
	}

	/**
	 * Get the type of automation tool used (Selenium, Appium, etc).
	 *
	 * @return a string containing automation tool used for testing.
	 */
	public static synchronized String getTestAutomationTool() {
		String tool;
		if (testAutomationTool != null) {
			tool = testAutomationTool;
		} else if (Utility.fnReadPropFile("automation_tool_used") != null) {
			tool = Utility.fnReadPropFile("automation_tool_used");
		} else {
			tool = unknown;
		}
		return tool;
	}

	/**
	 * Get the browser being used for testing the application (Chrome, Firefox,
	 * etc).
	 *
	 * @return a string containing the name of the browser being used.
	 */
	public static synchronized String getTestBrowser() {
		String browser;
		if (testBrowser != null) {
			browser = testBrowser;
		} else if (System.getProperty("browser.type") != null) {
			browser = System.getProperty("browser.type");
		} else if (Utility.fnReadPropFile("browserType") != null) {
			browser = Utility.fnReadPropFile("browserType");
		} else {
			browser = unknown;
		}
		return browser;
	}

	/**
	 * Get the environment in which the application is being tested (INT, SYS, ACC,
	 * PROD, etc).
	 *
	 * @return a string containing the environment in which the application under
	 *         test is configured.
	 */
	public static synchronized String getTestEnvironment() {
		String environment;
		if (testEnvironment != null) {
			environment = testEnvironment;
		} else if (System.getProperty("test.env") != null) {
			environment = System.getProperty("test.env");
		} else if (Utility.fnReadPropFile("test_environment") != null) {
			environment = Utility.fnReadPropFile("test_environment");
		} else {
			environment = unknown;
		}
		return environment;
	}
	// </editor-fold>
	// <editor-fold desc="Public Methods">

	/**
	 * Create a new Extent Report.
	 *
	 * @return path to the newly created report, or null on error.
	 */
	public static synchronized String htmlReportPath() {
		String directory = htmlreportspath;
		String fileName = "HTMLReport" + ".html";
		File dir = new File(directory);
		if (!dir.mkdirs()) {
			LOGGER.error("Failed to create the Test Results directory " + directory);
			return null;
		}

		htmlReporter = new ExtentSparkReporter(directory + File.separator + fileName);
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		// extent = new ExtentReports(directory + File.separator + fileName);
		return (directory + File.separator + fileName);
	}

	public static synchronized void htmlReportPathWithTime(String strDataNow) {
		String filename = "HTMLReport_" + strDataNow.toString().replace("/", "_").replace(":", "_").replace(" ", "_")
				+ ".html";
		Path sourceDirectory = Paths.get(htmlreportspath + "\\HTMLReport.html");
		Path targetDirectory = Paths.get(System.getProperty(USER_DIR) + HISTORYREPORT_PATH
				+ strDataNow.toString().replace("/", "_").replace(":", "_").replace(" ", "_") + "\\" + filename);
		/**
		 * copy source to target using Files Class
		 */
		try {
			if (new File(System.getProperty(USER_DIR) + HISTORYREPORT_PATH
					+ strDataNow.toString().replace("/", "_").replace(":", "_").replace(" ", "_") + "\\" + filename)
							.exists()) {
				cleanUp(targetDirectory);
			}
			Files.copy(sourceDirectory, targetDirectory);
			logReportPathWithTime(strDataNow);
		} catch (IOException e) {
			LOGGER.error("Failed to copy the Test Results directory from source to target" + e);
		}
	}

	public static synchronized void logReportPathWithTime(String strDataNow) {
		String filename = "PipelineLogs.log";
		Path sourceDirectory = Paths.get(logreportspath + "\\PipelineLogs.log");
		Path targetDirectory = Paths.get(System.getProperty(USER_DIR) + HISTORYREPORT_PATH
				+ strDataNow.toString().replace("/", "_").replace(":", "_").replace(" ", "_") + "\\" + filename);
		/**
		 * copy source to target using Files Class
		 */
		try {
			if (new File(System.getProperty(USER_DIR) + HISTORYREPORT_PATH
					+ strDataNow.toString().replace("/", "_").replace(":", "_").replace(" ", "_") + "\\" + filename)
							.exists()) {
				cleanUp(targetDirectory);
			}
			Files.copy(sourceDirectory, targetDirectory);
		} catch (IOException e) {
			LOGGER.error("Failed to copy the Test Log directory from source to target" + e);
		}
	}


	public static void cleanUp(Path path) throws NoSuchFileException, DirectoryNotEmptyException, IOException {
		Files.delete(path);
	}

	/**
	 * Info of Environment,Automation tools used Nature of AUT,Name of the
	 * AUT,Tested Browser
	 */
	private static void setReportAdditionalSystemInfo(ExtentReports ext) {
		try {
			ext.setSystemInfo("Environment", getTestEnvironment());
			ext.setSystemInfo("Automation tools used", getTestAutomationTool());
			ext.setSystemInfo("Nature of AUT", getTestApplicationType());
			ext.setSystemInfo("Name of the AUT", getTestApplicationName());
			ext.setSystemInfo("Tested Browser", getTestBrowser());
		} catch (Exception e) {
			LOGGER.error("Failed to add extended System Info to Extent report.", e);
		}
	}
	// </editor-fold>

	/**
	 * Set the location of the Extent XML configuration file.
	 *
	 * @param file string representing the full path of the Extent XML configuration
	 *             file.
	 */
	public static synchronized void setReportConfig(String file) {
		reportConfig = file;
	}

	/**
	 * Set the base directory to which test reports shall be written.
	 *
	 * @param path filesystem path.
	 */
	public static synchronized void setReportPath(String path) {
		resultsPath = path;
	}

	/**
	 * Set the name of the application under test.
	 *
	 * @param name name of the application under test.
	 */
	public static synchronized void setTestApplicationName(String name) {
		testApplicationName = name;
	}

	/**
	 * Set the type of application being tested (Desktop, Web, etc).
	 *
	 * @param type type of application.
	 */
	public static synchronized void setTestApplicationType(String type) {
		testApplicationType = type;
	}

	/**
	 * Set the type of automation tool used (Selenium, Appium, etc).
	 *
	 * @param tool name of the automation tool.
	 */
	public static synchronized void setTestAutomationTool(String tool) {
		testAutomationTool = tool;
	}

	/**
	 * Set the browser being used for testing the application (Chrome, Firefox,
	 * etc).
	 *
	 * @param browser name of the browser.
	 */
	public static synchronized void setTestBrowser(String browser) {
		testBrowser = browser;
	}

	/**
	 * Set the environment in which the application is being tested (INT, SYS, ACC,
	 * PROD, etc).
	 *
	 * @param environment name of the environment.
	 */
	public static synchronized void setTestEnvironment(String environment) {
		testEnvironment = environment;
	}

	/**
	 * Dummy constructor to prevent class instantiation.
	 */
	private ExtentManager() {
		throw new IllegalStateException("Utility class - static methods only");
	}
	// </editor-fold>
	// <editor-fold desc="Accessors">
}
