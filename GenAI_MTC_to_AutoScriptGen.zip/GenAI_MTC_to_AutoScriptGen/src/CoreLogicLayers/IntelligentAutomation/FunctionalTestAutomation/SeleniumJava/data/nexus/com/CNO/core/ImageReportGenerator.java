/**
 * Package containing reusable libraries methods for Image Report Generator
 * which support to capture screenshot and steps with timestamp status Mechanism
 *
 * @author HCL
 */
package com.cnoinc.qa.support;

/**
 * java.io.File new file
 */
import java.io.File;
/**
 * java.io.IOException IOException is a Java exception that occurs when an IO
 * operation fails
 */
import java.io.IOException;
/**
 * java.time.Instant
 */
import java.time.Instant;
/**
 * java.time.LocalDateTime
 */
import java.time.LocalDateTime;
/**
 * java.time.ZoneId
 */
import java.time.ZoneId;
/**
 * java.time.format.DateTimeFormatter
 */
import java.time.format.DateTimeFormatter;
/**
 * java.util.Arrays
 */
import java.util.Arrays;
/**
 * java.util.Iterator An iterator over a collection. Iterator takes the place of
 * Enumeration in the Java Collections Framework
 */
import java.util.Iterator;
/**
 * java.util.LinkedHashMap A comparator interface is used to order the objects
 * of user-defined classes
 */
import java.util.LinkedHashMap;
/**
 * java.util.LinkedList LinkedHashMap class is used to retrieve or fetch the
 * value mapped by a particular key mentioned in the parameter
 */
import java.util.LinkedList;
/**
 * java.util.List List is interface in java collection
 */
import java.util.List;
/**
 * java.util.Map Map is interface in java collection
 */
import java.util.Map;

/**
 * org.apache.commons.io.FileUtils
 */
import org.apache.commons.io.FileUtils;
/**
 * org.apache.logging.log4j Class LogManager
 */
import org.apache.logging.log4j.LogManager;
/**
 * org.apache.logging.log4j Interface Logger
 */
import org.apache.logging.log4j.Logger;

import com.cnoinc.qa.accelerators.UserdefinedException;
/**
 * Utility Class, also known as Helper class, is a class, which contains just
 * static methods, it is stateless and cannot be instantiated
 */
import com.cnoinc.qa.utilities.Utility;

/**
 * Image Report Generator which support to capture screenshot and steps with
 * timestamp and status in a summary HTML report
 *
 * @author HCL
 */
public class ImageReportGenerator {
	/**
	 * summary name of the screenshot path name
	 */
	public static final String IDXFILE = "Imageindex.html";
	/**
	 * Log4j is a fast, reliable and flexible logging framework which is written in
	 * java. It is an open-source logging API for java. Simply the logging means
	 * some way to indicate the state of the system at runtime
	 */
	private static final Logger LOGGER = LogManager.getLogger(ImageReportGenerator.class.getName());
	/**
	 * Line separator
	 */
	public static final String NEWLINE = System.lineSeparator();
	/**
	 * Current Image Desc
	 */
	public static String currimgdesc;
	/**
	 * Remove space from image
	 */
	public static String trimImgDesc;
	/**
	 * Status of the steps
	 */
	public static String testStepStatus;
	/**
	 * HTML tag
	 */
	public static final String ARR_HTML = "<html>";
	/**
	 * Body tag
	 */
	public static final String ARR_BODY = "<body>";
	/**
	 * The <b> tag in HTML is used to specify the bold text without any extra
	 * importance.
	 */
	public static final String BSB = "<b>%s</b>";
	/**
	 * The
	 * <td>HTML element defines a cell of a table that contains data. It
	 * participates in the table model.
	 */
	public static final String ARR_TD = "</td>";
	/**
	 * Pattern for lowercase/Upper case
	 */
	private static final String STRPATTERN = "\\s+";
	/**
	 * DataType: Iterator
	 */
	private static Iterator<String> it;
	/**
	 * DataType: List
	 */
	private static List<String> Value;

	public static String getFileTime(String filename) {
		File file = new File(filename);
		LocalDateTime fileDate = Instant.ofEpochMilli(file.lastModified()).atZone(ZoneId.systemDefault())
				.toLocalDateTime();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String formatDateTime = fileDate.format(format);
		return formatDateTime;
	}
	/*
	 * Add the new Line to the HTML Report
	 */

	public static String getLineSeparator() {
		return NEWLINE;
	}

	public static String htmlContentDiff(Iterator<String> lt, String imgfileval, String rptdir, String currdir) {
		Object key = lt.next();
		String currimg = key.toString();
		imgfileval += "<tr>" + getLineSeparator();
		if (currimg.contains("Pass")) {
			currimgdesc = String.format("<font color=\"green\">%s</font>", currimg);
			trimImgDesc = String.format(BSB, trim(currimgdesc, "Screenshot_Pass_", ".jpg"));
			testStepStatus = String.format("<font color=\"green\">%s</font>", "Pass");
		} else if (currimg.contains("Fail")) {
			currimgdesc = String.format("<font color=\"red\">%s</font>", currimg);
			trimImgDesc = String.format(BSB, trim(currimgdesc, "Screenshot_Fail_", ".jpg"));
			testStepStatus = String.format("<font color=\"red\">%s</font>", "Fail");
		} else {
			LOGGER.error("currimg is not predent PASS or FAIL");
		}
		imgfileval += "<td>";
		imgfileval += trimImgDesc;
		imgfileval += ARR_TD;
		imgfileval += "<td>";
		imgfileval += testStepStatus;
		imgfileval += ARR_TD;
		imgfileval += "<td>";
		String fullname = rptdir + "screenshots\\" + currdir + "\\" + currimg;
		String filetime = String.format(BSB, getFileTime(fullname));
		imgfileval += filetime;
		imgfileval += ARR_TD;
		imgfileval += "<td>";
		String imgrec = String.format("<a href=\"%s/%s\" ><img src=\"%s/%s\" alt=\"%s\" height=\"150\" width=\"300\">",
				currdir, currimg, currdir, currimg, currimg);
		imgfileval += imgrec;
		imgfileval += ARR_TD;
		imgfileval += getLineSeparator();
		imgfileval += getLineSeparator();
		imgfileval += "</tr>" + getLineSeparator();
		return imgfileval;
	}

	/**
	 * Generate the HTML Report Image based on the screenshots from each test step
	 * of the test case
	 */
	@SuppressWarnings("deprecation")
	public static void HTMLImagereport() {
		LOGGER.trace("Starting the Html Report Process");
		Map<String, List<String>> appmap = new LinkedHashMap<>();
		String rptdir = Utility.fnReadPropFile("screenshotReportdir");
		LOGGER.trace("Capturing the screenshots folder :" + rptdir);
		String idxfileval = ARR_HTML + getLineSeparator();
		idxfileval += ARR_BODY + getLineSeparator();
		recdir(rptdir + "Screenshots", appmap);
		it = appmap.keySet().iterator();
		while (it.hasNext()) {
			Object key = it.next();
			String currdir = key.toString();
			LOGGER.trace("Test case Screenshot Folder to get Image Report: " + currdir);
			String currhtml = String.format("%s.html", currdir.replace(STRPATTERN, ""));
			String idxrec = String.format("<a href=\"%s\">%s</a>", currhtml, currdir);
			idxfileval += idxrec;
			idxfileval += getLineSeparator();
			idxfileval += "<br>";
			idxfileval += getLineSeparator();
			Value = appmap.get(key);
			String imgfileval = ARR_HTML + getLineSeparator();
			imgfileval += ARR_BODY + getLineSeparator();
			imgfileval += "<table border = \"1\" cellpadding = \"5\" cellspacing = \"5\">";
			imgfileval += "<tr>";
			imgfileval += "<th>TestCase Step Image</th>";
			imgfileval += "<th>TestCase Step Result</th>";
			imgfileval += "<th>TestCase Step Time</th>";
			imgfileval += "<th>Image</th>";
			imgfileval += "</tr>";
			Iterator<String> lt = Value.iterator();
			while (lt.hasNext()) {
				/**
				 * html Content Diff based on HTML boday
				 */
				imgfileval = htmlContentDiff(lt, imgfileval, rptdir, currdir);
			}
			imgfileval += "</table>" + getLineSeparator();
			imgfileval += ARR_BODY + getLineSeparator();
			imgfileval += ARR_HTML;
			File currhtmlfile = new File(rptdir + "Screenshots\\" + currhtml);
			try {
				FileUtils.writeStringToFile(currhtmlfile, imgfileval);
			} catch (IOException e) {
				/**
				 * LOGGER: Unable to write screenshots to the HTML Image file:
				 */
				LOGGER.error("Unable to write screenshots to the HTML Image file: " + e.getMessage());
			}
		}
		idxfileval += "</body>" + getLineSeparator();
		idxfileval += "</html>";
		/**
		 * Screenshots path
		 */
		File file = new File(rptdir + "Screenshots\\" + IDXFILE);
		try {
			FileUtils.writeStringToFile(file, idxfileval);
		} catch (IOException e) {
			LOGGER.error("Unable to write  HTML Image index file: " + e.getMessage());
			throw new UserdefinedException("Unable to write  HTML Image index file: " + e.getMessage());
		}
	}

	/**
	 * Retrieve the Screenshot files from the Test Cases Screenshots Directory key.
	 *
	 * @param path        describes the folder containing the Screenshots
	 * @param Map<String, List<<String>> describe the Screenshot folder and the
	 *                    screenshot files inside the directory found.
	 */
	public static void recdir(String path, Map<String, List<String>> map) {
		File root = new File(path);
		File[] listArr = root.listFiles();
		if (listArr == null) {
			return;
		}
		Arrays.sort(listArr, (f1, f2) -> Long.valueOf(f1.lastModified()).compareTo(f2.lastModified()));
		for (File f : listArr) {
			if (f.isDirectory()) {
				String dname = f.getName();
				map.computeIfAbsent(dname, list -> new LinkedList<>());
				recdir(f.getAbsolutePath(), map);
				LOGGER.trace("Test Case Screenshots Directory Name:" + dname);
			} else {
				String fname = f.getName();
				String dname = f.getParentFile().getName();
				LOGGER.trace("Screenshot File Name::" + fname);
				map.get(dname).add(fname);
			}
		}
		LOGGER.trace(map);
	}
	/*
	 * Get the latest file Modified time for all the screenshot image Files
	 * 
	 * @param filename to retrieve the Modified time
	 */

	/*
	 * Trim the existing text
	 */
	public static String trim(String str, String prefix, String suffix) {
		int indexOfLast = str.lastIndexOf(suffix);
		str = str.substring(0, indexOfLast);
		return str.replaceFirst(prefix, "");
	}

	/**
	 * Generate the HTML Report Image based on the screenshots from each test step
	 * of the test case
	 */
	ImageReportGenerator() {
	}
}
