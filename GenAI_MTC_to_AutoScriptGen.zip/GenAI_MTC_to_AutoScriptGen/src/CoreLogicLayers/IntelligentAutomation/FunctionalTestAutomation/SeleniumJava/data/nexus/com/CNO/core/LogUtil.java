package com.cnoinc.qa.support;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cnoinc.qa.utilities.Utility;

/**
 * @author COGZZJ
 *
 */
public class LogUtil {

	private LogUtil() {
		super();
		// TODO Auto-generated constructor stub
	}

	private static final String STEP2 = "Step ";
	private static final char DELIMITER = '|';
	private static final char KEYSEPARATOR = '=';
	private static final String DATETIME = "DTS";
	private static final String HOST = "Host";
	private static final String LOGLEVEL = "LogLevel";
	private static final String UNIQUEID = "UniqueId";
	private static final String ENVIRONMENT = "ENV";
	private static final String JENKINSENV = "JENKINSENV";
	private static final String APPID = "AppId";
	private static final String TCNAME = "TcName";
	private static final String STEP = "Step";
	private static final String PARENTUNIQUEID = "ParentUniqueId";
	private static final String SEQUENCENUMBER = "SequenceNumber";
	private static final String STATUS = "Status";
	private static final String MESSAGE = "LogMessage";

	// private static Properties properties = Settings.getInstance();
	private static String strEnv = System.getProperty("test.env");

	// Initialize Log4j logs

	private static Logger Log = LogManager.getLogger(Logger.class.getName());//
	static Logparameters param = new Logparameters();

	// This is to print log for the beginning of the test case, as we usually run so
	// many test cases as a test suite

	public static void startTestCase(String sTestCaseName, String stepNum, String UUID, String appID,
			String processGUID, String sequence, String status) {
		param.setSequence(sequence);
		param.setProcessGUID(processGUID);
		param.setStatus(status);
		param.setMessage("START TESTCASE");
		Log.info(formatLog("INFO", UUID, strEnv, appID, sTestCaseName, stepNum, param));
	}

	// This is to print log for the ending of the test case

	public static void endTestCase(String sTestCaseName, String stepNum, String UUID, String appID, String processGUID,
			String sequence, String status) {
		param.setSequence(sequence);
		param.setProcessGUID(processGUID);
		param.setStatus(status);
		param.setMessage("END TESTCASE");
		Log.info(formatLog("INFO", UUID, strEnv, appID, sTestCaseName, stepNum, param));

	}

	// Need to create these methods, so that they can be called

	public static void info(String sTestCaseName, String stepNum, String UUID, String appID, String processGUID,
			String sequence, String status, String message) {
		param.setSequence(sequence);
		param.setProcessGUID(processGUID);
		param.setStatus(status);
		param.setMessage(message);
		Log.info(formatLog("INFO", UUID, strEnv, appID, sTestCaseName, STEP2 + stepNum, param));

	}

	public static void warn(String sTestCaseName, String stepNum, String UUID, String appID, String processGUID,
			String sequence, String status, String message) {
		param.setSequence(sequence);
		param.setProcessGUID(processGUID);
		param.setStatus(status);
		param.setMessage(message);
		Log.warn(formatLog("WARN", UUID, strEnv, appID, sTestCaseName, STEP2 + stepNum, param));

	}

	public static void error(String sTestCaseName, String stepNum, String UUID, String appID, String processGUID,
			Logparameters parameter, Exception ex) {

		parameter.setProcessGUID(processGUID);
		parameter.setStatus(param.getStatus());
		parameter.setMessage(param.getMessage());
		Log.error(formatLog("ERROR", UUID, strEnv, appID, sTestCaseName, STEP2 + stepNum, parameter) + "EXCEPTION"
				+ KEYSEPARATOR + ex.getMessage() + DELIMITER, ex);

	}

	public static void fatal(String sTestCaseName, String stepNum, String UUID, String appID, String processGUID,
			Logparameters parameter, Exception ex) {

		parameter.setProcessGUID(processGUID);
		parameter.setStatus(param.getStatus());
		parameter.setMessage(param.getMessage());
		Log.fatal(formatLog("FATAL", UUID, strEnv, appID, sTestCaseName, STEP2 + stepNum, parameter) + "EXCEPTION"
				+ KEYSEPARATOR + ex.getMessage() + DELIMITER, ex);

	}

	public static void debug(String sTestCaseName, String stepNum, String UUID, String appID, String processGUID,
			String sequence, String status, String message) {
		param.setSequence(sequence);
		param.setProcessGUID(processGUID);
		param.setStatus(status);
		param.setMessage(message);
		Log.debug(formatLog("DEBUG", UUID, strEnv, appID, sTestCaseName, STEP2 + stepNum, param));
	}

	public static UUID getTraceID() {
		return UUID.randomUUID();
	}

	public static String getDateTime() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
		Date date = new Date();
		return format.format(date);
	}

	public static String getHostName() {
		String hostName = "NA";
		try {
			InetAddress myHost = InetAddress.getLocalHost();
			hostName = myHost.getHostName();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hostName;
	}

	private static String formatLog(String logLevel, String UUID, String env, String appID, String testCaseName, String stepNum,Logparameters param){
		 StringBuilder formattedString = new StringBuilder(DATETIME);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(getDateTime());
		 formattedString.append(DELIMITER);
		 formattedString.append(HOST);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(getHostName());
		 formattedString.append(DELIMITER);
		 formattedString.append(LOGLEVEL);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(logLevel);
		 formattedString.append(DELIMITER);
		 formattedString.append(UNIQUEID);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(UUID);
		 formattedString.append(DELIMITER);
		 formattedString.append(ENVIRONMENT);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(env);
		 formattedString.append(DELIMITER);
		 formattedString.append(JENKINSENV);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(Utility.fnReadPropFile(JENKINSENV));
		 formattedString.append(DELIMITER);
		 formattedString.append(APPID);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(appID);
		 formattedString.append(DELIMITER);
		 formattedString.append(TCNAME);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(testCaseName);
		 formattedString.append(DELIMITER);
		 formattedString.append(STEP);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(stepNum);
		 formattedString.append(DELIMITER);
		 formattedString.append(PARENTUNIQUEID);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(param.getProcessGUID());
		 formattedString.append(DELIMITER);
		 formattedString.append(SEQUENCENUMBER);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(param.getSequence());
		 formattedString.append(DELIMITER);
		 formattedString.append(STATUS);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(param.getStatus());
		 formattedString.append(DELIMITER);
		 formattedString.append(MESSAGE);
		 formattedString.append(KEYSEPARATOR);
		 formattedString.append(param.getMessage());
		 formattedString.append(DELIMITER);
		 
		 return formattedString.toString();
	 }
}