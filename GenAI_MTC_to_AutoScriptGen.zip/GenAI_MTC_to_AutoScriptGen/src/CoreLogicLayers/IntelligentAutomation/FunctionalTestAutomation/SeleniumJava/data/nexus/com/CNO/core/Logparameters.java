package com.cnoinc.qa.support;

public class Logparameters {

	String status;
	String message;
	String processGUID;
	String sequenceNumber;

	public String getProcessGUID() {
		return processGUID;
	}

	public void setProcessGUID(String processGUID) {
		this.processGUID = processGUID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getSequence() {
		return sequenceNumber;
	}
	
	public void setSequence(String sequence) {
		this.sequenceNumber = sequence;
	}
}