package pageclasses;

import org.openqa.selenium.By;


public class Pega_CPL_ObjectRepo {

	private static final String DIV_DATA_ANALYTICS_ASSET_ID_2116924_H3 = "div[data-analytics-asset-id='2116924'] h3";
	private static final String DIV_DATA_ANALYTICS_ASSET_ID_2116905_H3 = "div[data-analytics-asset-id='2116905'] h3";
	private static final String DIV_DATA_ANALYTICS_ASSET_ID_2116886_H3 = "div[data-analytics-asset-id='2116886'] h3";
	private static final String SELECT_ID_DISCLOSURE_STATE = "select[id='disclosureState']";
	private static final String BUTTON_TEST_ID_QUOTE_FILTER_BUTTON = "button[test-id='quoteFilterButton']";
	private static final String INPUT_TEST_ID_ZIP_CODE = "input[test_id='zipCode'],INPUT[test_id='zipCode']";
	private static final String INPUT_TEST_ID_CITY = "input[test_id='city'],INPUT[test_id='city']";
	private static final String INPUT_TEST_ID_BIRTH_DAY = "input[test_id='birthDay']";
	private static final String INPUT_TEST_ID_LAST_NAME = "input[test_id='lastName']";
	private static final String INPUT_TEST_ID_FIRST_NAME = "input[test_id='firstName']";
	private Pega_CPL_ObjectRepo() {
		super();
		
	}
	private static final String INPUT_CONTAINS_CLASS_DATE = "input[class*='date']";
	private static final String SELECT_TEST_ID_STATE_SELECTION = "select[test_id='stateSelection']";
	private static final String SELECT_TEST_ID_OCCUPATION = "select[test_id='occupation']";
	private static final String P_CONTAINS_CLASS_INS_HEADER = "p[class='product_name_quote']";
	private static final String BUTTON_CONTINUE="button[test_id='continue']";
	// ---------------------QPanel Page-----------------------
	public static By QpanelPageCoverage = By.cssSelector("p[id*='PlanCoverage']");	
	public static By QpanelPagePremium = By.cssSelector("p[id*='Premium']");
	public static By QpanelPageProdcut = By.cssSelector(P_CONTAINS_CLASS_INS_HEADER);

	// -----------------------------------Other Policies--------------------
	public static By OtherPolicies_ = By.cssSelector("");
	public static By OtherPolicies_Continue = By.cssSelector("button[test_id='replacecontinue']");
	public static By OtherPolicies_Yes = By.cssSelector("input[test_id='Yes_GBLRQ1']+span");
	public static By OtherPolicies_No = By.cssSelector("input[test_id='No_GBLRQ1']+span");
	public static By OtherPolicies_alert = By.cssSelector("div[role='alert']");
	public static By BeneficiariesValidation = By.cssSelector("div[class='container'] h1");
	public static By OtherPolicies_HelpfulTip = By.cssSelector("a[class='tip-link-opener collapsed'] span[class='text']");
	public static By ReplacementQuestion1 = By.cssSelector("(div[class='question-item']):nth-of-type(1)p");
	 
	public static By ReplacementQuestion2 = By.cssSelector("(div[class='question-item']):nth-of-type(2)p");
	public static By ReplacementQuestionNo2 = By.cssSelector("input[test_id='No_GBLRQ2']+span");
	public static By OtherPolicies_Yes2 = By.cssSelector("input[test_id='Yes_GBLRQ2']+span");
	public static By policyPurchaseIneligible = By.xpath("//strong[contains(text(),'sorry')]");
	public static By exitApplication = By.xpath("//a[contains(text(),'Exit')]");

	// ---------------------------------Beneficiaries Page----------------------
	public static By Beneficiaries = By.cssSelector("");
	public static By Beneficiaries_Continue = By.cssSelector("button[test_id='benecontinue']");
	public static By Beneficiaries_Back = By.cssSelector("a[test_id='beneBack']");
	public static By Beneficiaries_firstname = By.cssSelector("input[id*='firstName1']");
	public static By Beneficiaries_firstname1 = By.cssSelector("input[aria-describedby='firstName2']");
	public static By Beneficiaries_firstname2 = By.cssSelector("input[aria-describedby='firstName3']");
	public static By Beneficiaries_lastname = By.cssSelector("input[id*,'lastName1']");
	public static By Beneficiaries_lastname1 = By.cssSelector("input[aria-describedby='lastName2']");
	public static By Beneficiaries_lastname2 = By.cssSelector("input[aria-describedby='lastName3']");
	public static By Beneficiaries_firstname_error = By
			.cssSelector("input[aria-describedby*;='firstName1']+div");
	public static By Beneficiaries_lastName_error = By
			.cssSelector("input[aria-describedby*='lastName1')]+div");
	public static By Beneficiaries_Relationship = By.cssSelector("select[name='relation1']");
	public static By Beneficiaries_realtionship_error = By
			.cssSelector("(select[title='relation1']:nth-of-type(3)+div");
	public static By Beneficiaries_share = By.cssSelector("select[id*='share3']");
	public static By sharePercentageError = By.cssSelector("div[@id='sharePercentageError']");
	// ---------------------------------------------paymentPage---------------------------
	public static By payment = By.cssSelector("");
	public static final  By paymentBillMeLater = By.cssSelector(
			"a[id='billmelater']");
	public static final By FirstPaymentOnly_BankAccount = By.cssSelector("label[class='form-check-label form-check-bankAccountfirstpaymentonly']");	
	public static final By paymentCreditCard = By.cssSelector("a[id='creditCard']");
	public static final By paymentBankAccount = By.cssSelector("a[id='bankAccount']");
	public static final By paymentContinue = By.cssSelector("button[test_id='payment_continue']");
	public static By paymentBack = By.cssSelector("a[test_id='paymentbc_back']");
	public static By paymentAccountType = By.cssSelector("select[test_id='accountType']");
	public static By paymentRecurringCC = By.cssSelector("input[test_id='creditCardrecurring']+label");
	public static By paymentFirstPaymentCC = By
			.cssSelector("input[test_id='creditCardfirstpaymentonly']+label");
	public static By paymentRecurringBankAcc = By
			.cssSelector("input[test_id='bankAccountrecurring']+label");
	public static By paymentFirstPaymentBankAcc = By
			.cssSelector("input[test_id='bankAccountfirstpaymentonly']+label");
	
	public static final By RountingNumber = By.cssSelector("input[test_id='routingNumber'], INPUT[test_id='routingNumber']");
	public static final By RountingNumberError = By.cssSelector("div[id='_CPPolicyPaymentModule_INSTANCE_MUEObC4u9LXi_routingNumberHelper'] div[class='required']");
	public static final By BillmelaterPopup=By.cssSelector("div[id='billMeLaterModal']");
	public static final By ccExpirationDate = By.cssSelector("input[test_id='expireDate'],INPUT[test_id='expireDate']");
	public static final By ccSecurityCode = By.cssSelector("input[test_id='CVV'],INPUT[test_id='CVV']");
	public static final By SavingsAccount=By.cssSelector("label[class='form-check-label form-check-savings']");
    public static final By CheckingAccount=By.cssSelector("label[class='form-check-label form-check-checking']");
	public static final By ccnumber = By.cssSelector("input[test_id='creditCardNumber'], INPUT[test_id='creditCardNumber']");
	public static final By paymentBankAccountEffectiveDate = By.cssSelector("input[test_id='bankEffDate']");
	public static final By paymentCreditCardEffectiveDate = By.cssSelector("input[test_id='credidEffDate']");
	public static final By bankAccountNumber = By.cssSelector("input[test_id='accountNumber']");
	public static final By accountNumberError = By.cssSelector("div[id='_CPPolicyPaymentModule_INSTANCE_MUEObC4u9LXi_accountNumberHelper'] div");
	public static final By cardNumberError = By.cssSelector("div[id='_CPPolicyPaymentModule_INSTANCE_MUEObC4u9LXi_creditCardNumberHelper'] div");
	public static final By ccSecurityCodeError = By.cssSelector("div[id='_CPPolicyPaymentModule_INSTANCE_MUEObC4u9LXi_CVVHelper'] div");
	public static final By paymentPageVerification =By.cssSelector("div[class='form_container payment'] h1");
	public static final By paymentpagePaymentMethod = By.cssSelector("div[class='form_container payment'] h1");;
	public static final By paymentPageContinue = By.cssSelector("button[test_id='payment_continue']");	
	public static final By firstPaymentOnly = By.cssSelector("label[class='form-check-label form-check-creditCardfirstpaymentonly']");
	public static final  By billmePopupConfirm=By.cssSelector("button[id='confirmBml_btn']");
	public static final By paymentPageAccountTypeChecking = By.cssSelector("label[class='form-check-label form-check-checking']");
	public static final By paymentPageAccountTypeSavings = By.cssSelector("label[class='form-check-label form-check-savings']");
	public static final String EFFDATECALENDER= "(//th[contains(text(),'month year')]/ancestor::div[@class='datepicker-days']//tbody)[1]/tr/td";
	public static final String EFFDATESTATUS="((//th[contains(text(),'month year')]/ancestor::div[@class='datepicker-days']//tbody)[1]/tr/td[text()='calcDate'])[mon]";
	public static final By PaymentEffNext = By.xpath("(//div[@class='datepicker-days']/table/thead/tr/th[@class='next'])[1]");
	public static final String DATELIST= "(//th[contains(text(),'month year')]/ancestor::div[@class='datepicker-days']//tbody/tr/td[iterate])[1]";
	public static final String CALENDERTABLE = "(//th[contains(text(),'month year')]/ancestor::div[@class='datepicker-days']//tbody)[1]";
	public static final  By GQPAGE_CITY = By.cssSelector(INPUT_TEST_ID_CITY);
	public static final By gqpage_Zipcode = By.cssSelector(INPUT_TEST_ID_ZIP_CODE);
	public static final By addressContinue=By.cssSelector("button[test_id='address_continue']");
	// -----------------------------------ReviewSubmit---------------------------
		public static final By certificate = By.cssSelector("div[class='policy_certificate'] strong");
	public static By reviewPageHeader = By.cssSelector("div[class='container'] h1");
	public static final By ssnField = By.cssSelector("input[test_id='ssn'], INPUT[test_id='ssn']");
	public static final By signature = By.cssSelector("input[test_id='signature']");
	public static final By noticesExpand = By.cssSelector("span[data-target='#notice_disclosure'] i[class='fa fa-chevron-down']");
	public static final By noticeCollapse = By.cssSelector("span[data-target='#notice_disclosure'] i[class='fa fa-chevron-up']");
	public static final By reviewExpand = By.cssSelector("span[data-target='#review_application'] i[class='fa fa-chevron-down']");
	public static final By reviewCollapse = By.cssSelector("span[data-target='#review_application'] i[class='fa fa-chevron-up']");
	public static By reviewDisclosureLink = By.cssSelector("div[data-analytics-asset-id='3673555'] h3 a");
	public static By reviewProductNotice= By.cssSelector("div[data-analytics-asset-id='2116082'] h3 a");
	public static By reviewApplication = By.cssSelector("a[test_id='review-popup']");
	public static By popupProductName = By.xpath("//span[contains(text(),'Policy')]/following-sibling::strong");
	public static final By reviewCloseButton = By.cssSelector("a[class='close-btn']");
	public static final  By congratulationsValidation = By
			.cssSelector("div[class='congratMsgInfo'] h1");
	public static By SignAndComplete = By.cssSelector("button[test_id='submit'] span");
	public static By SnnValues = By.cssSelector("input[test_id='ssn')]");
	public static By ApplicantName = By.cssSelector("span[id='name']");
	public static By ApplicantField = By.cssSelector("input[test_id='signature']");
	public static By ReviewSignatureContent = By.cssSelector("form[id='_CPReviewSubmit_INSTANCE_eE7r6lNoARb1_signSubmitForm'] div[class='txt-holder text-small text-gray'] p");
	public static By Reviewbackbutton = By.cssSelector("a[test_id='review_back']");
	public static By ReviewSignCompletebutton = By.cssSelector("button[test_id='submit'] span");
	public static By ReviewNoticeExpand = By.cssSelector("(a[href='#collapseReviewOne'] span[class='text']");
	public static By ReviewProductNotice1 = By.cssSelector("div[data-analytics-asset-id='2116082'] h3 a");
	public static By ReviewCloseIcon = By.cssSelector("div[id='myModalTerms'] a[class='model-right-close-btn'] i");
	public static By ReviewCloseButton1 = By.cssSelector("div[id='myModalTerms'] button[id='pricingTermsbtn']");
	public static By ReviewYourApplicationExpand = By.cssSelector("a[href='#collapseReviewTwo'] span[class='text']");
	public static By ReviewYourApplicationLink = By.cssSelector("a[id='reviewApplication']");
	public static By ReviewYourApplicationCloseIcon = By.cssSelector("div[id='review-popup'] a[class='close-btn']");
	public static By ReviewYourApplicationCloseButton = By.cssSelector("div[id='review-popup'] a[class='btn btn-primary']");
	public static By PaymentDate = By.cssSelector("input[test_id='bankEffDate')]");
	public static By ADR = By.cssSelector("p[test_id='selectedAdoncoverage')]");
	public static By reviewApplicationH3 = By.cssSelector("a[id='review-PDF']");
	public static By popupFName = By.xpath("(//span[contains(text(),'Name')]/following-sibling::strong)[1]");
	public static By popupAddress = By.xpath("//span[text()='Address']/following-sibling::strong");
	public static By popupCity = By.xpath("//span[text()='City']/following-sibling::strong");
	public static By popupState = By.xpath("//span[text()='State']/following-sibling::strong");
	public static By popupZipcode = By.xpath("//span[text()='Zipcode']/following-sibling::strong");
	public static By popupStateOfBirth = By.xpath("//span[text()='State of Birth']/following-sibling::strong");
	public static By popupCountryOfBirth = By.xpath("//span[text()='Country of Birth']/following-sibling::strong");
	public static By popupOccupation = By.xpath("//span[text()='Occupation']/following-sibling::strong");
	public static By popupEmailAddress = By.xpath("//span[text()='Email Address']/following-sibling::strong");
	public static By popupPhoneNumber = By.xpath("//span[text()='Phone Number']/following-sibling::strong");
	public static By popupGender = By.xpath("//span[text()='Gender']/following-sibling::strong");
	public static By popupDOB = By.xpath("//span[text()='Date of Birth']/following-sibling::strong");
	public static By popupHeightFeet = By.xpath("//span[text()='Height (Feet)']/following-sibling::strong");
	public static By popupHeightInch = By.xpath("//span[text()='Height (inches)']/following-sibling::strong");
	public static By popupWeight = By.xpath("//span[text()='Weight (lbs)']/following-sibling::strong");
	public static By CPCPLLogo = By.cssSelector("img[data-fileentryid='2106427']");
	public static By CPStartNewQuoteLink = By.linkText("Start A New Quote");
	public static final By paymentMethod=By.cssSelector("div[class='payment_method'] strong");
	public static final By congratsCoverage=By.cssSelector("span[class='covAmount'], SPAN[class='covAmount']");
	public static final By congratsADR=By.cssSelector("span[class='adrVal'] ");
	public static final By congrtsRider=By.cssSelector("p[class='siwlRider riderDetails textLength']");
	
	// ------------------------------------Your Health-----------------------
	public static final By yourHealth_landing = By
			.xpath("//li[contains(@class,'current')]//strong[contains(text(),'Health Questions')]");
	public static final By yourHealth_healthQuestions_header = By.xpath("//h1[contains(text(),'some health questions')]");
	public static final By yourHealth_selectHeightFeet = By.cssSelector("select[test_id='heightInFeet'],SELECT[id='_CPHealthSurveytModule_INSTANCE_GKIzsrpIcf6f_heightInFeet']");
	public static final By yourHealth_selectHeightInches = By.cssSelector("select[test_id='heightInInches'],SELECT[test_id='heightInInches']");
	public static final By yourHealth_WeightPounds = By.cssSelector("input[test_id='weight'],INPUT[test_id='weight']");
	public static final By yourHealth_continue = By.cssSelector("button[test_id='healthBasicsTab_continue']");
	 public static final By KnockoutText=By.cssSelector("div[class='col-md-8 p-0'] h1");
	   public static final By ExitButton=By.xpath("//button[contains(text(),'Exit Application')]");
	   public static final String KNOCKOUTMESSAGE="We're sorry, you do not qualify for this coverage.";
	    public static final By medicalQuesiton_wheelchair = By.xpath("//INPUT[@test_id='No|BASE_UW_PILOT1']/following-sibling::label[1]");			
		public static final By medicalQuestion_OrganTransplant = By.xpath("//INPUT[@test_id='No|BASE_UW_PILOT2']/following-sibling::label[1]");
		public static final By HeightFeetError=By.xpath("//*[@text='Please enter your height (feet)']");
	    public static final By HeightInchesError=By.xpath("//*[@text='Please enter your height (inches)']");
	    public static final By WeightError=By.xpath("//*[@text='Please enter your weight (pounds)']");
	    public static final By medicalQuestion_AIDSInfection = By.xpath("//INPUT[@test_id='No|SPT2130_045']/following-sibling::label[1]");
		public static final By medicalSituation_Continue = By.cssSelector("button[test_id='MedicalSituationsTab_continue']");
		public static By medicalQuestion_Florida = By.xpath("//div[@class='col-md-8 col-lg-8']//p[contains(text(),'Have you been tested positive for exposure to HIV or been diagnosed as having ARC or AIDS caused by the HIV infection or other sickness or condition derived from such infection?')]");
	public static By medicalQuestion_FloridaNo=By.xpath("//INPUT[@test_id='No|SPT2130_065']/following-sibling::label[1]");
	public static By previous_medical_historyTab = By.cssSelector("div[id='MedicalHistoryTab'] li[class='active']");
	public static final By additionalQuestions = By.xpath("//div[contains(@class,'content_bg yes_or_no')]/h4[contains(text(),'Living Benefit Rider Questions')]");
	public static By additionalQuestions1 = By
			.xpath("//div[@id='MedicalHistoryTab']/following::li[contains(text(),'Living') and @class='active']");
	public static final By yourHealth_medicalHistoryContinue = By.cssSelector("button[test_id='MedicalHistoryTab_continue']");
	public static final By yourHealth_AdditionalQuestions_Continue = By
			.cssSelector("button[test_id='AdditionalQuestionsTab_continue']");
	
	public static By yourHealth_medicalHistoryABRContinue = By
			.cssSelector("button[test_id='MedicalHistoryTab_abr_continue']");
	public static By yourHealth_medicalHeader = By
			.xpath("//strong[contains(text(),'Health Questions') ]");
	public static final By GBLheader=By.xpath("//strong[contains(text(),'Guaranteed Acceptance Life Insurance')]| //STRONG[contains(text(),'Guaranteed Acceptance Life Insurance')] ");
	public static final By Medical_Question1=By.xpath("//li[@class='child_item current']//a[contains(text(),'Medical Questions Part 1')]");
	 public static final By medicalqa_wheelchair=By.xpath("//*[@text='No' and ./parent::*[./parent::*[./parent::*[(./preceding-sibling::* | ./following-sibling::*)[./*[@text='Are you currently, or have you within the past 3 years used a wheelchair, used oxygen, been confined to a hospital or nursing facility, received or receiving home health or hospice care, or been disabled due to an illness?']]]]]]");
	 public static final By medicalqs_organTrnasplant=By.xpath("//*[@text='No' and ./parent::*[./parent::*[./parent::*[(./preceding-sibling::* | ./following-sibling::*)[./*[@text='Have you ever had an organ transplant, been advised in the past 5 years by a member of the medical profession to have surgery which has not yet been performed or testing that has not been completed, or are you currently undergoing an evaluation or diagnos...']]]]]]");
	 public static final By medicalqs_AIDS=By.xpath("//*[@text='No' and ./parent::*[./parent::*[./parent::*[(./preceding-sibling::* | ./following-sibling::*)[./*[@text='Have you been diagnosed by a member of the medical profession with or received treatment for AIDS (Acquired Immune Deficiency Syndrome) or infection with HIV (Human Immunodeficiency Virus)?']]]]]]");  
	 // -------------------------------Your Profile -----------------
	public static By yourProfile_ = By.cssSelector("");
	public static By yourProfile_ProductName = By.cssSelector("p[test_id*='product_desc']");
	public static By yourProfile_productNameBanner = By.cssSelector(P_CONTAINS_CLASS_INS_HEADER);
	public static By yourProfile_totalPermium = By.cssSelector("p[test_id='total_primium_amount']");

	public static By yourProfile_expand = By.cssSelector("i[class='fa fa-angle-down radius_border']");
	public static By yourProfile_collapse = By.cssSelector("p[class='collapse_lnk']i");
	public static By yourProfile_CoverageAmount = By.cssSelector("p[test_id='coverage_amount']");
	public static By yourProfile_Unit = By.cssSelector("span[test_id='unit']");
	public static By yourProfile_BannerHeader = By.cssSelector("div[@id='count-panel']h3");
	// Update yourProfile_Back
	public static By yourProfile_Back = By.cssSelector("//a[class*='btn-back']");
	public static By OtherPolicies_Back = By.cssSelector("a[test_id='replaceBack']");
	public static By yourProfile_Continue = By.cssSelector("button[test_id*='btn_continue']");
	public static By yourProfile_AddOns = By.cssSelector("a[test_id='plan_heading_link']");
	// For No thanks Button updated from //Button to //a
	public static By yourProfile_NoThanks = By.cssSelector("a[id*='no']");
	// For No thanks Button updated from //Button to //a
	public static By yourProfile_ContinueAdr = By.cssSelector("a[id*='adr_dialog_continue']");
	public static By yourProfile_customize = By.cssSelector("span[id='customCover']");
	public static By remove = By.cssSelector("p[class='remove_rider']");
	public static By ADR_Rider = By.cssSelector("div[id='AdOnPremium-ADR-Section'] p[class='base_plan_type']");
	public static By TellMeYourSlef = By.cssSelector("div[class='basic_person_details'] p[class='stmt_qute blue_stmt']");
	public static By BasicDetails = By.cssSelector("div[class='living_benefit_product_container'] div[class='more_info_about_product clearfix'] p:nth-of-type(1)");
	// -----------------------------------------------yourBasics----------------------------------------
	public static final By yourBaicsHeader = By.xpath("//h1[contains(text(),'Your application')]");
	public static final By GBLEnabled=By.cssSelector("div[class='gbl_card quote_product_card col-md-4 col-lg-12 product-item active'],DIV[class='gbl_card quote_product_card col-md-4 col-lg-12 product-item active']");
	public static By yourBasics_addSomePeaceOfMind = By
			.cssSelector("div[id='add-living-benefit-popup'] div[class='popup-heading'] h2");
	public static By yourBasics_addAccidentalDeathRider = By.cssSelector(
			"div[id='add-accidental-popup'] div[class='popup-heading'] h2");
	
	public static By yourBasics_addAccidentalDeathRider1 = By
			.cssSelector("div[id='add-accidental-popup'] div[class='popup-heading'] h2");
	public static By yourBaics = By.cssSelector("(div[class='col-xs-12 col-sm-8 col-md-8 col-lg-8 guarantee_one row'] h1");
	public static By yourbasics_productHeader = By.cssSelector("(p[test_id='product_desc'])");
	// "(//div[contains(@class,'HeaderProductBuyingField')]/descendant::span[contains(@class,'cno_cpl')])[1]
	// |
	
	public static By ExistingCustomerPopUp = By.cssSelector("div[id='limited-popup'] h2");
	public static By ECustContinueButton = By.cssSelector("a[id='adr_dialog_continue']");

	public static By yourbasics_coverageAmount = By.cssSelector("span[test_id='base_plan_coverage']");
	public static final By yourbasics_premium = By.cssSelector("p[test_id='product_premium']");
	public static final By yourbasics_adr = By.cssSelector("span[test_id='adr_coverage']");
	public static final By yourbasics_abr = By.cssSelector("span[test_id='abr_name']");
	public static By yourbasics_fname = By.cssSelector(INPUT_TEST_ID_FIRST_NAME);
	public static By yourbasics_lname = By.cssSelector(INPUT_TEST_ID_LAST_NAME);
	public static By yourbasics_dob = By.cssSelector(INPUT_TEST_ID_BIRTH_DAY);
	public static By yourbasics_dobtoWrite = By.cssSelector(INPUT_TEST_ID_BIRTH_DAY);

	
	public static By yourbasics_Address = By.cssSelector("input[test_id='addressLine1']");
	public static By YB_AddressLine1 = By.cssSelector("input[test_id='addressLine1']");
	
	public static By yourbasics_city = By.cssSelector(INPUT_TEST_ID_CITY);
	public static By yourbasics_ZipCode = By.cssSelector(INPUT_TEST_ID_ZIP_CODE);
	public static By yb_Occupation_DropDown = By.cssSelector(SELECT_TEST_ID_OCCUPATION);
	public static By yourbasics_Living_Benefit_Rider_Pop = By.cssSelector(SELECT_TEST_ID_OCCUPATION);
	public static By yourbasics_CommunicationDetails = By.cssSelector(
			"div[class='person_contact_info_wrapper col-xs-12 col-sm-6 col-md-6 col-lg-6 padding_side_0px'] p");
	public static By yourbasics_EmailAddress = By
			.cssSelector("div[class='person_contact_info_wrapper col-xs-12 col-sm-6 col-md-6 col-lg-6 padding_side_0px'] p:nth-of-type(4)");
	public static By yourbasics_PhoneNumber = By
			.cssSelector("div[class='person_contact_info_wrapper col-xs-12 col-sm-6 col-md-6 col-lg-6 padding_side_0px'] p:nth-of-type(5)");
	public static By startnewQuote_Button = By.cssSelector("div[class='nav-link'] span");
	public static final By yourbasics_continue = By.cssSelector(BUTTON_CONTINUE);
	public static By yourbasics_back = By.cssSelector("a[class='btn btn-md btn-default btn-back']");
	public static By yourbasics_ADRValue = By.cssSelector("p[test_id='selectedAdoncoverage']");
	public static By yourbasics_editIcon = By.cssSelector("(a[id='editExistingBasicDetails'] span");
	public static By yourbasics_ADRRider = By.cssSelector("a[id='adr_rider_popup_trigger']");
	public static By yourbasics_Living_Benefit_Rider = By.cssSelector(
			"div[class='take_to_abr_link rider_link clearfix'] a[test_id='plan_heading_link']");
	public static By yourbasics_addAndContinue = By.cssSelector("a[onclick='noThanks(event)']+a");
	public static By yourbasics_plusIcon = By.cssSelector("span[test_id='coverage_incre_adr']");
	public static By yourbasics_minusIcon = By.cssSelector("span[test_id='coverage_decre_adr']");
	public static By yourbasics_save = By.cssSelector("button[test_id='saveChanges']");
	
	//yourbasics_addAndContinue
	
	public static By yourbasics_stroke = By.cssSelector("input[id*='Heart')]");
	public static By yourbasics_cancer = By.cssSelector("input[id*='Cancer']");
	public static By yourbasics_cancer1 = By.cssSelector("input[id*='Cancer']");
	public static By yourbasics_chronic = By.cssSelector("input[id*='Chronic']");
	public static final By yourbasics_Occupation = By.xpath("//select[@test_id='occupation']|//SELECT[@id='_CPPersonalDetailsModule_INSTANCE_4nziR2ApJipe_occupation']");
	public static final By yourbasics_Country = By.cssSelector("select[test_id='birthCountry']");
	public static final  By yourbasics_State = By.cssSelector("select[test_id='birthState'], SELECT[test_id='birthState']");
	public static By yourBasic_PhoneNumber = By.cssSelector("input[test_id*='phone')]");
	public static final By Yourbasics_GBLcontinue=By.cssSelector(BUTTON_CONTINUE);
	public static final String yourCov_Subwaystop = "//a[text()='pageTitle']/parent::div/parent::li";
	// ----------------------GBL Product page--------------------
	public static By gbl_GreetingText = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116886_H3);
	public static By product_carousel_added = By.xpath("//p[contains(text(),'Added')]");
	public static By product_carousel_apply = By.xpath("//p[contains(text(),'Apply')]");
	public static By product_carousel_tryit = By.xpath("//p[contains(text(),'Try')]");

	// ------------------------SIWL Product page------------------
	public static By SIWL_GreetingText = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116905_H3);

	// ------------------------T90 Product Page---------------------
	public static By tninety_GreetingText = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116924_H3);

	// ---------------------------siwl and t90 living insurance-------------
	public static By siwlLivingInsurance = By.cssSelector("div[class='living_insuarance_logo_container'] +h2");
	public static By tNinetyLivingInsurance = By.cssSelector("div[class='living_insuarance_logo_container'] +h2");
	public static By livingInsurance = By.cssSelector("div[data-analytics-asset-id='2113478'] div[class='row']+div span");

	// --------------------------------Insurance page-------------------
	public static By InsuranceGBLBanner = By.cssSelector("a[href='/guaranteedacceptance'] h4");
	public static By InsuranceGBLGetQuote = By.cssSelector(
			"div[class='col-xs-12 col-md-8 col-sm-8 col-lg-8 default_product_button_container'] button[onclick*='guaranteedacceptance']+button");
	public static By InsuranceBGLLearnMore = By.cssSelector(
			"div[class='col-xs-12 col-md-8 col-sm-8 col-lg-8 default_product_button_container'] button[onclick*='guaranteedacceptance']");
	public static By InsuranceSIWLBanner = By
			.cssSelector("div[data-analytics-asset-id='2267046'] a[href='/wholelife']");
	public static By InsuranceSIWLGetQuote = By.cssSelector(
			"div[class='col-xs-12 col-md-8 col-sm-8 col-lg-8 default_product_button_container'] button[onclick*='SIWL&flow']");
	public static By InsuranceSIWLLearnMore = By.cssSelector(
			"div[class='col-xs-12 col-md-8 col-sm-8 col-lg-8 default_product_button_container'] button[onclick*='/wholelife']");
	public static By InsuranceTNinetyBanner = By.cssSelector("div[data-analytics-asset-id='2267176'] a");
	public static By InsuranceTninetyGetQuote = By.cssSelector("button[onclick*='T90&flow']");
	public static By InsuranceTninetyLearnMore = By.cssSelector("button[onclick*='termlife']");
	public static By InsuranceTninetyLivingBanner = By.cssSelector("div[data-analytics-asset-id='2110758'] a");
	public static By InsurancePermanentLivingBanner = By.cssSelector("div[data-analytics-asset-id='2110751'] a");
	public static By InsurancepermanentLivingGetQuote = By.cssSelector("button[onclick*='SIWL&abr=true&flow=quote']");
	public static By InsurancepermanentLivingLearnMore = By.cssSelector("/button[onclick*='wholelife-livinginsurance']");
	public static By InsuranceRenewableLivingGetQuote = By.cssSelector("button[onclick*='T90&abr=true&flow=']");
	public static By InsuranceRenewableLivingLearnMore = By.cssSelector(
			"button[onclick*='termlife-livinginsurance']");
	public static By comparePlans = By.xpath("//button[contains(text(),'Compare')]");
	public static By state = By.cssSelector(SELECT_TEST_ID_STATE_SELECTION);
	public static By dob = By.cssSelector(INPUT_TEST_ID_BIRTH_DAY);
	public static By GBL_InsuranceLandingPage = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116886_H3);
	public static By PWL_InsuranceLandingPage = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116905_H3);
	public static By T90_InsuranceLandingPage = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116924_H3);
	public static By LivingPWL_InsuranceLandingPage = By.cssSelector("div[data-analytics-asset-id='2116943'] h3");
	public static By LivingT20_InsuranceLandingPage = By.cssSelector("div[data-analytics-asset-id='2116958'] h3");

	// ----------------------------------------Fields------------------------------
	public static By FieldFirstName = By.cssSelector("input[id*='first']");
	public static By FieldLastName = By.cssSelector("input[id*='last']");			
	public static By FieldBirthDay =By.cssSelector("input[id*='date']");			
	public static By FieldState = By.cssSelector("select[id*='state']");
	public static By FieldEmail = By.cssSelector("input[id*='email']");
	public static By bannerMyQuote = By.cssSelector("button[id*='Myquote']");

	// -------------------------------Common-------------------------
	public static By getMyQuoteInsurance = By.cssSelector("a[test-id*='plan']");
	public static By newYorkResidentContent = By.cssSelector("a[id='stateLink']");

	// ----------------------------------Contact us--------------------
	public static By NYResident = By.cssSelector("a[id='Ny-resident'] button[class*='ny_resident_btn']");

	// -------------------------------------------------------HomePage--------------------------------------

	public static By Getquote_Button=By.xpath("//div[@class='main_banner_overlay_container col-12  animate_bgstate']//button[@class='linkAnimatetxtarrow']");
	public static By homePage_ContactUs = By.cssSelector("(ul[id='bqrk_'] a[href='/contact-us']");
	public static By caNotification = By.cssSelector("//*[@id='onetrust-policy-title']");
	public static By caNotificationClose = By.xpath("//*[@nodeName='BUTTON' and ./parent::*[@id='onetrust-close-btn-container-mobile']]");
	public static By homepage = By.cssSelector("a[href='/home']");

	public static By homePage_GlobalGetQuote = By.cssSelector("div[class='collapse navbar-collapse'] button[id='header-getquote']");
	public static By homePage_LocalGetQuote = By.cssSelector(BUTTON_TEST_ID_QUOTE_FILTER_BUTTON);
	public static By homePage_DOBField = By.cssSelector(INPUT_TEST_ID_BIRTH_DAY);
	public static By homePage_selectState = By.cssSelector(SELECT_TEST_ID_STATE_SELECTION);
	public static By homePage_LearnMore_GBL = By
			.cssSelector("a[test-id='plan-selection-getquote-GBLU']+button");
	public static By homePage_LearnMore_SIWL = By
			.cssSelector("a[test-id='plan-selection-getquote-NWL']+button");
	public static By homePage_LearnMore_T90 = By
			.cssSelector("a[test-id='plan-selection-getquote-NTP']+button");
	public static By homePage_ViewAllLifeInsurance = By.cssSelector("");
	public static By homepage_ViewAllLivinngInsuranceBannerlink = By
			.cssSelector("div[class*='two_section'] a[href='/livinginsurance']");
	public static By homepage_GBLBannerLink = By.cssSelector("div[class='product_one'] h4 a[@href='/guaranteedacceptance']");
	public static By nygotit = By.xpath("//button[contains(text(),'Got')]");
	public static By homePage_ComparePlans = By.cssSelector("");
	public static By homePage_NYLifechoice = By.cssSelector("h4 a[href='/lifechoice']");
	public static By homePage_InsuranceGBL = By.cssSelector("div[class='product_one'] h4 a[href='/guaranteedacceptance']");
	public static By homePage_InsuranceSIWL = By.cssSelector("div[class='product_one'] h4 a[href='/wholelife']");
	public static By homePage_InsuranceT90 = By.cssSelector("(div[class='product_one'] h4 a[href='/termlife']");
	public static By homepage_InsuranceLivingSIWL = By.cssSelector("div[class='product_one'] h4 a[href='/wholelife']");
	public static By homePage_InsuranceLivingT90 = By.cssSelector("div[class='product_one'] h4 a[href='/termlife']");
	public static By homePage_TheRightchoice = By.cssSelector("li[class='col-md-3 col-sm-3'] a[href='/rightchoice']");
	public static By homePage_Insurance = By.cssSelector("(div[id='bs-example-navbar-collapse-1'] a[href='/insurance']");
	public static By homePage_FooterGBL = By.cssSelector("div[class='footer_ul_content'] a[href='/guaranteedacceptance']");
	public static By homePage_FooterSIWL = By
			.cssSelector("div[class='footer_ul_content'] a[href='/wholelife']");
	public static By homePage_FootersT90 = By
			.cssSelector("div[class='footer_ul_content'] a[href='/termlife']");
	public static By homePage_DOBWarning = By.cssSelector("input[test_id='birthDay']+div span");
	public static By homePage_StateWarning = By
			.cssSelector("select[test_id='stateSelection']+div span");
	public static By NoticeandDiscState = By.cssSelector(SELECT_ID_DISCLOSURE_STATE);
	public static By notice_disclosure = By.linkText("Notices & Disclosures");
	
	public static By homePage_NewYorkResident = By.cssSelector("(p:has[>(span[class='ny_res_nrml_txt'])])nth-of-type(1)");
	public static By homepage_NewYorkResidentBanner = By.cssSelector("");
	public static By homePage_GlobalGetQuoteSpan = By.cssSelector(BUTTON_TEST_ID_QUOTE_FILTER_BUTTON);
	public static By homePage_selectState_id = By.cssSelector("select[id*='gender')]");
	public static By ContactUs_Link = By.linkText("Contact Us");
	public static By ContactUsNY = By.cssSelector("button[id='contactNY']");
	public static By Notice_Download_Button = By.cssSelector("button[class='view_doc_button']");
	public static By NoticeAndDisclusorestate = By.cssSelector(SELECT_ID_DISCLOSURE_STATE);
	public static By homePage_InsuranceDropDown = By.cssSelector(SELECT_ID_DISCLOSURE_STATE);
	public static By Spanish_Comp=By.xpath("//h1[contains(text(),'Hablamos ')]");
	public static By Spanish_Explore=By.cssSelector("button[onclick='spanishLink()']");
	public static By Spanish_Heading=By.xpath("//h1[contains(text(),'Encuentra')]");
	// -----------------------------------Insurance drop Down
	// Values--------------------------------
	public static By IDD_LifeInsurance = By.cssSelector("");
	public static By IDD_GBL = By.cssSelector("");
	public static By IDD_SIWL = By.cssSelector("");
	public static By IDD_TNinety = By.cssSelector("");
	public static By IDD_LivingInsurance = By.cssSelector("");
	public static By IDD_SIWLLiving = By.cssSelector("");
	public static By IDD_TNinetyLiving = By.cssSelector("");
	public static By Insurance_dropdown_all = By
			.cssSelector("li[class='col-md-2 col-sm-3 ins_hover_section'] i[class='fa fa-angle-down arw-down']");

	// -------------------------------------product
	// Quotepage-------------------------
	
	public static By GQSelectionPage_Price_GBL = By
			.cssSelector("div[data-analytics-asset-id='2116886'] span");
	public static By GQSelectionPage_Price_SIWL = By
			.cssSelector("div[data-analytics-asset-id='2116905'] span");
	public static By GQSelectionPage_Price_T90 = By
			.cssSelector("div[data-analytics-asset-id='2116924'] span");
	public static By GQSelectionPage_Price_SIWL_Living = By
			.cssSelector("div[data-analytics-asset-id='2116943'] span");
	public static By GQSelectionPage_Price_T90_Living = By
			.cssSelector("div[data-analytics-asset-id='2116958'] span");
	public static By GQSelectionPage_DOBField = By.cssSelector(INPUT_CONTAINS_CLASS_DATE);
	public static By GQSelectionPage_selectState = By.cssSelector(SELECT_TEST_ID_STATE_SELECTION);
	public static By GQSelectionPage_GotIt = By.cssSelector("div[data-analytics-asset-id='2110897'] button[class='close-btn']");
	public static By GQSelectionPage_ViewMyOptions = By.cssSelector(BUTTON_TEST_ID_QUOTE_FILTER_BUTTON);

	public static By GQSelectionPage_GetQuoteGBL = By.cssSelector("a[test-id='plan-selection-getquote-GBLU'] button[class^='col']");

	public static By GQSelectionPage_GetQuoteT90 = By.cssSelector("a[test-id='plan-selection-getquote-NTP'] button[class^='col']");

	public static By GQSelectionPage_GetQuoteSIWL = By.cssSelector("a[test-id='plan-selection-getquote-NWL'] button[class^='col']");
	public static By GQSelectionPage_ApplyGBL = By.cssSelector("a[test-id='plan-selection-getquote-GBLU]");


	public static By GQSelectionPage_ApplySIWL = By.cssSelector("a[test-id='plan-selection-getquote-NWL'] button[class^='col']");
	public static By GQSelectionPage_ApplyT90 = By.cssSelector("a[test-id='plan-selection-getquote-NTP']button");

	public static By GQSelectionPage_GetQuoteLifeChoice = By.cssSelector("a[test-id='plan-selection-getquote-LC']button");

	public static By GQSelectionPage_GetQuoteSIWLLiving = By
			.cssSelector("a[test-id='plan-selection-getquote-SILI'] button[class^='col']");

	public static By GQSelectionPage_GetQuoteT90Living = By
			.cssSelector("a[test-id='plan-selection-getquote-NTPLI'] button[class^='col']");
	public static By GQSelectionPage_ApplyLifeChoice = By.cssSelector("a[test-id='plan-selection-downloadapp-LC']button");
	public static By GQSelectionPage_ApplySIWLLiving = By.cssSelector("a[test-id='plan-selection-apply-SILI']button");
	public static By GQSelectionPage_ApplyT90Living = By.cssSelector("a[test-id='plan-selection-apply-NTPLI']button");

	public static By GQSelectionPage_BannerGBL = By
			.cssSelector("div[data-analytics-asset-id='2116886'] div[class='col-md-7 col-sm-7 col-lg-7']");

	public static By GQSelectionPage_BannerSIWL = By
			.cssSelector("div[data-analytics-asset-id='2116905'] div[class='col-md-7 col-sm-7 col-lg-7']");

	public static By GQSelectionPage_BannerT90 = By
			.cssSelector("div[data-analytics-asset-id='2116924'] div[class='col-md-7 col-sm-7 col-lg-7']");
	public static By GQSelectionPage_BannerLifeChoice = By
			.cssSelector("div[data-analytics-asset-title='PlanSelectionTile_LC'] h3");

	public static By GQSelectionPage_BannerSIWLLiving = By
			.cssSelector("div[data-analytics-asset-id='2116943'] div[class='col-md-7 col-sm-7 col-lg-7']");
	public static By GQSelectionPage_BannerT90Living = By
			.cssSelector("div[data-analytics-asset-id='2116958'] div[class='col-md-7 col-sm-7 col-lg-7']");
	public static By GBLQuote_GreetingText = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116886_H3);
	public static By SIWLLQuote_GreetingText = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116905_H3);
	public static By T90Quote_GreetingText = By.cssSelector(DIV_DATA_ANALYTICS_ASSET_ID_2116924_H3);
	public static By LivingSIWLLQuote_GreetingText = By.cssSelector("div[data-analytics-asset-id='2116943'] img");
	public static By T90Living_GreetingText = By.cssSelector("div[data-analytics-asset-id='2116958'] img");

	public static By GBL_HeaderLearnMoreExpand = By.cssSelector("p[test_id='product_expand'] span");

	public static By GBL_ProductLMButton = By.cssSelector("a[test_id*='product_learn_more']");
	public static By LifeChoice_GreetingText = By.cssSelector("h4 a[href='/lifechoice']");

	// ----------------------------------------Get Quote//
	// page--------------------------------------
	public static By headerValidation = By.cssSelector("div[class='container-fluid '] h1[class='hide-accessible']");
	public static String pricingAndTerms = "(//a[contains(text(),'Pricing')])[$]";
	public static By GQIneligible_GBL = By.cssSelector("");
	public static By ReturnToSelectionButton = By.cssSelector("");
	public static By QRPageEditBasicDetailLink = By.cssSelector("P[test_id='basic_details_learn_more'] span");
	public static By EditYourBasicDetails = By.cssSelector("a[test_id='edit_basic_details'] span");
	public static By QuotePage_StartANewQuoteButton = By.xpath("(//button[contains(text(),'Start')])[2]");
	// ------------------------------------Basic Details Section
	// ---------------------------------------
	public static final String GENDER="select[test_id='gender']";
	public static By productName = By.cssSelector("div[class*='guarantee_one')] h2");
	public static By GQPage_BasicDetails = By.cssSelector("div[class='get_quote_form_wrapper_container '] p[class='basic']");
	public static By GQPage_FirstName = By.cssSelector(INPUT_TEST_ID_FIRST_NAME);
	public static By GQPage_LastName = By.cssSelector(INPUT_TEST_ID_LAST_NAME);
	public static By GQPage_BirthDay = By.cssSelector("input[@test_id='dateOfBirth']");
	public static By GQPage_Gender = By.cssSelector(GENDER);
	public static By GQPage_PhoneNumber = By.cssSelector("input[test_id='phone']");
	public static By GQPage_Email = By.cssSelector("input[test_id='emailAddr']");
	public static By GQPage_FirstNameError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_firstNameHelper'] span");
	public static By GQPage_LastNameError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_lastNameHelper'] span");
	public static By GQPage_BirthDayError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_datepicker_1Helper'] span");
	public static By GQPage_GenderError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_genderHelper'] span");
	public static By GQPage_EmailError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_emailAddressHelper'] span");
	public static By GQPage_PhoneNumberError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_phoneNumberHelper'] div");
	public static By GQ_City = By.cssSelector(INPUT_TEST_ID_CITY);
	public static By GQ_ZipCode = By.cssSelector(INPUT_TEST_ID_ZIP_CODE);
	public static By GQPage_ZipError = By.cssSelector("");
	public static By GQPage_Address = By.cssSelector("input[name*='Line1']");
	public static By GQPage_Address2 = By.cssSelector("input[test_id=addressLine2]");
	public static By GQPage_State_LocationTab = By.cssSelector("(select[id='_CPQuote_INSTANCE_anxk42PWZqCh_stateCode']");
	public static  By pLapsedesc=By.cssSelector("p[class='laspe-desc col-md-8']");
	public static  By lapselearn=By.xpath("//a[contains(text(),'Learn more about this form')]");
	public static  By Designeefirst=By.cssSelector("input[test_id='firstName']");
	public static  By Designeelast=By.cssSelector("input[test_id='lastName']");
	public static By DesigneeAddress=By.cssSelector("input[id='_CPAddressDetailsModule_INSTANCE_WW3qLZqJJS20_informLapsAddress']");
	public static  By DesigneeCity=By.cssSelector("input[id='_CPAddressDetailsModule_INSTANCE_WW3qLZqJJS20_informLapsCity']");
	public static By DesigneeState=By.xpath("//select[@class='form-control informLapsState placeholder select2-hidden-accessible onlyPlaceHolder']");
	public static By Designeezip=By.cssSelector("input[id='_CPAddressDetailsModule_INSTANCE_WW3qLZqJJS20_informLapsZipCode']");
	public static By Phonenumber=By.cssSelector("input[test_id='phone']");
	public static By DesiRelation=By.cssSelector("select[test_id='informLapsRelation']");
	
	public static By gblBirthDay = By.cssSelector("input[test_id=dateOfBirth]");
	public static By GQPage_State_LocationTab_Error = By
			.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_stateCodeHelper'] span");
	public static By GQPage_CoverageAmount = By.cssSelector("select[id*='coverage']");
	public static By GQPage_ADRRiderDD = By.cssSelector("select[title*='accidental-death-rider']");
	public static By GQPage_LivingRider = By.cssSelector("");
	public static By GQPage_LocationExpand = By
			.xpath("//p[contains(text(),'Where')]/parent::div/following-sibling::p[1]/a");
	public static By GQPage_LocationDismiss = By
			.xpath("//p[contains(text(),'Where')]/parent::div/following-sibling::p[1]/a");	
	public static By GQPage_Arrowvalue = By
			.xpath("//p[contains(text(),'Where')]/parent::div/following-sibling::p[1]/a/label");
	public static By GQPage_ArrowvalueLearnMore = By.cssSelector("p[test_id='product_expand'] span");	
	public static By GQPage_SelectRider = By.cssSelector("select[title*='living']");	
	public static final By GQPAGE_DOWNLOADAPPLICATION = By.cssSelector("button[test_id='download_btn'],BUTTON[test_id='download_btn']");
	public static final By GQPage_Download_quotePanel= By.cssSelector("button[test_id='download_btn_quote_panel']");
	public static By GQPage_totalMonthlyPremium = By.cssSelector("div[class='col-xs-6 mobile_padding_0'] p[class*='no_quote_amount']");
	public static By GQPage_coverageAmount1 = By.cssSelector("div[class='col-xs-5 mobile_padding_0'] p[class*='no_quote_amount']");
	public static By GQpage_gblCoverageAmountDD = By.cssSelector("select[id*='coverageAmount']");
	public static By PolicyQuote_SendMeEmail = By.cssSelector("button[test_id=sendMeThisQuote] > span");
	public static By PolicyQuote_PopupHeading = By.cssSelector("div#emailTriggerPopUp h2:nth-of-type(1)");
	public static By emailQuote_continue = By.cssSelector("a[id*=emailTrigger_continue]");
	public static By baseCov = By.cssSelector("p#basePlanCoverageAmount");
	public static By monthlyPre = By.cssSelector("p#totalSelectedadOnPremiumOnscreen");
	
	public static By GQpage_reviewBasicdetails = By.cssSelector("p[test_id=basic_details_learn_more] > span");
	public static By GQpage_editBasicdetails = By.cssSelector("a[test_id=edit_basic_details]");
	
	public static By GQpage_GBLCoverageAmount = By.cssSelector("button[onclick*='GBLU']");
	public static By GQpage_NTPCoverageAmount = By.cssSelector("a[test-id*='apply-NTP')] button");
	public static By GQpage_SILICoverageAmount = By.cssSelector("a[test-id*='apply-SILI')] button");
	public static By GQpage_NTPLICoverageAmount = By.cssSelector("a[test-id*='apply-NTPLI')] button");
	public static By GQpage_APT = By.cssSelector("input[name*='Line2']");
	public static By Label_Occupation = By.cssSelector("label[for='_CPProductBuyingModule_INSTANCE_hZ4DyMtiZ8mc_occupation']");
	public static By Label_Country = By.cssSelector("label[for='_CPProductBuyingModule_INSTANCE_hZ4DyMtiZ8mc_birthCountry']");
	public static By Label_StateOfBirth = By.cssSelector("label[for='_CPProductBuyingModule_INSTANCE_hZ4DyMtiZ8mc_birthState']");
	public static By Label_CountryDropDown = By.cssSelector("select[test_id*='birthCountry']");
	public static By Label_occupation1 = By.cssSelector("select[test_id*='occupation']");
	public static By Label_birthState = By.cssSelector("select[test_id*='birthState']");
	public static By ErrorMsg_Occupation = By.cssSelector("div[id='_CPProductBuyingModule_INSTANCE_hZ4DyMtiZ8mc_occupationHelper'] div");
	public static By ErrorMsg_Label_Country = By.cssSelector("div[id='_CPProductBuyingModule_INSTANCE_hZ4DyMtiZ8mc_birthCountryHelper'] div");
	public static By ErrorMsg_Label_BirthState = By
			.cssSelector("div[id='_CPProductBuyingModule_INSTANCE_hZ4DyMtiZ8mc_birthStateHelper'] div");
	public static By Occupation_DropDown = By.cssSelector("select[test_id*='occupation']");
	public static By ExpandViewFullDetails = By.xpath("//span[contains(text(),'View Full Details')]");
	public static By AdrLink = By.cssSelector("p[id='addADRBenefitRider']");
	public static By AdrHeading = By.xpath("//h2[contains(text(),'Add an accidental death rider to your policy')]");
	public static By PricingandTerms1 = By.xpath("(//a[contains(text(),'Pricing and Terms')])[2]");
	public static By NoThanks = By.cssSelector("a[id='adr_dialog_nothanks']");
	public static By AddContinue = By.cssSelector("a[id='adr_dialog_continue']");
	public static By PopUpADRAmt = By.cssSelector("strong[test_id='adr_modalAmt']");
	public static By PopDecButton = By.cssSelector("button[test_id='adr_pop_decre']");
	public static By PopIncButton = By.cssSelector("button[test_id='adr_pop_incre']");
	public static By PopCloseIcon = By.xpath("//button[@type='button' and @title='Close']");
	public static By ABRLink = By.xpath("//a[contains(text(),'Add Living Benefit Rider')]");
	public static By ABRHeading = By.xpath("//h2[contains(text(),'Add some peace of mind to your policy')]");
	public static By ABRADDTHISRIDER = By.xpath("//span[contains(text(),'ADD THIS RIDER')]");
	public static By ABRHeart = By.xpath("//strong[contains(text(),'Heart attack/stroke')]");
	public static By ABRCancer = By.xpath("//strong[contains(text(),'Cancer')]");
	public static By ABRChronicIllness = By.xpath("//strong[contains(text(),'Chronic Illness')]");
	public static By AbrNoThanks = By.cssSelector("a[id='abr_dialog_nothanks']");
	public static By AbrAddContinue = By.cssSelector("a[id='abr_dialog_continue']");
	public static By EarlyPayoutBenefit = By.xpath("(//strong[@class='value percent'])[1]");
	public static By ABRRADIOButton = By.xpath("(//span[@class='fake-radio'])[1]");
	public static By getPercentageABR = By.cssSelector("span[id='lvngTypeText']");
	public static By ABRRemove = By.cssSelector("p[id='removeAbrRider']");
	public static By ADRAddContinue = By.xpath("(//a[@id='adr_dialog_continue'])[2]");

	// --------------------------Product name From
	// Header------------------------------------------------------------
	public static By GQPage_ProductNameHeader = By.xpath("//div[contains(@class,'guarantee')]/h2");
	public static By GQPage_ProductNameGBL = By.cssSelector("");
	public static By GQPage_ProductNameSIWL = By.cssSelector("");
	public static By GQPage_ProductNameT90 = By.cssSelector("");

	// ---------------------------------------Quotepanel----------------------------------------------------------------
	public static By QPanel_GetMyQuote = By.xpath("//button/span[contains(text(),'Get')]");
	public static By QPanel_GetMyQuoteBottom = By.cssSelector("button[test_id='get_my_quote']");
	public static By QPanel_UpdateQuote = By.xpath("//span[contains(text(),'Update Quote')]");
	public static By Qpanel_BasePlan = By.xpath("(//p[@class='plan_name'])[1]");
	public static By Qpanel_Premium = By.cssSelector("p[id='totalSelectedadOnPremiumOnscreen']");
	public static By QPanel_AddOns = By.cssSelector("");
	public static By QPanel_UpdateQuoteBottom = By.cssSelector("button[test_id='update_quote_results_btn'] span");

	// -----------------------------------------Your Policy
	// Quote-----------------------------------------------
	public static By PolicyQuote_productName = By.cssSelector(P_CONTAINS_CLASS_INS_HEADER);
	public static By PolicyQuote_Coverage = By.cssSelector("p[class*='base_plan_amount']");
	public static By PolicyQuote_ADR = By.cssSelector("select[name*='accidentalDeathRider']");
	public static By PolicyQuote_PolicyAddOns = By.cssSelector("");
	public static By PolicyQuote_ABRDropDown = By.cssSelector("select[name*='livingBenefitRider']");
	public static By PolicyQuote_ABRDropDownCl = By.xpath("//*[@id='_CPQuote_INSTANCE_jP47cGBSeCud_livingBenefitRider']");
	
	public static By PolicyQuote_LivingBenefit = By.xpath("//*[contains(@text,'Living Benefit Selection')]| //*[@text='Living Benefit Selection']");
	public static By PolicyQuote_Cancer = By.cssSelector("");
	public static By PolicyQuote_ChronicIllness = By.cssSelector("");
	public static By PolicyQuote_HeartAttack = By.cssSelector("");
	public static By PolicyQuote_Apply = By.xpath("(//span[contains(text(),'Apply')])[2]");
	public static By PolicyQuote_ApplyBottom = By.xpath("(//span[contains(text(),'Apply')])[1] | //*[@id='_CPQuote_INSTANCE_jP47cGBSeCud_applyBottom'] ");
	
	// --------------------------------Insurance page
	// ---------------------------------
	public static By InsPage_Header = By.cssSelector("");
	public static By InsPage_GBL_GetQuote = By.cssSelector("");
	public static By InsPage_SIWL_GetQuote = By.cssSelector("");
	public static By InsPage_TNinety_GetQuote = By.cssSelector("");
	public static By InsPage_SIWLLiving_GetQuote = By.cssSelector("");
	public static By InsPage_TNinetyLiving_GetQuote = By.cssSelector("");
	public static By InsPage_LifeChoice_GetQuote = By.cssSelector("");
	public static By InsPage_GBLName = By.cssSelector("");
	public static By InsPage_SIWLName = By.cssSelector("");
	public static By InsPage_TNinetyName = By.cssSelector("");
	public static By InsPage_SIWLLivingName = By.cssSelector("");
	public static By InsPage_TNinetyLivingName = By.cssSelector("");
	public static By InsPage_LifeChoiceName = By.cssSelector("");
	public static By InsPage_ShowOptions = By.cssSelector("");
	public static By InsPage_BDay = By.cssSelector(INPUT_CONTAINS_CLASS_DATE);
	public static By InsPage_State = By.cssSelector(SELECT_TEST_ID_STATE_SELECTION);
	public static By InsPage_Link = By.linkText("Insurance");
	// -------------------Life Choice Insurance------------------------
	public static By LifeChoiceInsurance = By.xpath("//h3[contains(text(),'LifeChoice')]");

	// --------------------------------Right Choice page
	// ---------------------------------
	public static By RCPage_Header = By.cssSelector("");
	public static By pricingAndTermsClose = By.cssSelector("button[id='pricingTermsbtn']");
	public static By RCPage_GBLName = By.cssSelector("a[href='/guaranteedacceptance'] p[class='guarantee_ins_head']");
	public static By RCPage_SIWLName = By.cssSelector("a[href='/wholelife'] p[class='guarantee_ins_head']");
	public static By RCPage_TNinetyName = By.cssSelector("a[href='/termlife'] p[class='guarantee_ins_head']");
	public static By RCPage_LivingInsuranceName = By.cssSelector("div[data-analytics-asset-id='2344700'] p[class='living_ins_head']");
	public static By RCPage_GBL_GetMyQuote = By
			.cssSelector("div[class='btns_section'] button[onclick*='GBL&flow']");
	public static By RCPage_SIWL_GetMyQuote = By
			.cssSelector("div[class='btns_section'] button[onclick*='SIWL&flow']");
	public static By RCPage_TNinety_GetMYQuote = By
			.cssSelector("div[class='btns_section'] button[onclick*='T90&flow']");
	public static By validDobError = By.xpath("//div[contains(text(),'Please Enter')]");
	public static By validDobError1 = By.xpath("//div[contains(text(),'Please enter')]");
	public static By rightChoice = By.xpath("//a[contains(text(),'The Right Choice')]");
	public static By birthDate = By.cssSelector(INPUT_CONTAINS_CLASS_DATE);
	public static By stateRightChoice = By.cssSelector(SELECT_TEST_ID_STATE_SELECTION);
	public static By showOptions = By.cssSelector("span[class='lfr-btn-label']");
	public static String dismiss_options = "(//div[@class='hide-column'])[$]";
	public static By showAllOptions = By.cssSelector("a[onclick*='showAllOp']");

	public static By RCGBLLearnMore = By
			.cssSelector("button[onclick*='guaranteedacceptance']");
	public static By RCSIWLLearnMore = By
			.xpath("(//div[contains(@class,'guarantee')]//button[contains(text(),'Learn More')])[2]");
	public static By RCT90LearnMore = By
			.xpath("(//div[contains(@class,'guarantee')]//button[contains(text(),'Learn More')])[3]");
	public static By SIWLLivingLearnMore = By
			.xpath("(//div[contains(@class,'guarantee')]//button[contains(text(),'Learn More')])[4]");
	public static By T90LivingLearnMore = By
			.xpath("(//div[contains(@class,'guarantee')]//button[contains(text(),'Learn More')])[5]");
	public static By LivinglearnMore = By
			.xpath("(//div[contains(@class,'living')]//button[contains(text(),'Learn')])[1]");
	public static By livingPricing = By.xpath("(//div[contains(@class,'living')]//a[contains(text(),'Pricing')])");
	public static String Pricing_Terms = "(//div[contains(@class,'guarantee')]//a[contains(text(),'Pricing')])[$]";

	// ---------------------------------Your Policy----------------------

	public static By yourPolicy_FirstName = By.cssSelector(INPUT_TEST_ID_FIRST_NAME);
	public static By yourPolicy_LastName = By.cssSelector(INPUT_TEST_ID_LAST_NAME);
	public static By yourPolicy_Address = By.cssSelector("input[id*='addressLine1']");
	public static By yourPolicy_AddressLine2 = By.cssSelector("input[test_id='addressLine2']");
	public static By yourPolicy_City = By.cssSelector(INPUT_TEST_ID_CITY);
	public static By yourPolicy_State = By.cssSelector("select[id*='stateCode']");
	public static By yourPolicy_Zipcode = By.cssSelector(INPUT_TEST_ID_ZIP_CODE);
	public static By yourPolicy_Gender = By.cssSelector(GENDER);
	public static By yourPolicy_EmailAddress = By.cssSelector("input[id*='email')]");
	public static By yourPolicy_Brthday = By.cssSelector("input[placeholder*='Date')]");
	public static By yourPolicy_PhoneNumber = By.cssSelector("input[placeholder*='Phone')]");
	public static By yourPolicy_SaveChangesButton = By.cssSelector("");
	public static By yourPolicy_Premium = By.cssSelector("");
	public static By yourPolicy_Addons = By.cssSelector("");
	public static By yourPolicy_BasePlan = By.cssSelector("");
	public static By yourPolicy_Coverage = By.cssSelector("");
	public static By yourPolicy_WelcomeName = By.cssSelector("");
	public static By yourPolicy_continue = By.cssSelector("");
	public static By yourPolicy_Back = By.cssSelector("");
	public static By yourPolicy_backtocolonialpenn = By.cssSelector("");
	// -------------------Life Choice Insurance------------------------
		public static final By lifeChoiceInsurance = By.cssSelector("div[id='LC']");
	// ---------------------Product
	// Result------------------------------------------------
	public static By ProductResult_Apply_1 = By.xpath("(//span[contains(text(),'Apply')])[1]");
	public static By ProductResult_BackButton = By.cssSelector("a[class*='btn-back']");
	public static By ProductResult_TotalPermium = By.cssSelector("p[id*='PremiumAmount']");
	public static By ProductResult_BackToColonialPenn = By.xpath("//span[contains(text(),'Start A New Quote')]");
	public static By ProductResult_BackToInsurancepage = By.xpath("//h2[contains(text(),'Insurance ')]");
	public static By ProductResult_LogoCPL = By.cssSelector("img[class*='cpl_logo']");
	public static By ProductResult_State = By.cssSelector("select[test_id*='state']");
	public static By ProductResult_Gender = By.cssSelector("select[test_id*='gender']");
	public static By ProductResult_BirthDay = By.cssSelector("input[test_id*='birthDay']");
	public static By ProductResult_PageTitleName = By.xpath("//h1[contains(text(),'basics')]");
	public static By ProductResult_Test = By.cssSelector("button[id*='nothanks']");

	// Baisc Review Screen Field Validation
	public static By GQPage_FirstNError1 = By.cssSelector("input[test_id='firstName']+div");
	public static By GQPage_LastsNameError1 = By.cssSelector("input[test_id='lastName']+div");
	public static By GQ_PhoneNumberError1 = By.cssSelector("input[test_id*='phone']+div");
	public static By GQPage_CityError1 = By.cssSelector("input[test_id*='city']+div");
	public static By GQ_EmailError1 = By.cssSelector("input[test_id*='emailAddr']+div");
	public static By GQPage_ZipcodeError1 = By.cssSelector("input[test_id,'zipCode']+div");
	public static By GoPage_ProductName = By.cssSelector("p[class*='product_name']");

	// Quote Enhancement
	public static By Quote_PolicyHeader = By.cssSelector("p[class='ins_header text-center']");
	public static By Quote_BaseCoverageLabel = By.cssSelector("div[class='col-xs-5 mobile_padding_0'] p[class='plan_heading']");
	public static By Quote_MonthlyPremium = By.cssSelector("div[class='col-xs-6 col-xs-offset-1 mobile_padding_0'] p");
	public static By Quote_ApplyButton = By.cssSelector("button[test_id*='apply_btn_quote_panel']");
	public static By Quote_30DaysTry = By.cssSelector("div[class='col-xs-12 thirty_days_try_container'] span");
	public static By Quote_PhoneNumber = By.cssSelector("span[class*='more_help_phone_no']");
	public static By Quote_BasicDeatilsLabel = By.cssSelector("p[class='basic']");
	public static By Quote_YourPolicyDisabled = By.cssSelector("p[class='product_name']");
	public static By Quote_ADRLabel = By.cssSelector("div[class='adr_benefit_product_container'] h3");
	public static By Quote_ArrowvalueReviewBasicDetails = By.cssSelector("div[class='basic_person_details'] p[test_id='basic_details_learn_more'] span");
	public static By Quote_Age = By.cssSelector("span[class='age']");
	public static By Quote_ArrowCollapseBasicDetails = By.cssSelector("div[class='hidden-xs text-center expand_collapse_toggle_link'] p[test_id='basic_details_dismiss_details'] span");
	public static By Quote_EditBasicDetails = By.cssSelector("a[test_id*='edit']");
	public static By QuotePageValidation = By.cssSelector("p[class='basic']");
	public static By Quote_ArrowvalueViewFullQuote = By.cssSelector("p[test_id='quote_panel_exapnd'] span");
	public static By Quote_ArrowvalueDismissDetails = By.cssSelector("p[test_id='quote_panel_dismiss'] span");
	public static By Quote_basePlanCoverage = By.cssSelector("p[id='basePlanCoverageAmount']");
	public static By Quote_TotalMonthlyPermium = By.cssSelector("p[id='totalSelectedadOnPremiumOnscreen']");
	public static By Quote_AccidentalDeathRider = By.cssSelector("a[test_id='add_death_rider']");
	public static By Quote_Remove = By.cssSelector("p[class='remove_rider removeRider']");
	public static By Quote_AddAccidentalDeathRider = By.cssSelector("a[test_id='add_death_rider_plus_icon']");
	public static By Quote_DDADR = By.cssSelector("select[id*='accidentalDeathRider']");
	public static By Quote_DECADR = By.cssSelector("span[test_id='death_rider_dec']");
	public static By Quote_DECCoverageAmount = By.cssSelector("span[test_id='base_coverage_dec']");
	public static By Quote_AddCoverageAmount = By.cssSelector("span[test_id='base_coverage_inc']");
	public static By Quote_SIWLbasePlanCoverage = By.cssSelector("p[id='selectedcoverageAmountOnscreen']");
	public static By Quote_BackToTOP = By.cssSelector("a[test_id='quote_back_to_top']");
	public static By Quote_DontWorryLabel = By.xpath("//p[contains(text(),'worry')]");
	public static By Quote_ResultPageBackToTOP = By.cssSelector("a[test_id='quote_results_back_to_top']");
	public static By Quote_ApplicationLabel = By.cssSelector("p[class='policy_eligibility_text']");
	public static By Quote_UpdateButtom = By.cssSelector("button[test_id*='update_quote']");
	public static By Quote_ErrorMessage = By.cssSelector("div[class='center_container'] p");
	public static By Quote_StartNewQuoteButton = By.cssSelector("button[id='header-getquote']");
	public static By Quote_PhoneNumErrorMsg = By.cssSelector("div[class='center_container'] a");
	public static By Quote_ReturnHomePage = By.cssSelector("button[test_id='error_view_plans_btn']");
	public static By Quote_GetquoteLabel = By.xpath("//h2[contains(text(),'started')]");
	public static By Quote_GetquoteInformation = By.cssSelector("p[class='what_we_need_to_give']");
	public static By Quote_BasicDetailsBackToTop = By.cssSelector("a[class='back-to-top'] span[class='text']");
	// -------------------------------------Beneficiary----------------------------
	
	
	public static By selectedShare1 = By.cssSelector("select[id*='share1'] option[selected] ");
	public static By selectedShare2 = By.cssSelector("select[id*='share2'] option[selected] ");
	public static By selectedShare3 = By.cssSelector("select[id*='share3'] option[selected] ");		
	public static By FNameErrMSG = By.xpath("//div[contains(text(),'first')] | //div[contains(text(),'First')]");
	public static By LNameErrMSG = By.xpath("//div[contains(text(),'last')] | //div[contains(text(),'Last')]");
	public static By CVGUnits = By.xpath("//dd[@class='text-green weight-bold covAmount']");
	public static By mobClick = By.xpath("//h3[contains(text(),'Which')]//following-sibling::i");
	//-----------------------------------------Email Validation----------------------
	public static By searchBoxWebmail = By.cssSelector("div[role='search'] input");
	public static By searchMailBtn = By.cssSelector("i[data-icon-name='Search']");
	public static By appReceivedMail = By.cssSelector("div[aria-label*='Application received']");
	public static By mailboxMaxMailDIV = By.cssSelector("div[class*='ScrollBar']");
	
	//----------------------------Ineligible---------------------------------------------
		public static final By thankYouText = By.cssSelector("div.not_eligible_title > p");
		public static final By notEligibleForAny = By.cssSelector("div[class*=not_eligible_content]");
		public static final By notEligibleForThis = By.xpath("//p[contains(text(),'not eligible for this insurance')]");
	    public static By notEligibletext=By.cssSelector("p[class='not_eligible_text']");
		public static By notQualifyPopup=By.xpath("//h4[text()='We�re sorry, you do not qualify for this coverage.']");
	    public static By AnotherpalnBtn=By.xpath("//button[@id='choose_plan_btn']");
		public static By DOBnotEligibleError=By.cssSelector("div[class='not_eligible_error']");
		public static By GBLNotEligibleError=By.cssSelector("div[class='col-12 col-md-12 not_eligible_error']");
		public static By UpdateYourinfButton=By.cssSelector("button[class='continue_btn btn_state']");
		public static By ReturntoHomeBtn=By.cssSelector("button[class='back_btn btn_state']");
		public static By GBLnotEligibletext=By.cssSelector("p[contains(text(),'you are not eligible for this insurance plan']");
		public static By SIWLEnabled=By.cssSelector("div[class='whole_card quote_product_card col-md-4 col-lg-12 product-item active']");
		public static By SIWLheader=By.xpath("//strong[contains(text(),'Permanent Whole Life Insurance')]");
		public static String QuoteResultPage="https://sit-temp.colonialpenn.com/quote-results";
	//newyorkContentValidate
		public static By nyResidentIcon= By.cssSelector("li.col-sm-7.col-md-8.col-lg-8.padding_side_0px.ny_link_container.col-xs-4 > div > a > p > span");
		public static By nyResidentAlert= By.cssSelector("div[data-analytics-asset-title=NYPopup]");
		public static By closeAlert= By.cssSelector("button.close-btn");
		public static By homepgAlexContent= By.cssSelector("p:contains(Alex educated)");
		//eliminateCOdownload
		public static By dwnloadApp= By.cssSelector("ul#euvj_ > li:nth-of-type(2)");
		public static By dwnloadAppTextBox = By.cssSelector("div.download-app > h4");
		public static By stateDropdown = By.cssSelector("select[name*=downloadapp_state]");
		public static By dwnLoadAppSubmit = By.cssSelector("(button#_com_cno_cpl_downloadapp_downloadapp_submit");
		public static By dwnloadAppGBLappLink = By.cssSelector("ul#downloadLink > li > a");
		//validateGBLage
		public static By homePageGBLLink = By.cssSelector("ul#lgcg_ > li > a");
		public static By gblHeader1 = By.cssSelector("div[data-analytics-asset-title=PlanSelectionTile_GBL] > div > h3");
		public static By gblFirstName = By.cssSelector("input[id*=firstName]");
		public static By gblLastName = By.cssSelector("input[id*=lastName]");
		public static By gblBDay = By.cssSelector("input[name*=dob]");
		public static By gblState = By.cssSelector("select[id*=state]");
		public static By gblEmail = By.cssSelector("input[id*=emailAddress]");
		public static By gblSubmitQuote = By.cssSelector("button[id*=submitMyquote]");
		//launchGBL
		public static By insuranceTab = By.cssSelector("li.col-md-2.col-sm-3.ins_hover_section > a");
		public static By insuranceGBLLink = By.xpath("(//a[contains(text(),'Guaranteed')])[1]");
		public static By webMailHeader = By.cssSelector("div#loginHeader");
		public static By latestEmail = By.xpath("(//span[@title='no-reply@colonialpenn.com'])[1]");
		public static By appReceiveMail = By.cssSelector("strong:contains(Your Quote)");
		public static By resumeQuoteLink = By.xpath("//a[contains(text(),'Start your application today')]");
		public static By resumeCallLink = By.xpath("//a[contains(text(),'Phone Number')]");
		public static By mailboxMaxMail = By.cssSelector("div[class*=ScrollBar]");
		
		public static By mailCoverageText = By.xpath("//td[contains(text(),'Base Plan Coverage')]");		
		public static By Header_PHnumber = By.cssSelector("span#dynamicPhoneHeader");
		public static By Home_PHnumber = By.cssSelector("a#dynamicPhoneCT");
		public static By Footer_PHnumber = By.xpath("(//a[@class='excludeURL mobile-number'])[1]");
		public static By NeedLilHelp = By.cssSelector("a#dynamicPhoneCT");
		public static By nameDis = By.xpath("//p[contains(text(),'Name and Place')]/following-sibling::p[1]");
		public static By streetAdd = By.xpath("//p[contains(text(),'Name and Place')]/following-sibling::p[2]");
		public static By Apt = By.xpath("//p[contains(text(),'Name and Place')]/following-sibling::p[3]");
		public static By cityDis = By.xpath("//p[contains(text(),'Name and Place')]/following-sibling::p[4]");
		public static By DOBDis = By.xpath("//p[contains(text(),'Birthdate')]/following-sibling::p[1]");
		public static By genderDis = By.xpath("//p[contains(text(),'Birthdate')]/following-sibling::p[2]");
		public static By emailDis = By.xpath("//p[contains(text(),'Birthdate')]/following-sibling::p[3]");
		public static By phNumDis= By.xpath("//p[contains(text(),'Birthdate')]/following-sibling::p[4]");
		public static By resumeQuote= By.xpath("//button[contains(@id='header-getquote')]");
		public static By ViewresumeFullQuote= By.xpath("//span[contains(text(),'View Full Details')]");
		public static By BasicDetailsCovamt= By.cssSelector("p[test_id=coverage_amount]");
		public static final By BasicDetailsmodalPre= By.cssSelector("span[id='montlyPremiumUpdated']");
		public static By customizeCov= By.xpath("//span[contains(text(),'Customize Coverage')]");
		public static By removeRider= By.cssSelector("p#removeRider");
		public static By saveChanges= By.cssSelector("button[test_id=saveChanges]");
		public static By cplLogo= By.cssSelector("img.cpl_logo");
		public static final By LCInsurance = By.cssSelector("div[id='LC']");
		public static final By GQpage_gblcoverageUnits=By.cssSelector("span[id='unitCount']");
		public static final By GQpage_LCcoverageamt=By.cssSelector("span[id='lccovamnt']");
		
		//----------------------------GetQuotePage---------------------------------------------
		public static final By Onetrust_Banner=By.cssSelector("div[id='onetrust-banner-sdk']");
		public static final By Onetr_Accept=By.cssSelector("button[id='onetrust-accept-btn-handler']");
		public static final By gqpage_Header=By.cssSelector("h4[class='product_form_head present'],H1[class='quote_header']");
		public static final By gblProduct=By.cssSelector("div[id='GBL'],div[id='NYGBL']");
		public static final By siwlproduct=By.cssSelector("div[id='SIWL']");
		public static final By gblpnt = By.cssSelector("div[class='quote_pricing_terms'] a[test_id='base_plan_pricing_terms']");
		public static final By lifeChoiceInsurance1 = By.cssSelector("div[id='LC']");
		public static final By gqPage_FirstName1 = By.cssSelector(INPUT_TEST_ID_FIRST_NAME);
		public static final By gqPage_LastName1 = By.cssSelector(INPUT_TEST_ID_LAST_NAME);
		public static final By gqPage_Birthday1 = By.cssSelector("input[test_id='dateOfBirth']");
		public static final By GQPAGE_GENDER1 = By.cssSelector(GENDER);
		public static final By gqpage_GenderMale= By.cssSelector("label[class='form-check-label form-check-male']");
		public static final By gqpage_GenderFemale = By.cssSelector("label[class='form-check-label form-check-female']");
		public static final By GQPage_State = By.cssSelector("select[test_id='state']");
		public static final By GQPAGE_PHONENUMBER1 = By.cssSelector("input[test_id='phone']");
		public static final By GQPAGE_EMAIL1 = By.cssSelector("input[test_id='emailAddr'],INPUT[test_id='emailAddr']");
		public static final By GQPage_FIRSTNAMEERROR1 = By.cssSelector("div[id='_CPQuote_firstNameHelper'] div");
		public static final By GQPage_LASTNAMEERROR1 = By.cssSelector("div[id='_CPQuote_lastNameHelper'] div");
		public static final By gqpage_Birthdayerror1 = By.cssSelector("div[id='_CPQuote_datepicker_1Helper'] div");
		public static final By GQPAGE_GENDERERROR1 = By.cssSelector("div[id='_CPQuote_femaleHelper'] div");
		public static final By GQPage_StateError1 = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_stateCodeHelper'] span");
		public static final By GQPAGE_EMAILERROR1 = By.cssSelector("div[id='_CPQuote_emailAddressHelper'] div");
		public static final  By GQPAGE_PHONENUMBERERROR1 = By.cssSelector("div[id='_CPQuote_phoneNumberHelper'] div");
		public static final By GQPage_AddressError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_addressLine1Helper'] span");
		public static final  By GQPAGE_CITY1 = By.cssSelector(INPUT_TEST_ID_CITY);
		public static final By GQPage_CityError = By.cssSelector("div[id='_CPQuote_INSTANCE_anxk42PWZqCh_cityHelper'] span");
		public static final By gqpage_Zipcode1 = By.cssSelector(INPUT_TEST_ID_ZIP_CODE);
		public static final By gqpage_ZipcodeError = By.cssSelector("div[id='_CPQuote_zipCodeHelper'] div");
		public static final By QPANEL_APPLY1 = By.cssSelector("button[test_id='get_a_quote'],BUTTON[test_id='get_a_quote']");
		public static final By GBLPNTHEADER=By.cssSelector("h4[class='modal-title gbl-head']");
		public static final By SIPNT = By.cssSelector("div[class='quote_pricing_terms'] a[test_id='base_plan_pricing_terms']");
		public static final By GBLPNTCLOSE=By.xpath("//*[@id=\"gblPricingTermModal\"]/div/div/div[1]/div/div/button[2]");

		// ---------------------Quote Results Page-----------------------
		public static final By QRPageCoverage = By.cssSelector("p[id*='PlanCoverage']");	
		public static final By QRPAGEPREMIUM = By.cssSelector("p[id*='Premium']");
		public static final By QRPAGEPRODUCT = By.cssSelector(P_CONTAINS_CLASS_INS_HEADER);
		public static final By QRPAGE_HEADER=By.cssSelector("label[class='select_coverage_label'],LABEL[class='select_coverage_label']");
		public static final By QRPAGE_DOWNLOADAPPLICATION = By.cssSelector("button[test_id='download_btn'],BUTTON[test_id='download_btn']");
		public static final By QPANEL_GETQUOTEMOBILE=By.xpath("//*[@text='Get a Quote']");
		public static final By QR_GETMYQUOTE = By.xpath("//button/span[contains(text(),'Get')]");
		public static final By QR_GETMyQUOTEBOTTOM = By.cssSelector("button[test_id='get_my_quote']");
		public static final By QR_PRODUCTNAME = By.cssSelector(P_CONTAINS_CLASS_INS_HEADER);
		public static final By QR_APPLYBOTTOM = By.xpath("(//span[contains(text(),'Apply')])[1] | //*[@id='_CPQuote_INSTANCE_jP47cGBSeCud_applyBottom'] ");
		public static final By PolicyQuote_ABRSECTION = By.xpath("//*[@text='More Benefits Available To You']");
		public static final By GQPAGE_ABRRIDERCHECKBOX = By.cssSelector("input[test_id='siwlAbrCheck'],INPUT[test_id='siwlAbrCheck']");
		public static final By GQ_COVERAGEAMOUNT = By.cssSelector("select[test_id='gblCoverage'],select[id='siwlCoverage'],SELECT[test_id='siwlCoverage'],select[id='lcCoverage'],SELECT[test_id='lcCoverage']");
		public static final By GQPAGE_ABRRIDERCANCER = By.cssSelector("input[test_id='abr_cancer'],input[test_id='abr_cancer']");
		public static final By GQPAGE_ABRRIDERCHRONIC = By.cssSelector("input[test_id='abr_chronic'],INPUT[test_id='abr_chronic']");
	    public static final By GQPAGE_ABRRIDERHA = By.cssSelector("input[test_id='abr_heart']");
	    public static final By yourbasics_ADRcheckbox = By.cssSelector("input[test_id='adr_checkbox']");
	    public static final By POLICYQUOTE_ABRRADIOBUTTON = By.cssSelector("input[name=abrRadio]");
	    public static final By GBL_COVERAGE=By.cssSelector("span[id='cov_amount']");
	    public static final By SIWL_COVERAGE = By.cssSelector("span[id='nwlcovamt']");
	    public static final By GQPAGE_ABRRIDERSELECTED = By.cssSelector("span[class='abr_benefit_units']");
	    public static final By QR_SENDMEEMAIL = By.cssSelector("a[test_id='sendMeThisQuote']");
	    public static final By QR_POPUPHEADING = By.cssSelector("h4[class='modal-title emailTrigrSucHead']");
	    public static final By EMAIL_CONTINUE = By.cssSelector("button[id='email_continue_btn']");
	    public static final By POLICYQUOTE_SENDMEEMAILDISABLED = By.cssSelector("a[class='disabled']");
	    public static final By GR_EDITBASICDETAILS = By.cssSelector("a[test_id=edit_details]");
	    public static final By GQPAGE_EDITBASICMOBILE=By.xpath("//*[@id='edit_details']");
	    public static final By QR_APPLY = By.xpath("(//span[contains(text(),'Apply')])[2]");
	    public static final By GBLBIRTHDAY1 = By.cssSelector("input[test_id=dateOfBirth]");
	    public static final By QRPAGE_DOWNCARET=By.xpath("//SPAN[@css='SPAN.expand_collapse_icon.d-lg-none']"); 	
		public static final By QRpage_upcaret=By.xpath("//SPAN[@css='SPAN.expand_collapse_icon.d-lg-none']");
		public static final By pricingState=By.cssSelector("select[id='select_state']");
		public static final By GBLPNT_CLOSE=By.cssSelector("button[id='gbl_popup_close_btn']");
		public static final By GQPAGE_ADRRIDERCHECKBOX = By.cssSelector("INPUT[test_id='siwlAdrCheck']");
		public static final By GQ_ADRRIDERDD = By.cssSelector("SELECT[test_id='gblAdr'],SELECT[test_id='siwlAdr']");
		public static final By QR_ADR = By.cssSelector("input[test_id='gblAdrCheck']");
		public static final By GQpage_GBLADRRidercheckbox=By.cssSelector("input[test_id='gblAdrCheck']");
		public static final By GQPAGE_AGESELECTED=By.cssSelector("span[class='ageSelected']");
		public static final By GQPAGE_GENDERSELECTED=By.cssSelector("span[class='genderSelected']");
		public static final By GQPAGE_ZIPSELECTED=By.cssSelector("span[class='zipcodeSelected']");
		public static final By MONTHLYPREMIUM = By.cssSelector("P[test_id='quote_panel_month.premium']");
		public static final By GQPAGE_ADRRIDERSELECTED =By.cssSelector("span[id='gblAdrAmt'],span[id='nwlAdrAmt']");
		// ---------------------Your Coverage Page-----------------------
		public static By YourCoverageHeader=By.cssSelector("h1[class='quote_result_header']");
		public static final By BasicDetailsmodalABR= By.cssSelector("strong[class='abr_benefit_units']");
		public static final By BasicDetailsmodalADR=By.cssSelector("strong[id='nwlAdrAmt'],strong[id='gblAdrAmt']");
		public static final By CoverageContinue=By.cssSelector(BUTTON_CONTINUE);
		public static final By GQPage_ReviewCAmount=By.cssSelector("select[test_id='coverage_dropdown']");
		public static final By GQPage_ReviewcADRRiderDD=By.cssSelector("select[test_id='adr_dropdown']");
		public static final By GQPage_ReviewABRRider=By.cssSelector("strong[class='abr_benefit_units']");
		// ---------------------Your Otherpolicies Page-----------------------
		public static final By OtherPolicies_Continue1=By.xpath("//button[contains(.,'Continue') and not (ancestor::div[contains(@style,'display:none')])]");
		public static final By notEligiblePage=By.xpath("//h1[contains(text(),'We�re sorry, you do not qualify for this coverage.')]");
		public static final By RiderPopup=By.cssSelector("button[onclick='noThanksAbr(event)'],Button[onclick='noThanksAbr(event)']");
		// ---------------------Your Benefeceries Page-----------------------
		public static final By beneficiaryHeader = By.cssSelector("div[class='title'] h1");
		public static final String BENEIFICIARYFNAME1 = "(//span[contains(@class,'solid_line')]/descendant::input[@placeholder='First Name'])[1] |//INPUT[contains(@id,'firstName1')]";
		public static final String BENEIFICIARYFNAME2 = "(//span[contains(@class,'solid_line')]/descendant::input[@placeholder='First Name'])[2] |//input[contains(@id,'firstName2')]";
		public static final String BENEIFICIARYFNAME3 = "(//span[contains(@class,'solid_line')]/descendant::input[@placeholder='First Name'])[3] |//input[contains(@id,'firstName3')]";
		public static final String BENEIFICIARYLNAME1 = "(//span[contains(@class,'solid_line')]/descendant::input[@placeholder='Last Name'])[1] |//input[contains(@id,'lastName1')]";
		public static final String BENEIFICIARYLNAME2 = "(//span[contains(@class,'solid_line')]/descendant::input[@placeholder='Last Name'])[2] |//input[contains(@id,'lastName2')]";
		public static final String BENEIFICIARYLNAME3 = "(//span[contains(@class,'solid_line')]/descendant::input[@placeholder='Last Name'])[3] |//input[contains(@id,'lastName3')]";
		public static final String[] BENEFICIARYFNAME = { BENEIFICIARYFNAME1, BENEIFICIARYFNAME2, BENEIFICIARYFNAME3 };
		public static final String[] BENEFICIARYLNAME = { BENEIFICIARYLNAME1, BENEIFICIARYLNAME2, BENEIFICIARYLNAME3 };
	    public static final String EMAIL1 = "//input[@name='_CPBeneficiaryModule_INSTANCE_aVS0gVmCClzg_emailAddress1']";
		public static final String EMAIL2 = "//input[@name='_CPBeneficiaryModule_INSTANCE_aVS0gVmCClzg_emailAddress2']";
		public static final String EMAIL3 = "//input[@name='_CPBeneficiaryModule_INSTANCE_aVS0gVmCClzg_emailAddress3']";
		public static final String[] email = { EMAIL1, EMAIL2, EMAIL3 };
		public static final String RELATIONSHIPDROPDOWN1 = ("(//SELECT[contains(@class,'standard')])[1]|//SELECT[contains(@id,'relation1')]");
		public static final String RELATIONSHIPDROPDOWN2 = ("(//select[contains(@class,'standard')])[2]|//select[contains(@id,'relation2')]");
		public static final String RELATIONSHIPDROPDOWN3 = ("(//select[contains(@class,'standard')])[3]|//select[contains(@id,'relation3')]");
		public static final String[] RELATIONSHIPDROPDOWN = { RELATIONSHIPDROPDOWN1, RELATIONSHIPDROPDOWN2,
				RELATIONSHIPDROPDOWN3 };
		public static final By SHARE1 = By.xpath("//SELECT[@id='_CPBeneficiaryModule_INSTANCE_aVS0gVmCClzg_share1']");
		public static final By SHARE2 = By.xpath("//SELECT[@id='_CPBeneficiaryModule_INSTANCE_aVS0gVmCClzg_share2']");
		public static final By SHARE3 =By.xpath("//SELECT[@id='_CPBeneficiaryModule_INSTANCE_aVS0gVmCClzg_share3']");
		public static final By SHAREPERCENTAGEERRORS = By.xpath("//div[contains(@class,'content-item content-field item-1 remove-all-spacing flex')]//div/descendant::span | //div[@id='sharePercentageError'] | //div[@id='sharePercentageError']");
		public static final By addBeneficiary1 = By.xpath("//button[@class='addBeneficiary'] | //BUTTON[@class='addBeneficiary']");
		public static final By addBeneficiary2 = By.xpath("(//button[@class='addBeneficiary'])[2]");
		// ---------------------Progressvie Flow-CheckList Page-----------------------
		 public static final By Eligibility_Header=By.xpath("//h1[contains(text(),'Check Your Eligibility')]");
	        public static final By EC_StateError=By.xpath("(//div[@class='required'])[1]");
	        public static final By EC_State=By.cssSelector("select[test_id='state']");
	        public static final By EC_DOB=By.cssSelector("input[test_id='dateOfBirth']");
	        public static final By EC_DOBError=By.cssSelector("div[id='_com_cno_cpl_progressivequote_web_CPProgressiveEligibilityPortlet_INSTANCE_dkn0SKlUvd2p_datepicker_1Helper']");
	        public static final By Genderfield=By.cssSelector("div[class='custom-radio error']");
	        public static final By Continue=By.cssSelector("button[test_id='continue']");
	        public static final By GenderError=By.cssSelector("div[id='_com_cno_cpl_progressivequote_web_CPProgressiveEligibilityPortlet_INSTANCE_dkn0SKlUvd2p_femaleHelper']");
	        public static final By Eligible_Header=By.xpath("//h4[contains(text(),'Great News')]");
	        public static final By CheckElig_Header=By.xpath("//h1[contains(text(),'We make the application')]");
	        public static final By Funeral_charge=By.cssSelector("span[class='average_cost']");
	        public static final By Second_carousel=By.cssSelector("li[data-slide-to='1']"); 


}
