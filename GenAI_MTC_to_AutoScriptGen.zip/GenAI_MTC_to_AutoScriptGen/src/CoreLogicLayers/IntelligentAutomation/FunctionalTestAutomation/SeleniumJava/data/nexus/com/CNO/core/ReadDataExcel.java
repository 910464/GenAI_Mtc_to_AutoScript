/**
 * Package containing reusable libraries for excel sheet (third party tool) POI
 * jar dependency
 *
 * @author HCL
 */
package com.cnoinc.qa.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
/**
 * IOException is a Unchecked Java exception that occurs when an IO operation
 * fails
 */
import java.io.IOException;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.SkipException;

import com.cnoinc.qa.accelerators.UserdefinedException;

/**
 * @author HCL0R9 Apr 29, 2022
 */
public class ReadDataExcel {
	/**
	 * Log4j is a fast, reliable and flexible logging framework which is written
	 * in java. It is an open-source logging API for java. Simply the logging
	 * means some way to indicate the state of the system at runtime
	 */
	private static final Logger LOGGER = LogManager.getLogger(ReadDataExcel.class.getName());
	public static FileInputStream fi;
	public static FileOutputStream fo;
	/**
	 * XSSFWorkbook: It is a class representing the XLSX file. Workbook: It
	 * represents an Excel Workbook. It is an interface implement by
	 * HSSFWorkbook and XSSFWorkbook.
	 */
	public static XSSFWorkbook wb;
	/**
	 * XSSFSheet: It is a class representing the sheet in an XLSX file.
	 */
	public static XSSFSheet ws;
	/**
	 * XSSFRow: It is a class representing a row in the sheet of XLSX file.
	 */
	public static XSSFRow row;
	/**
	 * XSSFCell: It is a class representing a cell in a row of XLSX file.
	 */
	public static XSSFCell cell;
	public static XSSFCellStyle style;
	public static HashMap<String, String> map;
	public static final String FILE_NOT_FOUND = "Test Data File Not Found in the location";
	public static final String TESTDATA_NOT_FOUND = "Unable to extract Test Case Data.";

	/**
	 * Get column count
	 *
	 * @param xlfile
	 *            excel file containing the test data
	 * @param xlsheet
	 *            excel sheet containing the test data
	 * @param rownum
	 *            row number of the data
	 *
	 * @return a integer containing the column count.
	 */
	public synchronized static int getCellCount(String xlfile, String xlsheet, int rownum) throws IOException {
		try {
			fi = new FileInputStream(xlfile);
			wb = new XSSFWorkbook(fi);
			ws = wb.getSheet(xlsheet);
			row = ws.getRow(rownum);
			int cellcount = row.getLastCellNum();
			wb.close();
			fi.close();
			return cellcount;
		} catch (FileNotFoundException e) {
			LOGGER.error(FILE_NOT_FOUND, e.getMessage());
			throw new UserdefinedException(FILE_NOT_FOUND + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(TESTDATA_NOT_FOUND, e.getMessage());
			throw new UserdefinedException(TESTDATA_NOT_FOUND + e.getMessage());
		}
	}

	/**
	 * Get Row count
	 *
	 * @param xlfile
	 *            excel file containing the test data
	 * @param xlsheet
	 *            excel sheet containing the test data
	 *
	 * @return a integer containing the Row count.
	 */
	public synchronized static int getRowCount(String xlfile, String xlsheet) throws IOException {
		try {
			fi = new FileInputStream(xlfile);
			wb = new XSSFWorkbook(fi);
			ws = wb.getSheet(xlsheet);
			int rowcount = ws.getLastRowNum();
			wb.close();
			fi.close();
			return rowcount;
		} catch (FileNotFoundException e) {
			LOGGER.error(FILE_NOT_FOUND, e.getMessage());
			throw new UserdefinedException(FILE_NOT_FOUND + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(TESTDATA_NOT_FOUND, e.getMessage());
			throw new UserdefinedException(TESTDATA_NOT_FOUND + e.getMessage());
		}
	}

	/**
	 * Update the table data.
	 *
	 * @param xlfile
	 *            excel file containing the test data
	 * @param xlsheet
	 *            excel sheet containing the test data
	 * @param rownum
	 *            row name to update the data.
	 * @param colnum
	 *            the data column to update the data.
	 * @param value
	 *            value to be updated.
	 */
	public synchronized static void updateCellData(String xlfile, String xlsheet, int rownum, int colnum, String value)
			throws IOException {
		try {
			fi = new FileInputStream(xlfile);
			wb = new XSSFWorkbook(fi);
			ws = wb.getSheet(xlsheet);
			row = ws.getRow(rownum);
			cell = row.createCell(colnum);
			cell.setCellValue(value);
			fo = new FileOutputStream(xlfile);
			wb.write(fo);
			wb.close();
			fi.close();
			fo.close();
		} catch (FileNotFoundException e) {
			LOGGER.error(FILE_NOT_FOUND, e.getMessage());
			throw new UserdefinedException(FILE_NOT_FOUND + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(TESTDATA_NOT_FOUND, e.getMessage());
			throw new UserdefinedException(TESTDATA_NOT_FOUND + e.getMessage());
		}
	}

	public String xlFile;

	/**
	 * @param xlFilepath
	 */
	public ReadDataExcel(String xlFilepath) {
		this.xlFile = xlFilepath;
	}

	/**
	 * Date : Apr 29, 2022 Method Description : closeworkbook
	 *
	 * @param wb
	 */
	public void closeworkbook(Workbook wb) {
		try {
			LOGGER.trace("Workbook close");
			wb.close();
		} catch (Exception e) {
			LOGGER.info(e);
		}
	}

	/**
	 * Get the cell data based on the Header
	 *
	 * @param xlsheet
	 *            Excel sheet containing the test data
	 * @param columnName
	 *            ColumnName containing the test data
	 * @param TestCaseID
	 *            TestcaseID of the Test data
	 *
	 * @return the String format of cell value
	 */
	public synchronized String getCellBasedOnHeader(String xlsheet, String columnName, String testCaseName) {
		DataFormatter formatter = new DataFormatter();
		ws = null;
		row = null;
		boolean fnstatus=false;
		try {
			int columnNum = -1;
			fi = new FileInputStream(xlFile);
			wb = new XSSFWorkbook(fi);
			ws = wb.getSheet(xlsheet);
			row = ws.getRow(0);
			int rowcount = ws.getLastRowNum() - ws.getFirstRowNum();
			for (int i = 0; i < row.getLastCellNum(); i++) {
				if (row.getCell(i).getStringCellValue().trim().equals(columnName)) {
					columnNum = i;
					break;
				}
			}
			for (int i = 1; i <= rowcount; i++) {
				String tcid = ws.getRow(i).getCell(1).getStringCellValue();
				if (tcid.equalsIgnoreCase(testCaseName)) {
					row = ws.getRow(i);
					cell = row.getCell(columnNum);
					fnstatus=true;
					break;
				}
			}
			wb.close();
			fi.close();
		} catch (Exception e) {
			LOGGER.info(e);
		}
		if(!fnstatus)
			throw new SkipException("Please set tc name.... "+testCaseName);
		
		if (formatter.formatCellValue(cell).isEmpty()) {
			return null;
		} else {
			return formatter.formatCellValue(cell);
		}

	}

	public synchronized String getCellBasedOnHeaderByInstance(String xlsheet, String columnName, String sNo) {
		DataFormatter formatter = new DataFormatter();
		ws = null;
		row = null;

		try {
			int columnNum = -1;
			fi = new FileInputStream(xlFile);
			wb = new XSSFWorkbook(fi);
			ws = wb.getSheet(xlsheet);
			row = ws.getRow(0);
			int rowcount = ws.getLastRowNum() - ws.getFirstRowNum();
			for (int i = 0; i < row.getLastCellNum(); i++) {
				if (row.getCell(i).getStringCellValue().trim().equals(columnName)) {
					columnNum = i;
					break;
				}
			}
			for (int i = 1; i <= rowcount; i++) {
				String sNoInstance = ws.getRow(i).getCell(0).getStringCellValue();
				if (sNoInstance.equalsIgnoreCase(sNo)) {
					row = ws.getRow(i);
					cell = row.getCell(columnNum);
					break;
				}
			}
			wb.close();
			fi.close();
		} catch (Exception e) {
			LOGGER.info(e);
		}
		if (formatter.formatCellValue(cell).isEmpty()) {
			return null;
		} else {
			return formatter.formatCellValue(cell);
		}

	}

	/**
	 * Date : Apr 29, 2022 Method Description : readaccessWF
	 *
	 * @param wb
	 * @param excelpath
	 *
	 * @return
	 */
	public Workbook readaccessWF(Workbook wb, String excelpath) {
		try {
			File file = new File(excelpath);
			wb = WorkbookFactory.create(file, null, true);
		} catch (Exception e) {
			LOGGER.info(e);
		}
		return wb;
	}
}
