/**
 * Package: ReadData - A class containing methods to access data from a
 * Microsofr SQL
 *
 * @author HCL 05 May,2022
 */
package com.cnoinc.qa.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.List;
/**
 * org.apache.logging.log4j Class LogManager
 */
import org.apache.logging.log4j.LogManager;
/**
 * org.apache.logging.log4j Interface Logger
 */
import org.apache.logging.log4j.Logger;
import com.cnoinc.qa.accelerators.TestEngine;
import com.cnoinc.qa.accelerators.UserdefinedException;
import com.cnoinc.qa.support.ReportEvent;
import com.cnoinc.qa.support.StatusReport;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

/**
 * ReadData - A class containing methods to access data from a Microsofr SQL
 * Server database. <br>
 * <br>
 * This class provides a foundation for access test data from a MSSQL database.
 * It provides a raw connection as well as some helper methods for working with
 * the data. <br>
 * <br>
 * Getting a connection:
 *
 * <pre>
 * {@code
 * System.out.println(rd.connection.getCatalog());
 * }
 * </pre>
 *
 * Getting a specific cell's data:
 *
 * <pre>
 * {
 * 	&#64;code
 * 	ReadData rd = new ReadData("Somehost", 1433, "username", "password", "database");
 * 	String cellData = rd.getCellData("tableName", "columnName", "testCaseId");
 * }
 * </pre>
 */
public class ReadDataSQL extends TestEngine {
	// <editor-fold desc="Class Variables">
	private static final Logger LOGGER = LogManager.getLogger(ReadDataSQL.class.getName());
	private static String errCloseConnection = "Failed to close the connection.";
	private static String errErrorCode = "SQL Error Code: ";
	private static String errExecuteQuery = "Failed to execute query.";
	private static String errStateCode = "SQL Error State Code: ";
	private static String errStatementClose = "Failed to close the statement.";
	private static final String EXECUTEQUERY = "Execute Query";
	private static final String SQL_CONNECTION = "SQL Connection";
	private static final String ORACLE_CONNECTION = "Oracle Connection";
	private static final String UNABLETO_CONNECTDB = "Unable to connect to DB: ";
	private static final String UPDATE_QUERY = "UPDATE %s SET [%s] = '%s' WHERE TC_ID='%s' AND SubIteration = '%s'";
	private int currentIteration = 0;
	private static int currentSubIteration = 0;
	public static final int A = 1;
	public static final int B = 2;
	// </editor-fold>
	private static ReportEvent report = new ReportEvent();

	public static void finallyBlock(PreparedStatement statement, ResultSet resultSet) {
		try {
			if (statement != null) {
				statement.close();
			}
		} catch (SQLException e) {
			LOGGER.warn(errStatementClose, e);
		}
		try {
			if (resultSet != null) {
				resultSet.close();
			}
		} catch (Exception e) {
			LOGGER.info(e);
		}
	}

	public Connection connection;
	private String dbUrl;
	private String username;
	private String password;
	private String server;
	private int port;
	private String database;

	// <editor-fold desc="Constructors">
	/**
	 * Generic constructor, no connection is made.
	 */
	public ReadDataSQL(int subItera) {
		this.currentSubIteration = subItera;
	}

	/**
	 * Create a new instance using Java SQL DriverManager to connect.
	 *
	 * @param dbUrl SQL connection string.
	 */
	public ReadDataSQL(String dbUrl) {
		this.dbUrl = dbUrl;
		connection = sqlConnectWithDriverManager();
	}

	/**
	 * Create a new instance using MS SQL SQLServerDataSource to connect.
	 *
	 * @param server   hostname of the database server
	 * @param port     port number to connect
	 * @param username username of the user to connect
	 * @param password password of the user to connect
	 * @param database name of the database to connect
	 *
	 * @throws SQLException
	 */
	public ReadDataSQL(String server, int port, String username, String password, String database) throws SQLException {
		this.server = server;
		this.port = port;
		this.username = username;
		this.password = password;
		this.database = database;
		connection = sqlConnectWithSqlServerDataSource();
	}

	// </editor-fold>
	public void setCurrentRow(String currentTestcase, int currentIteration, int currentSubIteration) {
		objdriver.setTestCaseName(currentTestcase);
		/* 42 */ this.currentIteration = currentIteration;
		/* 43 */ this.currentSubIteration = currentSubIteration;
	}
	
	public  synchronized int getRowCountAccess(String datatableName){
		String nonQuery = "SELECT " +"COUNT (*)" + " FROM " + datatableName ;
		int RowCount = 0;
		try {
			PreparedStatement statement = connection.prepareStatement(nonQuery);
			statement.setString(1, objdriver.getTestCaseName());
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				RowCount = resultSet.getInt(1);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return RowCount;

	}

	/**
	 * Close the connection to the database.
	 */
	public void closeConnection() {
		try {
			if (null != connection) {
				connection.close();
			}
		} catch (SQLException e) {
			LOGGER.error(errCloseConnection, e);
		}
	}

	/**
	 * Create a new connection to the database.
	 *
	 * @param dbUrl jdbc connection string.
	 *
	 * @return a Java SQL Connection object.
	 *
	 * @deprecated use {@link ReadData} constructors instead.
	 */
	@Deprecated
	public Connection dbconnection(String dbUrl) {
		LOGGER.debug("Getting Database Connection.");
		try {
			connection = DriverManager.getConnection(dbUrl);
		} catch (SQLTimeoutException e) {
			LOGGER.error("Timeout connecting to Microsoft SQL Server.", e);
			throw new UserdefinedException("Timeout connecting to Microsoft SQL Server.");
		} catch (SQLServerException e) {
			LOGGER.error("SQL Server experienced and error.", e);
			throw new UserdefinedException("SQL Server experienced and error.");
		} catch (SQLException e) {
			LOGGER.error("Unable to connect to the database.", e);
			throw new UserdefinedException("Unable to connect to the database.");
		}
		return connection;
	}
	// </editor-fold>

	/**
	 * Handle exiting from this class.
	 *
	 * @param message message to output to the LOGGER.
	 * @param e       exception encountered, null if no exception.
	 */
	@SuppressWarnings("deprecation")
	private void errOut(String message, Exception e) {
		if (e != null) {
			LOGGER.exit(0);
		} else {
			LOGGER.error(message);
		}
	}
	// </editor-fold>

	public String executeSQLQuery(String Query, String column) {
		PreparedStatement statement = null;
		String data = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(Query);
			statement.setString(1, objdriver.getTestCaseName());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				data = resultSet.getString(column);
			}
		} catch (SQLException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLogWithNoSS(errExecuteQuery,
					Query + objdriver.getTestCaseName() + " Column Name " + column, StatusReport.FAIL);
			} else {
				report.updateTestLogWithNoSS(errExecuteQuery,
						Query + objdriver.getTestCaseName() + " Column Name " + column, StatusReport.INFO);
			}
			LOGGER.error(errStateCode + e.getSQLState() + " " + errErrorCode + e.getErrorCode());
			LOGGER.error(errExecuteQuery, e);
		} finally {
			finallyBlock(statement, resultSet);
		}
		data = verfyemptyAndNull(data);
		return data;
	}

	public void executeUpdateQuery(String query) {
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(query);
			statement.executeUpdate();
		} catch (SQLException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLogWithNoSS(errExecuteQuery, query, StatusReport.FAIL);
			LOGGER.error(errExecuteQuery, e);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				LOGGER.warn(errStatementClose, e);
			}
		}
	}

	public String getCellCommonData(String appColumn, String table, String column) {
		String query = String.format("SELECT * FROM %s WHERE Application = ?", table);
		String value = getCommonTestData(query, column, appColumn);

		return value;
	}

	public String getCommonTestData(String query, String commonColumn, String appColumn) {
		PreparedStatement stmt = null;
		String commonData = null;
		ResultSet rs = null;
		try {
			stmt = connection.prepareStatement(query);
			stmt.setString(1, appColumn);
			rs = stmt.executeQuery();
			while (rs.next()) {
				commonData = rs.getString(commonColumn);
			}
		} catch (SQLException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLogWithNoSS(errExecuteQuery, query + objdriver.getTestCaseName(), StatusReport.FAIL);
			LOGGER.error(errStateCode + e.getSQLState() + " " + errErrorCode + e.getErrorCode());
		} finally {
			finallyBlock(stmt, rs);
		}
		commonData = verfyemptyAndNull(commonData);
		return commonData;
	}

	public String getCellDataSubIteration(String table, String column, int subiteration) {
		String query = String.format("SELECT * FROM %s WHERE Iteration='%s' AND SubIteration = '%s' And TC_ID=?", table,
				1, subiteration);
		String value = executeSQLQuery(query, column);
		return value;
	}

	public synchronized int getTCRowCountAccess(String dataSheetName) {
		String nonQuery = "SELECT " + "COUNT (*)" + " FROM " + dataSheetName + " WHERE TC_ID = '"
				+ objdriver.getTestCaseName() + "'";
		int RowCount = 0;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(nonQuery);
			resultSet = statement.executeQuery();
			resultSet.next();
			RowCount = resultSet.getInt(1);
		} catch (SQLException e) {
			LOGGER.error(errStateCode + e.getSQLState());
			LOGGER.error(errExecuteQuery, e);
			throw new UserdefinedException(errExecuteQuery);
		} finally {
			finallyBlock(statement, resultSet);
		}
		return RowCount;
	}

	/**
	 * Execute a query for the test case ID and concatenate the data into a string.
	 *
	 * @param table  table name containing the test case id.
	 * @param column the data column to use as the result set.
	 * @param id     the test case id for which to retrieve the data.
	 *
	 * @return a string containing the column data.
	 */
	public String getCellDataTCN(String table, String column) {
		String query = String.format("SELECT * FROM %s WHERE Iteration = '%s' AND SubIteration = '%s' AND TC_ID=?",
				table, 1, currentSubIteration);
		String value = executeSQLQuery(query, column);

		return value;
	}

	public String getDynamicData(String datasheetName, String getValue, String ColumnName, String ColumnValue) {
		PreparedStatement statement = null;
		String data = null;
		ResultSet resultSet = null;
		String Query = null;
		try {
			Query = "SELECT *" + " FROM " + datasheetName + " WHERE " + ColumnName + " = ?";
			statement = connection.prepareStatement(Query);
			statement.setString(1, ColumnName);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				data = resultSet.getString(objdriver.getTestCaseName());
			}
		} catch (SQLException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLogWithNoSS(errExecuteQuery, Query + objdriver.getTestCaseName(), StatusReport.FAIL);
			LOGGER.error(errStateCode + e.getSQLState() + " " + errErrorCode + e.getErrorCode());
			LOGGER.error(errExecuteQuery, e);
		} finally {
			finallyBlock(statement, resultSet);
		}
		data = verfyemptyAndNull(data);
		return data;
	}

	/**
	 * Get the databased used on the server.
	 *
	 * @return databased used on the server.
	 */
	public String getDatabase() {
		return database;
	}
	// </editor-fold>

	/**
	 * Name : getDataIndependentArray Author: Uvaraj Date: 9/3/2014 Description:
	 * Reusable function to get data from table
	 */
	public synchronized List<String> getDataIndependentArray(String datasheetName, String rowIdentifierField,
			String rowIdentifier, String fieldName) {
		List<String> dataValue = new ArrayList<>();
		String query = "SELECT ? FROM ? WHERE ? = ?";
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(query);
			statement.setString(1, fieldName);
			statement.setString(2, datasheetName);
			statement.setString(3, rowIdentifierField);
			statement.setString(4, rowIdentifier);
			resultSet = statement.executeQuery();
		} catch (SQLException e) {
			report.updateTestLogWithNoSS(errExecuteQuery, query, StatusReport.FAIL);
			throw new UserdefinedException("Error while querying the test data sheet; Query :" + query
					+ "\ncurrentTestcase: " + objdriver.getTestCaseName());
		} finally {
			finallyBlock(statement, resultSet);
		}
		return dataValue;
	}

	/**
	 * Get the connection string used to connect to the database.
	 *
	 * @return database connection string.
	 */
	public String getDbUrl() {
		return dbUrl;
	}

	/**
	 * Retrieve the number of rows which have the colName flagged as 'Yes' in the
	 * specified table.
	 *
	 * @param table  table to query
	 * @param column column to test for 'Yes' being present.
	 *
	 * @return a count of the number of rows returned.
	 */
	public int getnoOfExecutableTestCases(String table, String column) {
		int rc;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String query = String.format("SELECT COUNT(*) FROM %s WHERE ?='Yes'", table);
		try {
			statement = connection.prepareStatement(query);
			statement.setString(1, column);
			resultSet = statement.executeQuery();
			resultSet.next();
			rc = resultSet.getInt(1);
		} catch (SQLException e) {
			LOGGER.error(errErrorCode + e.getErrorCode());
			LOGGER.error("Failed to execute query", e);
			throw new UserdefinedException(errExecuteQuery);
		} finally {
			finallyBlock(statement, resultSet);
		}
		return rc;
	}

	/**
	 * Get the port used to connect to the database.
	 *
	 * @return port used to connect to the database.
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Get the server used to connect to the database.
	 *
	 * @return server used to connect to the database.
	 */
	public String getServer() {
		return server;
	}

	/**
	 * Get the username used to connect to the database.
	 *
	 * @return username used to connect to the database.
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Update the table data.
	 *
	 * @param table  table name to update the data.
	 * @param column the data column to update the data.
	 * @param id     id whose Test Case data use to update.
	 * @param value  value to be updated.
	 */
	public void putData(String table, String column, String value) {
		String query = String.format(UPDATE_QUERY, table, column, value, objdriver.getTestCaseName(),
				currentSubIteration);
		executeUpdateQuery(query);
	}

	public void putDataForDynamicTcID(String table, String column, String value) {
		putData(table, column, value);
	}

	public void putCommonData(String table, String fieldName, String Columnvalue, String appName) {
		String query = String.format("UPDATE %s SET [%s] = '%s' WHERE Application = '%s'", table, fieldName,
				Columnvalue, appName);
		executeUpdateQuery(query);
	}

	public void putDynamicDataQuery(String query) {
		executeUpdateQuery(query);
	}

	public synchronized void putSubIterationData(String datatableName, String fieldName, String dataValue,
			int SubIteration) {
		String query = String.format(UPDATE_QUERY, datatableName, fieldName, dataValue, objdriver.getTestCaseName(),
				SubIteration);
		executeUpdateQuery(query);
	}

	// <editor-fold desc="Utility Methods">
	/**
	 * Retrieve the number of rows in the table.
	 *
	 * @param table name of the table from which to derive the row count.
	 *
	 * @return an integer representing the number of rows in the table.
	 */
	public int rowCount(String table, String testCaseID) {
		// PreparedStatement variable binding
		int rc;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String query = String.format("SELECT COUNT(*) FROM %s WHERE tTestCaseID = '%s'", table, testCaseID);
		try {
			statement = connection.prepareStatement(query);
			resultSet = statement.executeQuery();
			resultSet.next();
			rc = resultSet.getInt(1);
		} catch (SQLException e) {
			LOGGER.error(errStateCode + e.getSQLState());
			LOGGER.error(errExecuteQuery, e);
			throw new UserdefinedException(errExecuteQuery);
		} finally {
			finallyBlock(statement, resultSet);
		}
		return rc;
	}

	public void setCurrentRow(String table, String tCN, int iterator, int subIt) {
		String query = String.format("Insert into %s (tTestDescription,Iteration,SubIteration) values ('%s','%s','%s')",
				table, tCN, iterator, subIt);
		executeUpdateQuery(query);
	}

	/**
	 * Set the database to be used on the server.
	 *
	 * @param database database to be used on the server.
	 */
	public void setDatabase(String database) {
		this.database = database;
	}

	// <editor-fold desc="Getter/Setters">
	/**
	 * Set the connection string to be used to connect to the database.
	 *
	 * @param dbUrl database connection string.
	 */
	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	/**
	 * Set the password to be used to connect to the database.
	 *
	 * @param password password to be used to connect to the database.
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Set the port to be used to connect to the database.
	 *
	 * @param port port to be used to connect to the database.
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * Set the server to be used to connect to the database.
	 *
	 * @param server server to be used to connect to the database.
	 */
	public void setServer(String server) {
		this.server = server;
	}

	/**
	 * Set the username to be used to connect to the database.
	 *
	 * @param username username to be used to connect to the database.
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	// <editor-fold desc="Connection Facilitators">
	/**
	 * Connect to the MS SQL Database via connection string in dbUrl.
	 *
	 * @return a connection to the specified database or null on error.
	 */
	private Connection sqlConnectWithDriverManager() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbUrl);
		} catch (SQLTimeoutException e) {
			errOut("Timeout connecting to SQL Server. Exiting.", e);
		} catch (SQLServerException e) {
			errOut("Unable to connect to SQL Server. Exiting.", e);
		} catch (SQLException e) {
			errOut("Unable to connect to the Server. Exiting.", e);
		}
		return con;
	}

	/**
	 * Connect to the MS SQL Database using the SQLServerDataSource class.
	 *
	 * @return a connection to the specified database or null on error.
	 *
	 * @throws SQLException
	 */
	private Connection sqlConnectWithSqlServerDataSource() throws SQLException {
		Connection con = null;
		SQLServerDataSource ds = new SQLServerDataSource();
		ds.setServerName(server);
		ds.setPortNumber(port);
		ds.setUser(username);
		ds.setPassword(password);
		ds.setDatabaseName(database);
		ds.setTrustServerCertificate(true);
		try {
			con = ds.getConnection();
		} catch (SQLServerException e) {
			errOut("Unable to connect to SQL Server. Exiting.", e);
		}
		return con;
	}

	/**
	 * Update the data used flag in the table to reflect that test data was used.
	 *
	 * @param table table containing the test data.
	 * @param id    test case id whose data used flag to update.
	 */
	public void updateTcIndex(String table, String id) {
		// PreparedStatement variable binding
		PreparedStatement statement = null;
		String query = String.format("UPDATE %s SET tDataUsed='Yes' WHERE tTestCaseID='?'", table);
		try {
			statement = connection.prepareStatement(query);
			statement.setString(1, id);
			statement.execute();
		} catch (Exception e) {
			LOGGER.error(errStateCode + e);
			throw new UserdefinedException(errExecuteQuery);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				LOGGER.debug(errStatementClose, e);
			}
		}
	}

	public Connection CreateOracleConnection(String strConnectionURL, String strUsername, String strPassword) {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@" + strConnectionURL, strUsername, strPassword);
			report.updateTestLog(ORACLE_CONNECTION, "Connection established to URL: " + strConnectionURL, StatusReport.PASS);
		} catch (ClassNotFoundException e) {
			LOGGER.info(
					"Unable to locate ojdbc JAR to register class: 'oracle.jdbc.driver.getWebDriver().OracleDriver'. "
							+ e.getMessage());
			report.updateTestLog(ORACLE_CONNECTION,
					"Unable to locate ojdbc JAR to register class: 'oracle.jdbc.driver.getWebDriver().OracleDriver'.",
					StatusReport.FAIL);
		} catch (SQLException e) {
			LOGGER.info(UNABLETO_CONNECTDB + strConnectionURL + " Kindly check connection URL and credentials. "
					+ e.getMessage());
			report.updateTestLog(ORACLE_CONNECTION,
					UNABLETO_CONNECTDB + strConnectionURL + " Kindly check connection URL and credentials.",
					StatusReport.FAIL);
		}
		return conn;
	}

	public Connection CreateSQLServerConnection(String strConnectionURL, String strUsername, String strPassword) {
		Connection conn = null;
		try {
			// "oracle.jdbc.driver.getWebDriver().OracleDriver" modified by cogl5c on
			// 21/09/2020
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:sqlserver:" + strConnectionURL, strUsername, strPassword);
			report.updateTestLogWithNoSS(SQL_CONNECTION, "Connection established to URL: " + strConnectionURL,
					StatusReport.PASS);
		} catch (ClassNotFoundException e) {
			report.updateTestLogWithNoSS(SQL_CONNECTION,
					"Unable to locate ojdbc JAR to register class: 'oracle.jdbc.driver.getWebDriver().OracleDriver'.",
					StatusReport.FAIL);
		} catch (SQLException e) {
			report.updateTestLogWithNoSS(SQL_CONNECTION,
					UNABLETO_CONNECTDB + strConnectionURL + " Kindly check connection URL and credentials.",
					StatusReport.FAIL);
		}
		return conn;
	}

	/**
	 * @param con
	 *
	 * @Function To disconnect the created connection
	 */
	public void disconnectConnection(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				LOGGER.error(
						UNABLETO_CONNECTDB + conn + " Kindly check connection URL and credentials. " + e.getMessage());
			}
		}
	}

	public String checkDynamicSQLQuery(String Query, String column, String value) {
		PreparedStatement statement = null;
		String data = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(Query);
			statement.setString(1, value);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				data = resultSet.getString(column);
			}
		} catch (SQLException e) {
			throw new UserdefinedException("No test data found for the current row:");
		} finally {
			finallyBlock(statement, resultSet);
		}
		data = verfyemptyAndNull(data);
		return data;
	}

	public String getDataTCN(String table, String column) {
		String query = String.format("SELECT * FROM %s WHERE Iteration = '%s' AND SubIteration = '%s' AND TC_ID=?",
				table, 1, currentSubIteration);
		String value = checkSQLQuery(query, column);
		value = verfyemptyAndNull(value);
		return value;
	}

	public String checkSQLQuery(String Query, String column) {
		PreparedStatement statement = null;
		String data = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(Query);
			statement.setString(1, objdriver.getTestCaseName());
			resultSet = statement.executeQuery();
			data = resultSet.getString(column);
		} catch (SQLException e) {
			throw new UserdefinedException("No test data found for the current row:");
		} finally {
			finallyBlock(statement, resultSet);
		}
		data = verfyemptyAndNull(data);
		return data;
	}

	public void CloseConnectionDataBase(Connection conn) {
		if (conn != null) {
			try {
				if (!conn.isClosed()) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public ResultSet ExecuteQuery(Connection con, String strQuery) {
		ResultSet rs = null;
		try {
			if (!con.isClosed()) {
				rs = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)
						.executeQuery(strQuery);
			} else {
				report.updateTestLogWithNoSS(EXECUTEQUERY, "Connection to DB is closed. Unable to execute query.",
						StatusReport.FAIL);
			}
		} catch (SQLException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLogWithNoSS(EXECUTEQUERY,
					"Unable to execute query: \"" + strQuery + "\". " + e.getMessage(), StatusReport.FAIL);
			}
			e.printStackTrace();
		} catch (NullPointerException e) {
			report.updateTestLogWithNoSS(EXECUTEQUERY,
					"Connection is not established to required DB. " + e.getMessage(), StatusReport.FAIL);
		}
		return rs;
	}

	public String verfyemptyAndNull(String data) {
		if (data != null && !(data.equalsIgnoreCase("null"))) {
			data = data.trim();
		} else {
			data = "";
		}
		return data;
	}
}
