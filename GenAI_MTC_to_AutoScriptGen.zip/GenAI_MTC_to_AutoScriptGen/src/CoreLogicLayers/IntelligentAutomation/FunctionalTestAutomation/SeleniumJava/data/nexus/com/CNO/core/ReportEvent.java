/**
 * Package containing reusable libraries for external report Mechanism
 *
 * @author HCL
 */
package com.cnoinc.qa.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.cnoinc.qa.accelerators.TestEngine;
import com.cnoinc.qa.utilities.Utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

/**
 * A class containing methods to write report steps to the Extent report.
 */
public class ReportEvent extends TestEngine {
	private static final Logger LOGGER = LogManager.getLogger(ReportEvent.class.getName());
	public static final ExtentReports report = ExtentManager.getInstance();
	public static ThreadLocal<ExtentTest> extentTestThreadSafe = new ThreadLocal<>();
	static ExtentTest test;
	static String reportStepFont = "Cambria";
	public static final String SCREENSHOT_MESSAGE = "SCREENSHOT : ";
	public static final String BROWSERSTACK_USERNAME = "BROWSERSTACK_USERNAME";
	public static final String MOBILE = "Mobile";
	public static final String TESTMODE = "test.mode";
	public static final String EXCEPTIONOCCURED = "Exception Occured";
	public static final String ERROR = "error";
//	private static int stepCount = 0;

	/**
	 * public constructor
	 */
	public ReportEvent() {
		// Constructor used to generate class instance
	}

	/**
	 * Get the synchronized Thread for reporting
	 *
	 * @return synchronized Extenttest Object
	 */
	public static synchronized ExtentTest getTest() {
		return extentTestThreadSafe.get();
	}

	/**
	 * Helper method to create test report entries.
	 *
	 * @param comment comment to appear in the test step.
	 * @param color   color of the comment text.
	 * @param font    font of the comment text.
	 * @param bold    true to make comment bold.
	 * @param italic  true for comments to be in italics.
	 *
	 * @return HTML of the report line.
	 */
	private static String reportStep(String comment, String color, String font, boolean bold, boolean italic) {
		String html = "<font color='" + color + "' face='" + font + "'>";
		if (bold) {
			html += "<b>";
		}
		if (italic) {
			html += "<i>";
		}
		html += comment;
		if (bold) {
			html += "</b>";
		}
		if (italic) {
			html += "</i>";
		}
		html += "</font>";
		return html;
	}

	/**
	 * Capture a screenshot of the current desktop and add a failed step to the
	 * report.
	 *
	 * @param comment  note to attach to the failed step.
	 * @param testname describing the Test case folder name to which screenshot
	 *                 needs to be captured
	 *
	 * @return return the constructed HTML element with the note and the path to the
	 *         screenshot, null on failure.
	 */
	public static synchronized MediaEntityBuilder reportStepFailed(String comment) {
		MediaEntityBuilder html = null;
		String finalComments = null;
		errorcount++;
		try {
			finalComments = comment.split("\\-")[0];
			String path = Utility.failScreenshotCapture(finalComments, comment);
			String userpath = path.substring(1);
			String removeResultFolder1 = userpath.replace("\\", "<<>>");
			String removeResultFolder2[] = removeResultFolder1.split("<<>>");
			String finalpath = removeResultFolder2[2] + "\\" + removeResultFolder2[3];
			html = MediaEntityBuilder.createScreenCaptureFromPath(finalpath);
		} catch (Exception e) {
			LOGGER.error("Error recording failed step to report.", e);
			html = null;
		}
		return html;
	}

	public static String reportStepFailedNoSS(String comment) {
		errorcount++;
		return reportStep(comment, "red", reportStepFont, true, false);
	}

	/**
	 * Add a comment step to the report.
	 *
	 * @param comment note to attach to the comment step.
	 *
	 * @return return the constructed HTML element with the note.
	 */
	public static String reportStepInfo(String comment) {
		return reportStep(comment, "blue", reportStepFont, false, true);
	}

	/**
	 * Capture a screenshot of the current desktop and add a passed step to the
	 * report.
	 *
	 * @param comment  note to attach to the passed step.
	 * @param testname describing the Test case folder name to which screenshot
	 *                 needs to be captured
	 *
	 * @return return the constructed HTML element with the note and the path to the
	 *         screenshot, null on failure.
	 */
	public static MediaEntityBuilder reportStepPassed(String comment) {
		MediaEntityBuilder html = null;
		try {
			String path = Utility.passScreenshotCapture(comment, comment);
			String userpath = path.substring(1);
			String removeResultFolder1 = userpath.replace("\\", "<<>>");
			String removeResultFolder2[] = removeResultFolder1.split("<<>>");
			String finalpath = removeResultFolder2[2] + "\\" + removeResultFolder2[3];
			
			html = MediaEntityBuilder.createScreenCaptureFromPath(finalpath);
		} catch (Exception e) {
			LOGGER.error("Error recording passed step to report.", e);
			html = null;
		}
		return html;

	}

	public static String reportStepPassedNoSS(String comment) {
		return reportStep(comment, "black", reportStepFont, true, false);
	}

	/**
	 * Add a skipped step to the report.
	 *
	 * @param comment note to attach to the skipped step.
	 *
	 * @return return the constructed HTML element with the note.
	 */
	public static String reportStepSkip(String comment) {
		return reportStep(comment, "sky blue", reportStepFont, true, false);
	}

	/**
	 * Add a warning step to the report.
	 *
	 * @param comment note to attach to the warning step.
	 *
	 * @return return the constructed HTML element with the note.
	 */
	public static String reportStepWarning(String comment) {
		return reportStep(comment, "orange", reportStepFont, true, false);
	}

	/**
	 * Set the ExtentTest Object to synchronized
	 *
	 * @param test ExtentTest Object
	 */
	public static synchronized void setTest(ExtentTest test) {
		extentTestThreadSafe.set(test);
	}

	/**
	 * Add a node to the test report.
	 *
	 * @param testName                the name of the test that was executed.
	 * @param testStepExecutionStatus the step state, PASS, FAIL, etc.
	 * @param comment                 the comment to log with the test step status.
	 */
	public synchronized static void testStepReport(String testStepExecutionStatus, String comment) {
		
		// Throw an error if required data was provided
		if (("CLOSE").equalsIgnoreCase(testStepExecutionStatus)) {
			LOGGER.trace("Closing test results report.");
			report.flush();
			return;
		}
		if (("ReportEnd").equalsIgnoreCase(testStepExecutionStatus)) {
			LOGGER.trace("Ending test results report.");
			report.flush();
			return;
		}
		if (objdriver.getTestCaseName() == null) {
			throw new IllegalArgumentException("Unable to create report/test step - test name was not set.");
		}
		if (testStepExecutionStatus == null) {
			throw new IllegalArgumentException("Unable to create report/test step - execution status was not set.");
		}
		// Create a new test report the first time through
		if (getTest() == null) {
			setTest(report.createTest(objdriver.getTestCaseName()).assignCategory(System.getProperty("test.type")));
			objdriver.setStepCount(1);
		}
		manageReport(comment, failScreenshotCapture, passScreenshotCapture, testStepExecutionStatus, ScreenshotCapture);
	}


	public static void manageReport(String comment, String failScreenshotCapture, String passScreenshotCapture,
			String testStepExecutionStatus, String ScreenshotCapture) {
		// Manage the report

		switch (testStepExecutionStatus.toUpperCase()) {
		case "END":
			setTest(null);
			break;
		case "ERROR":
			if(objdriver.getDriver()!=null && objdriver.getAppiumDriver()==null && System.getenv(BROWSERSTACK_USERNAME) != null && System.getProperty(TESTMODE)!= null && System.getProperty(TESTMODE).equalsIgnoreCase(MOBILE)){
				annotate(EXCEPTIONOCCURED, ERROR, objdriver.getDriver());
			}else if(objdriver.getAppiumDriver()!=null) {
				annotate(EXCEPTIONOCCURED, ERROR, objdriver.getAppiumDriver());
			}
			getTest().log(Status.FAIL, comment);
			Assert.fail(comment);
			break;
		case "FAIL":
			errorcount++;
			if(objdriver.getDriver()!=null && objdriver.getAppiumDriver()==null && System.getenv(BROWSERSTACK_USERNAME) != null && System.getProperty(TESTMODE)!= null && System.getProperty(TESTMODE).equalsIgnoreCase(MOBILE)){
				annotate(EXCEPTIONOCCURED, ERROR, objdriver.getDriver());
			}else if(objdriver.getAppiumDriver()!=null) {
				annotate(EXCEPTIONOCCURED, ERROR, objdriver.getAppiumDriver());
			}
			if (failScreenshotCapture.equalsIgnoreCase("Y")&&objdriver.getAppiumDriver()==null) {
				getTest().log(Status.FAIL, comment, reportStepFailed(SCREENSHOT_MESSAGE + comment).build());
			}else {
				getTest().log(Status.FAIL, comment);
			}
			LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
                    configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.FAIL.toString(),
                    comment);
			objdriver.setStepCount(objdriver.getStepCount()+1);
			Assert.fail(comment);
			break;
		case "DBFAIL":
			errorcount++;
			getTest().log(Status.FAIL, comment);
			LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
                    configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.FAIL.toString(),
                    comment);
			objdriver.setStepCount(objdriver.getStepCount()+1);
			Assert.fail(comment);
			break;
		case "FATAL":
			getTest().log(Status.FAIL, comment);
			Assert.fail(comment);
			break;
		case "INFO":
			if(objdriver.getDriver()!=null && objdriver.getAppiumDriver()==null && System.getenv(BROWSERSTACK_USERNAME) != null && System.getProperty(TESTMODE)!= null && System.getProperty(TESTMODE).equalsIgnoreCase(MOBILE)){
				annotate(comment, "info", objdriver.getDriver());
			}else if(objdriver.getAppiumDriver()!=null) {
				annotate(comment, "info", objdriver.getAppiumDriver());
			}
			getTest().log(Status.INFO, comment);
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SyntheticMonitoring")) {
				LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
						configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.INFO.toString(),
						comment);
				objdriver.setStepCount(objdriver.getStepCount()+1);
			}
			break;
		case "DBPASS":
			getTest().log(Status.PASS, comment);
			LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
                    configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.PASS.toString(),
                    comment);
			objdriver.setStepCount(objdriver.getStepCount()+1);
			break;
		case "PASS":
			if (passScreenshotCapture.equalsIgnoreCase("Y")&&objdriver.getAppiumDriver()==null) {
				getTest().log(Status.PASS, comment, reportStepPassed(SCREENSHOT_MESSAGE + comment).build());
			}else {
				getTest().log(Status.PASS, comment);
			}
			LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
                    configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.PASS.toString(),
                    comment);
			objdriver.setStepCount(objdriver.getStepCount()+1);
			break;
		case "SCREENSHOT":
            if (ScreenshotCapture.equalsIgnoreCase("Y")&&objdriver.getAppiumDriver()==null) {
                   getTest().log(Status.PASS, comment, reportStepPassed(SCREENSHOT_MESSAGE + comment).build());
            } else {
                   getTest().log(Status.PASS, comment);
            }
            LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
                    configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.PASS.toString(),
                    comment);
			objdriver.setStepCount(objdriver.getStepCount()+1);
            break;
		case "SKIP":
			getTest().log(Status.SKIP, comment);
			break;
		case "WARNING":
			if(objdriver.getDriver()!=null && objdriver.getAppiumDriver()==null && System.getenv(BROWSERSTACK_USERNAME) != null && System.getProperty(TESTMODE)!= null && System.getProperty(TESTMODE).equalsIgnoreCase(MOBILE)){
				annotate(comment, "warn", objdriver.getDriver());
			}else if(objdriver.getAppiumDriver()!=null) {
				annotate(comment, "warn", objdriver.getAppiumDriver());
			}
			getTest().log(Status.WARNING, comment);
			LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
                    configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), StatusReport.WARNING.toString(),
                    comment);
			objdriver.setStepCount(objdriver.getStepCount()+1);
			break;
		default:
			getTest().log(Status.WARNING, comment);
		}
	}
	
	public void updateTestLog(String stepName, String comment, String exceptionMessage, StatusReport status) {
		String failScreenshotCapture = configProps.getProperty("takescreenshot_Fail");
		comment = stepName + " - " + comment;
		errorcount++;
		if (status.toString().equalsIgnoreCase("FAIL")) {
			if (failScreenshotCapture.equalsIgnoreCase("Y")) {
				getTest().log(Status.FAIL, comment, reportStepFailed(SCREENSHOT_MESSAGE + comment).build());
			} else {
				getTest().log(Status.FAIL, comment);
			}
			LogUtil.info(objdriver.getTestCaseName(), String.valueOf(objdriver.getStepCount()), objdriver.getUuid(),
					configProps.getProperty("AppID"), configProps.getProperty("ParentUniqueId"),configProps.getProperty("SequenceNumber"), Status.FAIL.toString(),
					comment+" - Exception: "+exceptionMessage);
			objdriver.setStepCount(objdriver.getStepCount()+1);
			Assert.fail(comment);
		}
	}

	public void updateTestLog(String stepName, String comment, StatusReport status) {
		if (!comment.startsWith(" ")) {
			comment = " " + comment;
		}
		if (status.equals(StatusReport.PASS)) {
			ReportEvent.testStepReport("Pass", stepName + " -" + comment);
		} else if (status.equals(StatusReport.FAIL)) {
			errorcount++;
			ReportEvent.testStepReport("Fail", stepName + " -" + comment);
			Assert.fail(comment);
		} else if (status.equals(StatusReport.INFO)) {
			ReportEvent.testStepReport("Info", stepName + " -" + comment);
		} else if (status.equals(StatusReport.DONE)) {
			ReportEvent.testStepReport("Info", stepName + " -" + comment);
		} else if (status.equals(StatusReport.WARNING)) {
			ReportEvent.testStepReport("Warning", stepName + " -" + comment);
		} else if (status.equals(StatusReport.SKIP)) {
			ReportEvent.testStepReport("SKIP", stepName + " -" + comment);
		} else if (status.equals(StatusReport.SCREENSHOT)) {
			ReportEvent.testStepReport("SCREENSHOT", stepName + " -" + comment);
		}
	}

	public void updateTestLog(String comment, StatusReport status) {
		if (!comment.startsWith(" ")) {
			comment = " " + comment;
		}
		if (status.equals(StatusReport.PASS)) {
			ReportEvent.testStepReport("Pass", comment);
		} else if (status.equals(StatusReport.FAIL)) {
			errorcount++;
			ReportEvent.testStepReport("Fail", comment);
			Assert.fail(comment);
		} else if (status.equals(StatusReport.INFO)) {
			ReportEvent.testStepReport("Info", comment);
		} else if (status.equals(StatusReport.WARNING)) {
			ReportEvent.testStepReport("Warning", comment);
		} else if (status.equals(StatusReport.SKIP)) {
			ReportEvent.testStepReport("SKIP", comment);
		} else if (status.equals(StatusReport.SCREENSHOT)) {
			ReportEvent.testStepReport("SCREENSHOT", comment);
		}
	}

	public void updateTestLogWithNoSS(String stepName, String comment, StatusReport status) {
		if (!comment.startsWith(" ")) {
			comment = " " + comment;
		}
		if (status.equals(StatusReport.PASS)) {
			ReportEvent.testStepReport("dbPass", stepName + " -" + comment);
		} else if (status.equals(StatusReport.FAIL)) {
			errorcount++;
			ReportEvent.testStepReport("dbfail", stepName + " -" + comment);
			Assert.fail(comment);
		}
	}
	
	// This method accepts the status, reason and WebDriver instance and marks the test on BrowserStack
    public static void markTestStatus(String status, String reason, WebDriver driver) {
        final JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("browserstack_executor: {\"action\": \"setSessionStatus\", \"arguments\": {\"status\": \""+ status + "\", \"reason\": \"" + reason + "\"}}");
    }

    public static void annotate(String data, String level, WebDriver driver) {
        final JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("browserstack_executor: {\"action\": \"annotate\", \"arguments\": {\"data\": \""+ data + "\", \"level\": \"" + level + "\"}}");
    }
}
