package com.cnoinc.qa.accelerators;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.aventstack.extentreports.model.Report;
import com.cnoinc.qa.support.StatusReport;
import com.cnoinc.qa.utilities.Utility;
import com.google.common.base.Function;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;

public abstract class ReusableLibrary extends ActionEngine {
	private static Logger LOGGER = LogManager.getLogger(ReusableLibrary.class.getName());
	private static final String ELEMENT_VERIFICATION = "Element Verification";
	private static final String IS_NOT_DISPLAYED = " is not Displayed";
	private static final String IS_DISPLAYED = " is Displayed";
	private static final String CLICK_BUTTON = "Click Button";
	private static final String CLICKED = "' clicked";
	private static final String IS_ENTERED_IN = " is entered in ";
	private static final String ENTER_TEXT = "EnterText";
	private static final String IS_NOT_ENTERED_IN = " is not entered in ";
	private static final String EXCEPTION_MESSAGE = "Exception Message : ";
	private static final String ARG_0 = "arguments[0].value='";
	private static final String NATIVE_APP = "NATIVE_APP";
	private static final String CONTENT = "content";
	private static final String TIMEOUT = "timeout";
	private static final String LABEL = "label";
	private static final String THRESHOLD = "threshold";
	private static final String MOBILE_CLICK = "mobile:button-text:click";
	private static final String REPO_FILE = "repositoryFile";
	private static final String HANDSET_FILE = "handsetFile";
	private static final String LOCATION = "location";
	private static final String MOBILE_TOUCH = "mobile:touch:drag";
	private static final String RESPONSE_CODE = "Response code : ";
	private static final String REPLACE_ME = "<<REPLACE ME>>";
	private static final String REPLACE_ME1 = "<<REPLACE ME1>>";
	private static final String WINDOW_SCROLL = "window.scrollTo(0,";
	private static final String NOT_CLICKED = "' not clicked";
	private static final String EXCEPTION = "Exception : ";
	private static final String IS_NOT_CLICKABLE_AT_POINT = "is not clickable at point";
	private static final String CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP = " clicked and accepted the Submission pop up";
	private static final String NOT_CLICK = " not clicked";
	private static final String CLICK = " clicked";
	private static final String MOUSE_HOVER = "Mouse Hover";
	private static final String ELEMENT_NOT_CLICKABLE = "Element is not clickable at point";
	private static final String ENTER_TEXT_PASSWORD = "EnterText_Password";
	private static final String PASSWORD_NOT_ENTERED = "Password is not entered in ";
	private static final String DROP_DOWN = "DropDown";
	private static final String ARG_ZERO_CLICK = "arguments[0].click();";
	private static final String IS_SELECTED_IN = " is selected in ";
	private static final String SELECT_VALUE = "Select Value";
	private static final String PRESENCE = " Presence";
	private static final String VALUE = "value";
	private static final String SEND_TAB = "SendTab";
	private static final String CLASS = "class";
	private static final String IS_ENABLED = " is Enabled";
	private static final String IS_NOT_ENABLED = " is not Enabled";
	private static final String DEFAULT_CHECK = "Default Check";
	private static final String SELECT_DROP_DOWN_VALUE = "selectDropDownValue";
	private static final String IS_NOT_AVAILABLE_IN = " is not available in ";
	private static final String TEXT_VERIFICATION = "Text verification";
	private static final String MM_DD_YYYY = "MM/dd/yyyy";
	private static final String YYYY_MM_DD = "yyyy-MM-dd";
	private static final String REPLACEME_2 = "<<REPLACE ME2>>";
	private static final String BY_XPATH = "By.xpath: ";
	private static final String SELECTED = "Selected: ";
	private static final String RADIO_GROUP_SELECTION = "Radio Group Selection";
	private static final String WINDOW_SCROLLBY_0 = "window.scrollBy(0,";
	private static final String READONLY = "readonly";
	private static final String ONLY_CLICK = "Click";
	private static final String TEXT_BOX = "Text Box ";
	private static final String IS_NOT_BLANK = "' is not blank";
	private HttpURLConnection httpURLConnect;
	private int responseCode;
	protected Map<String, Object> perfectoCommand = new HashMap<>();
	private static final String SUPPORTR_LIBRARIES = "supportlibraries";
	private static final String SAVED_FILES = "Saved_Files";
	public static boolean checkAscending(LinkedList<String> sortField) {
		String previous = "";
		for (String current : sortField) {
			if (current.compareToIgnoreCase(previous) < 0) {
				return false;
			}
			previous = current;
		}
		return true;
	}

	public static boolean checkDescending(LinkedList<String> sortField) {
		String previous = "";
		for (String current : sortField) {
			if (current.compareToIgnoreCase(previous) > 0) {
				return false;
			}
			previous = current;
		}
		return true;
	}

	/**
	 * Name : deleteDirectory Author: - Date: - Description: Deletes directory
	 */
	public static boolean deleteDirectory(File directory)
			throws NoSuchFileException, DirectoryNotEmptyException, IOException {
		boolean checkFileDeleted = false;
		if (directory.exists()) {
			File[] files = directory.listFiles();
			if (null != files) {
				for (File file2 : files) {
					if (file2.isDirectory()) {
						deleteDirectory(file2);
					} else {
						checkFileDeleted = Files.deleteIfExists(directory.toPath());
					}
				}
			}
		}
		return checkFileDeleted;
	}

	public static By GetObject(String ObjectName, String ObjectTemplate, int ObjectInstance) {
		ObjectTemplate = "(" + (ObjectTemplate.replace(REPLACE_ME, "'" + ObjectName + "'")) + ")";
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate + "[" + ObjectInstance + "]");
		return ReturnObject;
	}

	public static By GetObject(String ObjectName, String ObjectSubName, String ObjectTemplate) {
		ObjectTemplate = (ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"")).replace(replaceme,
				"\"" + ObjectSubName + "\"");
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate);
		return ReturnObject;
	}

	public static By GetObject(String ObjectName, String ObjectSubName, String ObjectTemplate, int ObjectInstance) {
		ObjectTemplate = "(" + (ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"").replace(replaceme,
				"\"" + ObjectSubName + "\"")) + ")";
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate + "[" + ObjectInstance + "]");
		return ReturnObject;
	}

	public static void HardDelay(long delayTime) throws InterruptedException {
		threadSleep(delayTime);
	}

	public static Properties loadPropertiesFile(String FilePath) throws IOException {
		try {
			Properties lproperties = new Properties();
			FileInputStream stream = new FileInputStream(FilePath);
			lproperties.load(stream);
			stream.close();
			return lproperties;
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
			throw new UserdefinedException("FileNotFoundException while loading the file " + FilePath);
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
			throw new UserdefinedException("IOException while loading the file " + FilePath);
		}
	}

	public static String removeQuotesInArrayIndex(String objectTemplate) {
		StringBuilder builder = new StringBuilder(objectTemplate);
		Pattern p = Pattern.compile("\"\\d{0,3}\"");
		Matcher m = p.matcher(builder);
		while (m.find()) {
			builder.deleteCharAt(m.start());
			builder.deleteCharAt(m.end() - 2);
			m = p.matcher(builder);
		}
		return builder.toString();
	}

	public static String replaceStringValues(String selector, String... values) {
		String[] args = new String[values.length + 1];
		System.arraycopy(values, 0, args, 0, values.length);
		return String.format(selector, (Object[]) args);
	}

	public static By replaceValues(String objType, String selector, String... values) {
		By tempObj = null;
		String[] args = new String[values.length + 1];
		System.arraycopy(values, 0, args, 0, values.length);
		String replaceValue = String.format(selector, (Object[]) args);
		if (objType.equalsIgnoreCase("CSS")) {
			tempObj = By.cssSelector(replaceValue);
		} else
			tempObj = By.xpath(replaceValue);
		return tempObj;
	}

	/**
	 * All reusuable Selenium Functions with Perfecto
	 */
	/**
	 * Function to switch the Context
	 *
	 * @param objdriver.getDriver()
	 *
	 * @RemoteWebDriver
	 *
	 * @param context
	 */
	protected static void switchToContext(RemoteWebDriver driver, String context) {
		RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
		Map<String, String> params = new HashMap<>();
		params.put("name", context);
		executeMethod.execute(DriverCommand.SWITCH_TO_CONTEXT, params);
	}

	@SuppressWarnings("deprecation")
	public static WebElement waitToGetElementFluent(final WebDriver driver, final By by) {
		try {
			new FluentWait<>(by).withTimeout(60, TimeUnit.SECONDS).pollingEvery(100, TimeUnit.MILLISECONDS)
					.until(new Function<By, Boolean>() {
						@Override
						public Boolean apply(By by) {
							try {
								WebElement element = driver.findElement(by);
								return element.isDisplayed();
							} catch (Exception e) {
								return false;
							}
						}
					});
		} catch (Exception e1) {
			LOGGER.error(e1.getMessage());
			throw new UserdefinedException("Failed to find the element " + by.toString() + " in the page");
		}
		try {
			WebElement retelement = null;
			retelement = driver.findElement(by);
			return retelement;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return null;
		}
	}

	private static SecureRandom random = new SecureRandom();

	public void acceptPopUp() {
		ajaxFluentPredicateWait();
		Alert Prompt = objdriver.getDriver().switchTo().alert();
		Prompt.accept();
		ajaxFluentPredicateWait();
	}

	public Date addDays(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(5, days);
		return cal.getTime();
	}

	public Date addHours(Date date, int hrs) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR, hrs);
		return cal.getTime();
	}

	public Date addMonth(Date date, int month) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, month);
		return cal.getTime();
	}

	public Date addYear(Date date, int year) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.YEAR, year);
		return cal.getTime();
	}

	public int[] ageCalculator(String strdate1, String strdate2) {
		int[] age = new int[3];
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate date1 = LocalDate.parse(strdate1, dateFormat);
		LocalDate date2 = LocalDate.parse(strdate2, dateFormat);
		Period datePeriod = Period.between(date1, date2);
		age[0] = datePeriod.getYears();
		age[1] = datePeriod.getMonths();
		age[2] = datePeriod.getDays();
		return age;
	}

	public void ajaxFluentPredicateWait() {
		handle_ajaxFluentPredicateWait("3000");
	}

	/**
	 * Function to check the bro
	 *
	 * @param Url
	 */
	protected void brokenLinkValidator(String Url) {
		urlLinkStatus(validationOfLinks(Url));
	}

	public void catchingClickElementException(WebDriverException e, By strobj, String strButtonName,
			Actions clickAction, WebElement element) {
		if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
			((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
			try {
				clickAction.moveToElement(element).sendKeys(Keys.ENTER).build().perform();
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
			} catch (Exception e1) {
				moveToLocationAndClick(strButtonName, element, e1);
			}
		} else {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.INFO);
			}
		}
	}

	public void catchingWebDriverException(By strobj, String strButtonName) {
		try {
			WebElement element = objdriver.getDriver().findElement(strobj);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
			element.click();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
		} catch (Exception e1) {
			WebElement element = objdriver.getDriver().findElement(strobj);
			moveToLocationAndClick(strButtonName, element, e1);
		}
	}

	public void checkField_MaxLength(By objID, String checkValue, int maxLength, String description) {
		String textValue = null;
		final String FIELD_VALIDATION = "Field validation";
		try {
			threadSleep(1);
			ImplicitWaitSwitchOFF();
			textValue = objdriver.getDriver().findElement(objID).getText();
			if (textValue.isEmpty()) {
				textValue = objdriver.getDriver().findElement(objID).getAttribute(VALUE);
			}
			ImplicitWaitSwitchON();
			if (textValue.length() > maxLength) {
				if (!(textValue.equals(checkValue) && textValue.length() > maxLength)) {
					report.updateTestLog(FIELD_VALIDATION, description + " field length is as expected", StatusReport.PASS);
				} else {
					report.updateTestLog(FIELD_VALIDATION, description + " field length is not as expected",
							StatusReport.FAIL);
				}
			}
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			report.updateTestLog(FIELD_VALIDATION, "Unable to fetch field value", StatusReport.FAIL);
		}
	}

	public void checkFieldErrorMsg(By objID, String expError, String description) {
		final String FIELD_COMPARISON = "Field comparison";
		String selectedvalue = null;
		try {
			threadSleep(1);
			ImplicitWaitSwitchOFF();
			selectedvalue = objdriver.getDriver().findElement(objID).getText();
			if (selectedvalue.isEmpty()) {
				selectedvalue = objdriver.getDriver().findElement(objID).getAttribute(VALUE);
			}
			ImplicitWaitSwitchON();
			if (selectedvalue.equals(expError)) {
				report.updateTestLog(FIELD_COMPARISON,
						"Expected error message \"" + expError + "\" is displayed for " + description + " field",
						StatusReport.PASS);
			} else {
				report.updateTestLog(FIELD_COMPARISON,
						"Expected error message \"" + expError + "\" is not displayed for " + description + " field",
						StatusReport.FAIL);
			}
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			report.updateTestLog(FIELD_COMPARISON, "Error message field is not available", StatusReport.FAIL);
		}
	}

	public void checkingClickElementWithPopUp(By strobj, String strButtonName) {
		try {
			WebElement element = objdriver.getDriver().findElement(strobj);
			if (element != null) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				element.click();
				threadSleep(5000);
				Alert Prompt = objdriver.getDriver().switchTo().alert();
				Prompt.accept();
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP,
						StatusReport.PASS);
			}
		} catch (NullPointerException n) {
			LOGGER.error("Element is null");
			throw new UserdefinedException("WebElement is null");
		}
	}

	public void checkingSelectRadioButton(By objIdYes, By objIdNo, String strValueToSelect) {
		try {
			if (strValueToSelect.equalsIgnoreCase("Yes")) {
				WebElement element = objdriver.getDriver().findElement(objIdYes);
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				((JavascriptExecutor) objdriver.getDriver()).executeScript(ARG_ZERO_CLICK, element);
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, "'" + strValueToSelect + CLICKED, StatusReport.PASS);
			} else if (strValueToSelect.equalsIgnoreCase("No")) {
				WebElement element = objdriver.getDriver().findElement(objIdNo);
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				((JavascriptExecutor) objdriver.getDriver()).executeScript(ARG_ZERO_CLICK, element);
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, "'" + strValueToSelect + CLICKED, StatusReport.PASS);
			}
		} catch (NullPointerException n) {
			throw new UserdefinedException("WebElement is empty");
		}
	}

	public boolean checkingStaleClick(By objIdYes, By objIdNo, String SelVal) {
		int count = 0;
		while (count < 200) {
			try {
				if (SelVal.equalsIgnoreCase("Yes")) {
					objdriver.getDriver().findElement(objIdYes).click();
				} else if (SelVal.equalsIgnoreCase("No")) {
					objdriver.getDriver().findElement(objIdNo).click();
				}
				count = count + 201;
			} catch (StaleElementReferenceException e) {
				count = count + 1;
			}
		}
		report.updateTestLog("Stale Click Radio button", "Radio button is selected as " + SelVal, StatusReport.PASS);
		return true;
	}

	public boolean checkingStaleClickRadio(By strobj, String objDesc) {
		int count = 0;
		while (count < 200) {
			try {
				ajaxFluentPredicateWait();
				WebElement element = objdriver.getDriver().findElement(strobj);
				element.click();
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, objDesc + " is clicked", StatusReport.PASS);
				count = count + 201;
			} catch (StaleElementReferenceException e) {
				count = count + 1;
			}
		}
		return true;
	}

	public boolean checkingStaleFunction(By strobj) {
		int count = 0;
		while (count < 100) {
			try {
				count = count + 20;
			} catch (StaleElementReferenceException e) {
				count = count + 1;
			}
		}
		return true;
	}

	public boolean checkingStateSelectFunction(By strobj, String SelVal) {
		int count = 0;
		while (count < 200) {
			try {
				Select select = new Select(objdriver.getDriver().findElement(strobj));
				select.selectByVisibleText(SelVal);
				ajaxFluentPredicateWait();
				count = count + 201;
			} catch (StaleElementReferenceException e) {
				count = count + 1;
			}
		}
		report.updateTestLog("Stale Select Function", strobj + " Lsitbox is selected as " + SelVal, StatusReport.PASS);
		return true;
	}

	public boolean CheckReadOnlyById(By objId, String strdesc) {
		try {
			ImplicitWaitSwitchOFF();
			if (!(isEnabled(objId, strdesc))) {
				report.updateTestLog("ReadOnly Check", "Element is Not Enabled & Read Only", StatusReport.INFO);
				ImplicitWaitSwitchON();
				return true;
			} else {
				report.updateTestLog(DEFAULT_CHECK, "Element is Enabled & not Read Only", StatusReport.INFO);
				ImplicitWaitSwitchON();
				return false;
			}
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			return false;
		}
	}

	public boolean checkTab(By ObjID) {
		int count = 0;
		while (count < 200) {
			try {
				objdriver.getDriver().findElement(ObjID).sendKeys(Keys.TAB);
				ajaxFluentPredicateWait();
				count = count + 201;
			} catch (StaleElementReferenceException e) {
				count = count + 1;
				ajaxFluentPredicateWait();
			}
		}
		report.updateTestLog(SEND_TAB, "---------Exception found in Stale SendTab ", StatusReport.PASS);
		return true;
	}

	public boolean CheckTextDefaultValue(By objId, String strValueToSelect, String reportvalue) {
		String value = null;
		try {
			value = GetTextValue(objId, reportvalue);
			if (strValueToSelect.equalsIgnoreCase(value)) {
				report.updateTestLog(DEFAULT_CHECK, "Default Value is selected", StatusReport.INFO);
				return true;
			} else {
				report.updateTestLog(DEFAULT_CHECK, "Other Value is selected", StatusReport.INFO);
				return true;
			}
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public void clear(By xpath) {
		objdriver.getDriver().findElement(xpath).clear();
	}

	public void clearText(By elementQuery, String strdesc) {
		try {
			WebElement element = objdriver.getDriver().findElement(elementQuery);
			element.clear();
			report.updateTestLog("Clear Text", "Text cleared in " + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, "Text is not cleared in " + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void ClickAnyJSElementWithoutWait(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_ZERO_CLICK, element);
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
					executor.executeScript(ARG_ZERO_CLICK, element);
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, element, e1);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
		}
	}

	/**
	 * Constructor to click the Web Element of the Object
	 *
	 * @param report        The {@link Report} object
	 * @param strButtonName The {@link String} object
	 * @param strobj        The {@link By} object
	 */
	public void ClickElement(By strobj, String strButtonName) {
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 180);
			wait.until(ExpectedConditions.elementToBeClickable(strobj));
			WebElement element = objdriver.getDriver().findElement(strobj);
			if (element != null) {
				element.click();
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
			} else {
				throw new NullPointerException(element + " is null ");
			}
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				catchingWebDriverException(strobj, strButtonName);
			} else {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
					report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
					report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
				} else {
					report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.INFO);
				}
			}
		} catch (Exception e) {
			WebElement element = objdriver.getDriver().findElement(strobj);
			element.click();
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.INFO);
			}
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param testCaseName
	 * @param context      - Context of App like NATIVE_APP or WEB
	 * @param appName      - Name of the App as displayed in Mobile
	 */
	public void clickElement_MobileApp(By strobj, String strButtonName) {
		WebElement element = null;
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getAppiumDriver(), 120);
			wait.until(ExpectedConditions.elementToBeClickable(strobj));
			element = objdriver.getAppiumDriver().findElement(strobj);
			element.click();
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, strButtonName + IS_NOT_DISPLAYED, StatusReport.FAIL);
		}
	}

	public void clickElement_NoReportMob(By strobj, String strButtonName) {
		WebElement element = null;
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getAppiumDriver(), 120);
			wait.until(ExpectedConditions.elementToBeClickable(strobj));
			element = objdriver.getAppiumDriver().findElement(strobj);
			element.click();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void ClickElement2Hover(By strMouseOverobj1, By strMouseOverobj2, By strobj, String strButtonName) {
		WebElement elementMouseHover1 = objdriver.getDriver().findElement(strMouseOverobj1);
		try {
			Actions actionBuilder = new Actions(objdriver.getDriver());
			actionBuilder.moveToElement(elementMouseHover1).perform();
			threadSleep(500);
			threadSleep();
			WebElement elementMouseHover2 = objdriver.getDriver().findElement(strMouseOverobj2);
			WebElement elementMouseClick = objdriver.getDriver().findElement(strobj);
			actionBuilder.moveToElement(elementMouseHover2).perform();
			threadSleep(500);
			actionBuilder.moveToElement(elementMouseClick).click().perform();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + elementMouseHover1.getLocation().y + ")");
				try {
					Actions actionBuilder = new Actions(objdriver.getDriver());
					actionBuilder.moveToElement(elementMouseHover1).perform();
					threadSleep(500);
					WebElement elementMouseHover2 = objdriver.getDriver().findElement(strMouseOverobj2);
					actionBuilder.moveToElement(elementMouseHover2).perform();
					threadSleep(500);
					WebElement elementMouseClick = objdriver.getDriver().findElement(strobj);
					actionBuilder.moveToElement(elementMouseClick).click().perform();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
					report.updateTestLog(CLICK_BUTTON, EXCEPTION + e1.getLocalizedMessage(), StatusReport.FAIL);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public boolean ClickElementByPartialId(String objId, String strElementType) {
		try {
			By by;
			if (strElementType.equals("BUTTON") || strElementType.equals("RDB") || strElementType.equals("CHECKBOX")) {
				by = By.xpath("//input[contains(@id,'" + objId + "')]");
			} else if (strElementType.equals("LINK")) {
				by = By.xpath("//a[contains(@id,'" + objId + "')]");
			} else if (strElementType.equals("TD")) {
				by = By.xpath("//td[contains(@id,'" + objId + "')]");
			} else if (strElementType.equals("ONCLICK")) {
				by = By.xpath("//a[contains(@onclick,'" + objId + "')]");
			} else if (strElementType.equals("IMAGE")) {
				by = By.xpath("//img[contains(@id,'" + objId + "')]");
			} else {
				by = By.xpath("//button[contains(@id,'" + objId + "')]");
			}
			WebElement element = waitToGetElementFluent(objdriver.getDriver(), by);
			if (element != null && element.isEnabled()) {
				element.click();
				report.updateTestLog("Click on " + strElementType, "'" + objId + "' clicked as expected", StatusReport.PASS);
			} else {
				report.updateTestLog("Click on " + strElementType, "'" + objId + "' not clicked as expected",
						StatusReport.FAIL);
				throw new UserdefinedException("Uanble to ClickElementByPartialId");
			}
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public void ClickElementHover(By strMouseOverobj, By strobj, String strButtonName) {
		WebElement elementMouseHover = objdriver.getDriver().findElement(strMouseOverobj);
		try {
			Actions actionBuilder = new Actions(objdriver.getDriver());
			actionBuilder.moveToElement(elementMouseHover).perform();
			threadSleep(500);
			WebElement elementMouseClick = objdriver.getDriver().findElement(strobj);
			actionBuilder.moveToElement(elementMouseClick).click().perform();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + elementMouseHover.getLocation().y + ")");
				try {
					Actions actionBuilder = new Actions(objdriver.getDriver());
					actionBuilder.moveToElement(elementMouseHover).perform();
					threadSleep(500);
					WebElement elementMouseClick = objdriver.getDriver().findElement(strobj);
					actionBuilder.moveToElement(elementMouseClick).click().perform();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, elementMouseHover, e1);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void ClickElements(By strobj, String strButtonName) {
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 180);
			wait.until(ExpectedConditions.elementToBeClickable(strobj));
			WebElement element = objdriver.getDriver().findElement(strobj);
			element.click();
			ajaxFluentPredicateWait();
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				catchingWebDriverException(strobj, strButtonName);
			}
		} catch (Exception e) {
			WebElement element = objdriver.getDriver().findElement(strobj);
			element.click();
		}
	}

	public void ClickElementWithActionEnter(By strobj, String strButtonName) {
		WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 180);
		wait.until(ExpectedConditions.elementToBeClickable(strobj));
		WebElement element = objdriver.getDriver().findElement(strobj);
		Actions clickAction = new Actions(objdriver.getDriver());
		try {
			clickAction.moveToElement(element).sendKeys(Keys.ENTER).build().perform();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
		} catch (WebDriverException e) {
			catchingClickElementException(e, strobj, strButtonName, clickAction, element);
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void ClickElementWithActions(By strobj, String strButtonName) {
		WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 180);
		wait.until(ExpectedConditions.elementToBeClickable(strobj));
		WebElement element = objdriver.getDriver().findElement(strobj);
		Actions clickAction = new Actions(objdriver.getDriver());
		try {
			clickAction.moveToElement(element).click(element).build().perform();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
		} catch (WebDriverException e) {
			catchingClickElementException(e, strobj, strButtonName, clickAction, element);
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.INFO);
			}
		}
	}

	public void ClickElementWithCancelPopUp(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			element.click();
			threadSleep(500);
			Alert Prompt = objdriver.getDriver().switchTo().alert();
			Prompt.dismiss();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + " clicked and rejected the Submission pop up",
					StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					element.click();
					threadSleep(500);
					Alert Prompt = objdriver.getDriver().switchTo().alert();
					Prompt.dismiss();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + " clicked and rejected the Submission pop up",
							StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, element, e1);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public String ClickElementWithCancelPopUpAndGetMessage(By strobj, String strButtonName) {
		String message = null;
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			element.click();
			threadSleep(500);
			Alert Prompt = objdriver.getDriver().switchTo().alert();
			message = Prompt.getText();
			Prompt.dismiss();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					element.click();
					threadSleep(500);
					Alert Prompt = objdriver.getDriver().switchTo().alert();
					message = Prompt.getText();
					Prompt.dismiss();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP,
							StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, element, e1);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			return message;
		}
		return message;
	}

	public void ClickElementWithoutAjaxWait(By strobj, String strButtonName) {
		try {
			WebElement element = objdriver.getDriver().findElement(strobj);
			threadSleep(2000);
			element.click();
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.INFO);
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void ClickElementWithPopUp(By strobj, String strButtonName) {
		try {
			WebElement element = objdriver.getDriver().findElement(strobj);
			if (element != null) {
				element.click();
				threadSleep(10000);
				Alert Prompt = objdriver.getDriver().switchTo().alert();
				Prompt.accept();
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP,
						StatusReport.PASS);
			}
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				try {
					checkingClickElementWithPopUp(strobj, strButtonName);
				} catch (Exception e1) {
					WebElement element = objdriver.getDriver().findElement(strobj);
					if (element != null) {
						moveToLocationAndClick(strButtonName, element, e1);
					}
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public String ClickElementWithPopUpAndGetMessage(By strobj, String strButtonName) {
		String message = null;
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			element.click();
			threadSleep(500);
			Alert Prompt = objdriver.getDriver().switchTo().alert();
			message = Prompt.getText();
			Prompt.accept();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					element.click();
					threadSleep(500);
					Alert Prompt = objdriver.getDriver().switchTo().alert();
					message = Prompt.getText();
					Prompt.accept();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP,
							StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, element, e1);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			return message;
		}
		return message;
	}

	public void ClickElementWithtwoPopUp(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			element.click();
			threadSleep(500);
			Alert Prompt1 = objdriver.getDriver().switchTo().alert();
			Prompt1.accept();
			threadSleep(500);
			Alert Prompt2 = objdriver.getDriver().switchTo().alert();
			Prompt2.accept();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					element.click();
					threadSleep(500);
					Alert Prompt1 = objdriver.getDriver().switchTo().alert();
					Prompt1.accept();
					threadSleep(500);
					Alert Prompt2 = objdriver.getDriver().switchTo().alert();
					Prompt2.accept();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICKED_AND_ACCEPTED_THE_SUBMISSION_POP_UP,
							StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, element, e1);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void clickingJSElement(WebElement element) {
		int runTime = 0;
		final int maxRunTime = 30;
		JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
		executor.executeScript(ARG_ZERO_CLICK, element);
		do {
			try {
				Alert Prompt = objdriver.getDriver().switchTo().alert();
				Prompt.accept();
				runTime++;
				if (runTime > maxRunTime) {
					break;
				}
			} catch (Exception e) {
				break;
			}
		} while (true);
	}

	/**
	 * Constructor to Click JavaScriptor Web Element of the Object
	 *
	 * @param report        The {@link Report} object
	 * @param strButtonName The {@link String} object
	 * @param strobj        The {@link By} object
	 */
	public void ClickJSElement(By strobj, String strButtonName) {
		WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 180);
		wait.until(ExpectedConditions.elementToBeClickable(strobj));
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_ZERO_CLICK, element);
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
					executor.executeScript(ARG_ZERO_CLICK, element);
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, element, e1);
				}
			} else {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
					report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
				} else {
					report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.INFO);
				}
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
		}
	}

	public void ClickJSElement_MobileWeb(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			element.click();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
		} catch (WebDriverException e) {
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_ZERO_CLICK, element);
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		}
	}

	public void clickJSElementMobile(By strobj, String strButtonName) {
		try {
			JavascriptExecutor executor = objdriver.getAppiumDriver();
			WebElement element = objdriver.getAppiumDriver().findElement(strobj);
			executor.executeScript(ARG_ZERO_CLICK, element);
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (Exception e) {
			objdriver.getDriver().findElement(strobj).click();
		}
	}

	/**
	 * Constructor to Click JavaScriptor Web Element of the Object
	 *
	 * @param report        The {@link Report} object
	 * @param strButtonName The {@link String} object
	 * @param strobj        The {@link By} object
	 */
	public void ClickJSElementWithAnyPopups(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			clickingJSElement(element);
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					clickingJSElement(element);
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			}
		} catch (Exception e2) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
		}
	}

	/**
	 * Constructor to Click JavaScriptor Web Element of the Object
	 *
	 * @param report        The {@link Report} object
	 * @param strButtonName The {@link String} object
	 * @param strobj        The {@link By} object
	 */
	public void ClickJSElementWithPopup(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_ZERO_CLICK, element);
			acceptPopUp();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
					executor.executeScript(ARG_ZERO_CLICK, element);
					acceptPopUp();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
		}
	}

	/**
	 * Constructor to Click JavaScriptor Web Element of the Object
	 *
	 * @param report        The {@link Report} object
	 * @param strButtonName The {@link String} object
	 * @param strobj        The {@link By} object
	 */
	public void ClickJSElementWithTwoPopups(By strobj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strobj);
		try {
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_ZERO_CLICK, element);
			Alert Prompt = objdriver.getDriver().switchTo().alert();
			Prompt.accept();
			Alert Prompt1 = objdriver.getDriver().switchTo().alert();
			Prompt1.accept();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
					executor.executeScript(ARG_ZERO_CLICK, element);
					Alert Prompt = objdriver.getDriver().switchTo().alert();
					Prompt.accept();
					Alert Prompt1 = objdriver.getDriver().switchTo().alert();
					Prompt1.accept();
					ajaxFluentPredicateWait();
					report.updateTestLog(CLICK_BUTTON, strButtonName + CLICK, StatusReport.PASS);
				} catch (Exception e1) {
					report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(CLICK_BUTTON, strButtonName + NOT_CLICK, StatusReport.FAIL);
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param context - Context of App like NATIVE_APP or WEB
	 * @param appName - Name of the App.
	 */
	protected void closeApp(final String context, final String appName) {
		if (context.equals(NATIVE_APP)) {
			perfectoCommand.put("name", appName);
			try {
				objdriver.getAppiumDriver().executeScript("mobile:application:close", perfectoCommand);
			} catch (final WebDriverException e) {
				LOGGER.error(e.getMessage());
			}
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param context - Context of App like NATIVE_APP or WEB
	 * @param appName - Identifier of the App.
	 */
	protected void closeAppWithIdentifier(final String context, final String bundleId) {
		if (context.equals(NATIVE_APP)) {
			perfectoCommand.put("identifier", bundleId);
			try {
				objdriver.getAppiumDriver().executeScript("mobile:application:close", perfectoCommand);
			} catch (final WebDriverException e) {
				LOGGER.error(e.getMessage());
			}
		}
	}

	public void closeBrowser() {
		objdriver.getDriver().close();
	}

	public void closeWindow() {
		objdriver.getDriver().close();
	}

	/**
	 * Constructor to Select the value from Web Element of the Object
	 *
	 * @param report   The {@link Report} object
	 * @param strdesc  The {@link String} object
	 * @param strValue The {@link String} object
	 * @param objName  The {@link By} object
	 */
	public void ComboSelectValue(By objName, String strValue, String strdesc) {
		try {
			ImplicitWaitSwitchOFF();
			Select select = new Select(objdriver.getDriver().findElement(objName));
			if (strValue != null) {
				ImplicitWaitSwitchOFF();
				select.selectByVisibleText(strValue);
				report.updateTestLog(SELECT_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
				ImplicitWaitSwitchON();
			}
		} catch (NoSuchElementException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
				report.updateTestLog(SELECT_VALUE, strValue + " is not selected in " + strdesc, StatusReport.FAIL);
			else
				report.updateTestLog(SELECT_VALUE, strValue + " is not selected in " + strdesc, StatusReport.INFO);
		} catch (StaleElementReferenceException e1) {
			StaleSelectFunction(objName, strValue);
		}
	}

	public void ComboSelectValueByIndex(By objName, String strValue, int index) {
		try {
			List<WebElement> selectOptions = new Select(objdriver.getDriver().findElement(objName)).getOptions();
			int size = selectOptions.size();
			Select select = new Select(objdriver.getDriver().findElement(objName));
			if (size > 1) {
				select.selectByIndex(index);
				report.updateTestLog(SELECT_VALUE, strValue, StatusReport.PASS);
			} else {
				report.updateTestLog(SELECT_VALUE, "No items are there in the list to select", StatusReport.FAIL);
			}
		} catch (NoSuchElementException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
				report.updateTestLog(SELECT_VALUE, strValue, StatusReport.FAIL);
			else
				report.updateTestLog(SELECT_VALUE, strValue, StatusReport.INFO);
		}
	}

	public void ComboSelectValueByValue(By objName, String strValue, String strdesc) {
		try {
			ImplicitWaitSwitchOFF();
			Select select = new Select(objdriver.getDriver().findElement(objName));
			if (strValue != null && strValue.equals("")) {
				ImplicitWaitSwitchOFF();
				select.selectByValue(strValue);
				report.updateTestLog(SELECT_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
				ImplicitWaitSwitchON();
			}
		} catch (NoSuchElementException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
				report.updateTestLog(SELECT_VALUE, strValue + " is not selected in " + strdesc, StatusReport.FAIL);
			else
				report.updateTestLog(SELECT_VALUE, strValue + " is not selected in " + strdesc, StatusReport.INFO);
		}
	}

	public int comparedatesWithTime(String date1, String date2) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy hh:mm:ss aa");
		try {
			Date d1 = sdf.parse(date1);
			Date d2 = sdf.parse(date2);
			return d1.compareTo(d2);
		} catch (ParseException e) {
			LOGGER.error(e.getMessage());
		}
		return -99;
	}

	public String convertDatetoString(Date date) {
		String currentDate = new SimpleDateFormat(MM_DD_YYYY).format(date);
		return currentDate;
	}

	public String convertDatetoString_AnyFormat(Date date, String strDate) {
		String currentDate = new SimpleDateFormat(strDate).format(date);
		return currentDate;
	}

	public String convertDatetoString_React(Date date) {
		String currentDate = new SimpleDateFormat(YYYY_MM_DD).format(date);
		return currentDate;
	}

	@Override
	public String convertDatetoString_SpecifedFormat(Date date) {
		String currentDate = new SimpleDateFormat("M/d/yyyy").format(date);
		return currentDate;
	}

	public Document ConvertFileToXMLDoc(String strFilePath) {
		final String READ_ACCORD_103 = "Read Accord 103";
		DocumentBuilderFactory dbFactory = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		File objFile = new File(strFilePath);
		try {
			dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
			dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
			dBuilder = dbFactory.newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new FileReader(objFile));
			doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e) {
			LOGGER.error(e.getLocalizedMessage());
			report.updateTestLog(READ_ACCORD_103, "Unable to parse Accord XML: " + strFilePath, StatusReport.FAIL);
		} catch (SAXException e) {
			LOGGER.error(e.getLocalizedMessage());
			report.updateTestLog(READ_ACCORD_103, "Unable to parse Accord XML: " + strFilePath, StatusReport.FAIL);
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getLocalizedMessage());
			report.updateTestLog(READ_ACCORD_103, "Unable to find Accord XML: " + strFilePath, StatusReport.FAIL);
		} catch (IOException e) {
			LOGGER.error(e.getLocalizedMessage());
			report.updateTestLog(READ_ACCORD_103, "Unable to read Accord XML: " + strFilePath, StatusReport.FAIL);
		}
		return doc;
	}

	public Date convertStringToDate(String date) {
		Date dt;
		try {
			dt = new SimpleDateFormat(MM_DD_YYYY).parse(date);
			return dt;
		} catch (ParseException e) {
			return null;
		}
	}

	public Date convertStringToDate_AnyFormat(String date, String strFormat) {
		Date dt;
		try {
			dt = new SimpleDateFormat(strFormat).parse(date);
			return dt;
		} catch (ParseException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog("Convert Date", "Unable to parase date " + date + " to format: " + strFormat,
					StatusReport.FAIL);
			}
			return null;
		}
	}

	public String ConvertStringToDate_FromAnyFormat(String date, String format) {
		String newdate = null;
		try {
			SimpleDateFormat source = new SimpleDateFormat(format);
			SimpleDateFormat targer = new SimpleDateFormat(MM_DD_YYYY);
			newdate = targer.format(source.parse(date));
			return newdate;
		} catch (ParseException e) {
			LOGGER.error(e.getMessage());
			report.updateTestLog("Convert Date", "Unable to parase date " + date + " to format: " + format,
					StatusReport.FAIL);
			return null;
		}
	}

	public int convertStringToInteger(String stringValue) {
		int integerValue = 0;
		try {
			integerValue = Integer.parseInt(stringValue);
		} catch (NumberFormatException numberFormatException) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog("Conversion", "Error While converting string to integer value : "
					+ Integer.parseInt(stringValue) + " Exception ; " + numberFormatException.fillInStackTrace(),
					StatusReport.FAIL);
		}
		}
		return integerValue;
	}

	public Document ConvertStringToXMLDoc(String strXMLContents) {
		DocumentBuilderFactory dbFactory = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		try {
			dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
			dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
			dBuilder = dbFactory.newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(strXMLContents));
			doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e) {
			LOGGER.error(e.getLocalizedMessage());
		} catch (SAXException e) {
			LOGGER.error(e.getLocalizedMessage());
		} catch (IOException e) {
			LOGGER.error(e.getLocalizedMessage());
		}
		return doc;
	}

	public String ConvertXMLDocToString(Document doc) {
		String output = null;
		try {
			TransformerFactory tf = javax.xml.transform.TransformerFactory.newInstance();
			tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
			output = writer.getBuffer().toString();
		} catch (Exception e) {
			LOGGER.error(e.getLocalizedMessage());
		}
		return output;
	}

	/**
	 * Function is used to generate C14 number
	 *
	 * @return C14 number
	 */
	public String createC14number() {
		long c14num = showRandomIntegerLong(100000000, 999999999, random);
		int posOne, posTwo, posThr, PosFour, posFive, PosSix, posSev, posEig, posNine, digit;
		posOne = Integer.parseInt(String.valueOf(c14num).substring(0, 1));
		posOne = posOne * 2;
		posThr = Integer.parseInt(String.valueOf(c14num).substring(2, 3));
		posThr = posThr * 2;
		posFive = Integer.parseInt(String.valueOf(c14num).substring(4, 5));
		posFive = posFive * 2;
		posSev = Integer.parseInt(String.valueOf(c14num).substring(6, 7));
		posSev = posSev * 2;
		posNine = Integer.parseInt(String.valueOf(c14num).substring(8, 9));
		posNine = posNine * 2;
		if (posOne >= 10)
			posOne = Integer.parseInt(String.valueOf(posOne).substring(0, 1))
					+ Integer.parseInt(String.valueOf(posOne).substring(1, 2));
		if (posThr >= 10)
			posThr = Integer.parseInt(String.valueOf(posThr).substring(0, 1))
					+ Integer.parseInt(String.valueOf(posThr).substring(1, 2));
		if (posFive >= 10)
			posFive = Integer.parseInt(String.valueOf(posFive).substring(0, 1))
					+ Integer.parseInt(String.valueOf(posFive).substring(1, 2));
		if (posSev >= 10)
			posSev = Integer.parseInt(String.valueOf(posSev).substring(0, 1))
					+ Integer.parseInt(String.valueOf(posSev).substring(1, 2));
		if (posNine >= 10)
			posNine = Integer.parseInt(String.valueOf(posNine).substring(0, 1))
					+ Integer.parseInt(String.valueOf(posNine).substring(1, 2));
		posTwo = Integer.parseInt(String.valueOf(c14num).substring(1, 2));
		PosFour = Integer.parseInt(String.valueOf(c14num).substring(3, 4));
		PosSix = Integer.parseInt(String.valueOf(c14num).substring(5, 6));
		posEig = Integer.parseInt(String.valueOf(c14num).substring(7, 8));
		int val = posOne + posTwo + posThr + PosFour + posFive + PosSix + posSev + posEig + posNine;
		if (((val % 10) - 10) == -10) {
			digit = 0;
		} else {
			digit = (val % 10) - 10;
			digit = Math.abs(digit);
		}
		String num = Long.toString(c14num) + digit;
		return num;
	}

	@SuppressWarnings("deprecation")
	public int DateDiffinDays(String date1, String date2) {
		Date dtDate1 = convertStringToDate(date1);
		Date dtDate2 = convertStringToDate(date2);
		int intDiff = dtDate1.getDate() - dtDate2.getDate();
		if (dtDate1.getDate() < dtDate2.getDate()) {
			intDiff -= 1;
		}
		if (dtDate1.getDate() == dtDate2.getDate() && (dtDate1.getDate() < dtDate2.getDate())) {
			intDiff -= 1;
		}
		return intDiff;
	}

	@SuppressWarnings("deprecation")
	public int DateDiffinYears(String date1, String date2) {
		Date dtDate1 = convertStringToDate(date1);
		Date dtDate2 = convertStringToDate(date2);
		int intDiff = dtDate1.getYear() - dtDate2.getYear();
		if (dtDate1.getMonth() < dtDate2.getMonth()) {
			intDiff -= 1;
		}
		if (dtDate1.getMonth() == dtDate2.getMonth() && (dtDate1.getDate() < dtDate2.getDate())) {
			intDiff -= 1;
		}
		return intDiff;
	}

	public String dateToString(String input, String currentformat, String format) {
		SimpleDateFormat parser = new SimpleDateFormat(currentformat);
		String formattedDate = "";
		try {
			Date date = parser.parse(input);
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			formattedDate = formatter.format(date);
		} catch (ParseException e) {
			LOGGER.error(e.getMessage());
		}
		return formattedDate;
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param handsetFile
	 */
	protected void deleteFromDevice(final String handsetFile) {
		perfectoCommand.put(HANDSET_FILE, handsetFile);
		objdriver.getAppiumDriver().executeScript("mobile:media:delete", perfectoCommand);
		perfectoCommand.clear();
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param repositoryFile
	 */
	protected void deleteFromRepository(final String repositoryFile) {
		perfectoCommand.put(REPO_FILE, repositoryFile);
		objdriver.getAppiumDriver().executeScript("mobile:media:delete", perfectoCommand);
		perfectoCommand.clear();
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param keyPress
	 */
	protected void deviceKeyPress(final String keyPress) {
		perfectoCommand.put("keySequence", keyPress);
		objdriver.getAppiumDriver().executeScript("mobile:presskey", perfectoCommand);
		perfectoCommand.clear();
	}

	public Date DisplaceDate(Date initDate, int months, int days, int years) {
		Date DisplacedDate = addYear(initDate, years);
		DisplacedDate = addMonth(DisplacedDate, months);
		DisplacedDate = addDays(DisplacedDate, days);
		return DisplacedDate;
	}

	/**
	 * Function to double Click the {@link WebDriver} object
	 *
	 * @param strobj  The {@link By} object
	 * @param strname The {@link String} object
	 * @param report  The {@link Report} object
	 */
	public void doubleClick(By strobj, String strname) {
		try {
			Actions actions = new Actions(objdriver.getDriver());
			WebElement element = objdriver.getDriver().findElement(strobj);
			threadSleep(2500);
			actions.doubleClick(element).perform();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, "'" + strname + CLICKED, StatusReport.PASS);
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog(ONLY_CLICK, "'" + strname + NOT_CLICKED, StatusReport.FAIL);
			report.updateTestLog(ONLY_CLICK, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		}
	}

	public void doubleClickMobile(By strobj, String strname) {
		try {
			Actions actions = new Actions(objdriver.getAppiumDriver());
			WebElement element = objdriver.getAppiumDriver().findElement(strobj);
			threadSleep(2500);
			actions.doubleClick(element).perform();
			ajaxFluentPredicateWait();
			report.updateTestLog(CLICK_BUTTON, "'" + strname + CLICKED, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ONLY_CLICK, "'" + strname + NOT_CLICKED, StatusReport.FAIL);
			report.updateTestLog(ONLY_CLICK, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param type - Type of report like pdf
	 */
	protected byte[] downloadReport(final String type) throws IOException {
		final String command = "mobile:report:download";
		final Map<String, String> params = new HashMap<>();
		params.put("type", type);
		final String downloadedReport = (String) (getRemoteWebDriver()).executeScript(command, params);
		final byte[] reportBytes = OutputType.BYTES.convertFromBase64Png(downloadedReport);
		return reportBytes;
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 */
	protected byte[] downloadWTReport() {
		final String reportUrl = (String) objdriver.getAppiumDriver().getCapabilities().getCapability("windTunnelReportUrl");
		String returnString = "<html><head><META http-equiv=\"refresh\" content=\"0;URL=";
		returnString = returnString + reportUrl + "\"></head><body /></html>";
		return returnString.getBytes();
	}

	public void dragToScroll(Object duration, Object fromX, Object fromY, Object toX, Object toY) {
		HashMap<String, Object> scrollobj = new HashMap<>();
		scrollobj.put("duration", duration);
		scrollobj.put("fromX", fromX);
		scrollobj.put("fromY", fromY);
		scrollobj.put("toX", toX);
		scrollobj.put("toY", toY);
		((JavascriptExecutor) objdriver.getDriver()).executeScript("mobile:dragFromToForDuration", scrollobj);
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param letter
	 */
	protected void drawLetter(final String letter) {
		final List<String> coordinates = new ArrayList<>();
		switch (letter) {
		case "A":
		case "B":
		case "C":
		case "D":
		case "F":
		case "G":
		case "H":
		case "I":
		case "J":
		case "K":
		case "L":
		case "M":
		case "N":
		case "O":
		case "Q":
		case "S":
		case "T":
		case "U":
		case "V":
		case "W":
		case "X":
		case "Y":
		case "Z":
			break;
		case "E":
			coordinates.add("42%,40%");
			coordinates.add("42%,60%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("42%,40%");
			coordinates.add("52%,40%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("42%,48%");
			coordinates.add("52%,48%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("42%,56%");
			coordinates.add("52%,56%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			break;
		case "P":
			coordinates.add("30%,40%");
			coordinates.add("30%,60%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("30%,40%");
			coordinates.add("40%,40%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("38%,40%");
			coordinates.add("38%,52%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("38%,48%");
			coordinates.add("28%,48%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			break;
		case "R":
			coordinates.add("54%,40%");
			coordinates.add("54%,60%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("54%,40%");
			coordinates.add("64%,40%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("62%,40%");
			coordinates.add("62%,52%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("62%,48%");
			coordinates.add("52%,48%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			coordinates.add("54%,48%");
			coordinates.add("64%,60%");
			perfectoCommand.put(LOCATION, coordinates);
			((JavascriptExecutor) objdriver.getDriver()).executeScript(MOBILE_TOUCH, perfectoCommand);
			perfectoCommand.clear();
			coordinates.clear();
			break;
		default:
			break;
		}
	}

	public void enteringData(boolean skipEmptyValues, String strValue, WebElement element, By elementQuery) {
		element.clear();
		strValue = strValue.trim();
		if (skipEmptyValues) {
			if (!strValue.equalsIgnoreCase("")) {
				element.sendKeys(strValue);
				objdriver.getDriver().findElement(elementQuery).sendKeys(Keys.TAB);
			}
		} else {
			element.sendKeys(strValue);
		}
	}

	public void enteringTextAndClearUsingActions(Actions actionBuilder, WebElement element, String strValue,
			By elementQuery) {
		try {
			actionBuilder.sendKeys(element, strValue).build().perform();
		} catch (StaleElementReferenceException a) {
			element = objdriver.getDriver().findElement(elementQuery);
			Explicitwait(elementQuery, 30);
			actionBuilder.sendKeys(element, strValue).build().perform();
		}
	}

	public boolean EnterNonPrefil(By ObjId, String desc, String strValue) {
		String value = GetTextValue(ObjId, desc);
		if (value.equalsIgnoreCase(strValue)) {
			LOGGER.info(value + "is equal to " + strValue);
		}
		return false;
	}

	/**
	 * Constructor to Enter text to the Web Element of the Object
	 *
	 * @param report       The {@link Report} object
	 * @param strdesc      The {@link String} object
	 * @param strValue     The {@link String} object
	 * @param elementQuery The {@link By} object
	 *
	 * @author - arun modified - added stale element reference exception
	 */
	public void EnterText(By elementQuery, String strValue, String strdesc) {
		WebElement element = objdriver.getDriver().findElement(elementQuery);
		try {
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.clear();
				element.sendKeys(strValue);
			}
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					if (!strValue.isEmpty()) {
						strValue = strValue.trim();
						element.clear();
						element.sendKeys(strValue);
					}
					report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
				} catch (Exception e1) {
					if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
					report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
					else
						report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.INFO);
				}
			} else {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
				report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
				}
			}
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		}
	}

	/**
	 * Constructor to Enter text to the Web Element of the Object
	 *
	 * @param report       The {@link Report} object
	 * @param strdesc      The {@link String} object
	 * @param strValue     The {@link String} object
	 * @param elementQuery The {@link By} object
	 */
	public void EnterText(By elementQuery, String strValue, String strdesc, Boolean skipEmptyValues) {
		WebElement element = objdriver.getDriver().findElement(elementQuery);
		try {
			enteringData(skipEmptyValues, strValue, element, elementQuery);
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					enteringData(skipEmptyValues, strValue, element, elementQuery);
					report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
				} catch (Exception e1) {
					if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
					report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
				}
			} else {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
				report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			}
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
		}
	}

	public void EnterText_Integer(By elementQuery, String strValue, String strdesc) {
		WebElement element = objdriver.getDriver().findElement(elementQuery);
		try {
			element.click();
			element.clear();
			threadSleep(1000);
			element.sendKeys("" + Integer.parseInt(strValue));
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void EnterText_Password(By elementQuery, String strValue, String strdesc) {
		WebElement element = objdriver.getDriver().findElement(elementQuery);
		try {
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.clear();
				element.sendKeys(strValue);
			}
			report.updateTestLog(ENTER_TEXT_PASSWORD, "Password is entered in " + strdesc, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(ELEMENT_NOT_CLICKABLE)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + element.getLocation().y + ")");
				try {
					if (!strValue.isEmpty()) {
						strValue = strValue.trim();
						element.clear();
						element.sendKeys(strValue);
					}
					report.updateTestLog(ENTER_TEXT_PASSWORD, "Password is entered in " + strdesc, StatusReport.PASS);
				} catch (Exception e1) {
					if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
					report.updateTestLog(ENTER_TEXT_PASSWORD, PASSWORD_NOT_ENTERED + strdesc, StatusReport.FAIL);
					report.updateTestLog(ENTER_TEXT_PASSWORD, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
				}
				}
			} else {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog(ENTER_TEXT_PASSWORD, PASSWORD_NOT_ENTERED + strdesc, StatusReport.FAIL);
				report.updateTestLog(ENTER_TEXT_PASSWORD, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
			}
			}
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog(ENTER_TEXT_PASSWORD, PASSWORD_NOT_ENTERED + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT_PASSWORD, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
		}
		}
	}

	public void EnterTextAndClearUsingActions(By elementQuery, String strValue, String strdesc) {
		try {
			Explicitwait(elementQuery, 30);
			WebElement element = objdriver.getDriver().findElement(elementQuery);
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				Actions actionBuilder = new Actions(objdriver.getDriver());
				actionBuilder.click(element).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
						.sendKeys(Keys.BACK_SPACE).build().perform();
				enteringTextAndClearUsingActions(actionBuilder, element, strValue, elementQuery);
			}
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT,
					strValue + IS_NOT_ENTERED_IN + strdesc + "and Exception Message is: " + e.getLocalizedMessage(),
					StatusReport.FAIL);
		}
	}

	public void EntertextAppium(By objName, String text) {
		objdriver.getAppiumDriver().findElement(objName).sendKeys(text);
	}

	public void EnterTextByChar(By elementQuery, String strValue, String strdesc) {
		char c;
		int i;
		try {
			WebElement element = objdriver.getDriver().findElement(elementQuery);
			for (i = 0; i < strValue.length(); i++) {
				c = strValue.charAt(i);
				String val = new StringBuilder().append(c).toString();
				if (!val.isEmpty()) {
					element.clear();
					element.sendKeys(val);
				}
			}
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.clear();
				element.sendKeys(strValue);
			}
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (StaleElementReferenceException a) {
			StaleEnterTextFunction(elementQuery, strValue, strdesc);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void enterTextMobile(By elementQuery, String strValue, String strdesc) {
		WebElement element = objdriver.getAppiumDriver().findElement(elementQuery);
		try {
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.clear();
				element.sendKeys(strValue);
			}
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void EnterTextwithActions(By elementQuery, String strValue, String strdesc) {
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 30);
			wait.until(ExpectedConditions.elementToBeClickable(elementQuery));
			WebElement element = objdriver.getDriver().findElement(elementQuery);
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				Actions actionBuilder = new Actions(objdriver.getDriver());
				actionBuilder.click(element).perform();
				element.clear();
				threadSleep(1500);
				actionBuilder.sendKeys(element, strValue).build().perform();
				element.sendKeys(Keys.TAB);
			}
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (StaleElementReferenceException a) {
			StaleEnterTextFunction(elementQuery, strValue, strdesc);
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
			} else {
				report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.INFO);
				report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.INFO);
			}
		}
	}

	public void EnterTextWithJS(By strobj, String text, String strdesc) {
		try {
			text = replaceSlash(text);
			WebElement element = objdriver.getDriver().findElement(strobj);
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_0 + text + "'", element);
			objdriver.getDriver().findElement(strobj).sendKeys(Keys.TAB);
			report.updateTestLog(ENTER_TEXT, text + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLog(ENTER_TEXT, text + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			else
				report.updateTestLog(ENTER_TEXT, text + IS_NOT_ENTERED_IN + strdesc, StatusReport.INFO);
		}
	}

	public void EnterTextWithJSAndPopUp(By strobj, String text, String strdesc) {
		try {
			text = replaceSlash(text);
			WebElement element = objdriver.getDriver().findElement(strobj);
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			executor.executeScript(ARG_0 + text + "'", element);
			objdriver.getDriver().findElement(strobj).sendKeys(Keys.TAB);
			objdriver.getDriver().switchTo().alert().accept();
			report.updateTestLog(ENTER_TEXT, text + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, text + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
		}
	}

	public void EnterTextwithKeys(By elementQuery, String strValue, String strdesc) {
		try {
			WebElement element = objdriver.getDriver().findElement(elementQuery);
			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), strValue);
			}
			report.updateTestLog(ENTER_TEXT, strValue + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (StaleElementReferenceException a) {
			StaleEnterTextFunction(elementQuery, strValue, strdesc);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, strValue + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
			report.updateTestLog(ENTER_TEXT, EXCEPTION_MESSAGE + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void EnterTextWithMobileJS(By strobj, String text, String strdesc) {
		try {
			text = replaceSlash(text);
			WebElement element = objdriver.getAppiumDriver().findElement(strobj);
			JavascriptExecutor executor = objdriver.getAppiumDriver();
			executor.executeScript(ARG_0 + text + "'", element);
			objdriver.getAppiumDriver().findElement(strobj).sendKeys(Keys.TAB);
			report.updateTestLog(ENTER_TEXT, text + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog(ENTER_TEXT, text + IS_NOT_ENTERED_IN + strdesc, StatusReport.FAIL);
		}
	}

	public boolean Explicitwait(By locator, int timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), timeout);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (org.openqa.selenium.TimeoutException exception) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
			report.updateTestLog("Wait for element",
					"Element " + locator.toString() + " not found within " + timeout + " Seconds.", StatusReport.FAIL);
			} else {
				report.updateTestLog("Wait for element",
						"Element " + locator.toString() + " not found within " + timeout + " Seconds.", StatusReport.INFO);
			}
			return false;
		}
		return true;
	}

	public boolean Explicitwait_Mobile(By locator, int timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getAppiumDriver(), timeout);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (org.openqa.selenium.TimeoutException exception) {
			report.updateTestLog("Wait for element",
					"Element " + locator.toString() + " not found within " + timeout + " Seconds.", StatusReport.FAIL);
			return false;
		}
		return true;
	}

	public String findFilePath(String path, String fileName) {
		File rootPath = new File(path);
		File[] files = rootPath.listFiles();
		if (files != null) {
			for (File file2 : files) {
				if (file2.isDirectory()) {
					String filePath = null;
					filePath = findFilePath(file2.getAbsolutePath(), fileName);
					if (filePath != null) {
						return filePath;
					}
				} else if (file2.getName().contains(fileName)) {
					return file2.getPath();
				}
			}
		}
		return null;
	}

	public void FocusElement(By id) {
		Point howerItem = objdriver.getDriver().findElement(id).getLocation();
		((JavascriptExecutor) objdriver.getDriver()).executeScript("return window.title;");
		threadSleep(3000);
		((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLLBY_0 + (howerItem.getY() - 50) + ");");
		threadSleep(3000);
	}

	public void fullpage_scroll_Screenshot(String pageTopic) {
		((JavascriptExecutor) objdriver.getDriver()).executeScript("window.scrollTo(0,0)");
		ajaxFluentPredicateWait();
		float height = ((Number) ((JavascriptExecutor) objdriver.getDriver())
				.executeScript("return window.innerHeight")).floatValue() - 100;
		float totalheight = ((Number) ((JavascriptExecutor) objdriver.getDriver())
				.executeScript("return document.body.scrollHeight")).floatValue();
		float numberofScrolls;
		int scrolls;
		if ((totalheight % height) == 0) {
			numberofScrolls = (totalheight / height);
		} else {
			numberofScrolls = (totalheight / height) + 1;
		}
		scrolls = (int) numberofScrolls;
		for (int s = 1; s <= scrolls; s++) {
			report.updateTestLog(pageTopic + " Page", pageTopic + " Page; Part " + s, StatusReport.PASS);
			ajaxFluentPredicateWait();
			((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLLBY_0 + height + ");");
		}
	}

	public static String generateAlphaNumeric(int length) {
		String randomString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		char[] c = new char[length];
		for (int i = 0; i < length; i++) {
			c[i] = randomString.charAt(random.nextInt(randomString.length()));
		}
		return new String(c);
	}

	public String generateRandomInt(int length) {
		String randomInt = "0123456789";
		char[] c = new char[length];
		for (int i = 0; i < length; i++) {
			if (i == 0) {
				randomInt = "123456789";
				c[i] = randomInt.charAt(random.nextInt(randomInt.length()));
				randomInt = "0123456789";
			} else {
				c[i] = randomInt.charAt(random.nextInt(randomInt.length()));
				while (c[i - 1] == c[i]) {
					c[i] = randomInt.charAt(random.nextInt(randomInt.length()));
				}
			}
		}
		return new String(c);
	}

	public String generateRandomString(int length) {
		String randomString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		char[] c = new char[length];
		for (int i = 0; i < length; i++) {
			c[i] = randomString.charAt(random.nextInt(randomString.length()));
		}
		return new String(c);
	}

	public String getAge(String DOB) {
		String strAge = null;
		int length = DOB.length();
		if (length <= 2) {
			return DOB;
		} else {
			try {
				Date CurrDate = getCurrentDate();
				Date dt = convertStringToDate_AnyFormat(DOB, MM_DD_YYYY);
				LocalDate dtDOB = dt.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				LocalDate crDt = CurrDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				int age = Period.between(dtDOB, crDt).getYears();
				strAge = Integer.toString(age);
				return strAge;
			} catch (Exception e) {
				report.updateTestLog("Calculate Age", "Age not calculated from DOB: " + DOB, StatusReport.FAIL);
				return strAge;
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public AppiumDriver getAppiumDriver() {
		return (AppiumDriver) objdriver.getAppiumDriver();
	}

	public String GetAttributeValue(By obj, String AttributeName) {
		try {
			WebElement element = objdriver.getDriver().findElement(obj);
			String attributeValue = element.getAttribute(AttributeName);
			return attributeValue;
		} catch (Exception e) {
			return null;
		}
	}

	public String getCellData(By strObject, int rowNum, int colNum) {
		String cellData = null;
		int i = 1;
		int j = 1;
		WebElement table = objdriver.getDriver().findElement(strObject);
		List<WebElement> allRows = table.findElements(By.tagName("tr"));
		for (WebElement row : allRows) {
			if (i == rowNum) {
				List<WebElement> cells = row.findElements(By.tagName("td"));
				for (WebElement cell : cells) {
					if (j == colNum)
						cellData = cell.getText();
					j++;
				}
			}
			i++;
		}
		return cellData;
	}

	public String getClientHeight(By element) {
		String clientHeight = null;
		String className = GetAttributeValue(element, CLASS);
		try {
			clientHeight = (((JavascriptExecutor) objdriver.getDriver()).executeScript(
					"return document.getElementsByClassName(\'" + className + "\')[0].clientHeight", className))
							.toString();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return clientHeight;
	}

	public Date getCurrentDate() {
		Date dtCurrentDate = new Timestamp(System.currentTimeMillis());
		String currentDate = new SimpleDateFormat(MM_DD_YYYY).format(dtCurrentDate);
		try {
			return (new SimpleDateFormat(MM_DD_YYYY).parse(currentDate));
		} catch (ParseException e) {
			return null;
		}
	}

	public String getCurrentUrl() {
		return objdriver.getDriver().getCurrentUrl();
	}

	public String getDate_Time(String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date();
		String date1 = dateFormat.format(date);
		return date1;
	}

	/**
	 * This method is used to find the days b/w two dates
	 */
	public long getDatedifference(String date1, String date2) {
		long diffDays = 0;
		SimpleDateFormat simpleDateFormat = null;
		simpleDateFormat = new SimpleDateFormat(MM_DD_YYYY);
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = simpleDateFormat.parse(date1);
			d2 = simpleDateFormat.parse(date2);
			long diff = d1.getTime() - d2.getTime();
			diffDays = diff / (24 * 60 * 60 * 1000);
		} catch (ParseException parseException) {
			LOGGER.error(parseException.getMessage());
		}
		return diffDays;
	}

	public String getDateofPreviousYear() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -1);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_YEAR));
		return new SimpleDateFormat(MM_DD_YYYY).format(calendar.getTime());
	}

	public String getDateofPreviousYear_React() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -1);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_YEAR));
		return new SimpleDateFormat(YYYY_MM_DD).format(calendar.getTime());
	}

	public String getDay(Date date) {
		String day;
		day = new SimpleDateFormat("d").format(date);
		return day;
	}

	public int getDayInNumber() {
		return Calendar.getInstance().get(Calendar.DATE);
	}

	public String getDayName(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, Locale.US);
	}

	public String getDayNameOfWeek(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.US);
	}

	public String getDOB(String Age) {
		String DOB = null;
		String year;
		String month;
		String Day;
		int Year;
		try {
			Date CurrDate = getCurrentDate();
			year = new SimpleDateFormat("yyyy").format(CurrDate);
			month = new SimpleDateFormat("M").format(CurrDate);
			Day = new SimpleDateFormat("d").format(CurrDate);
			int i;
			if (Integer.parseInt(Day) - 1 == 0) {
				month = (Integer.parseInt(month) - 1) + "";
				i = 28;
			} else {
				i = Integer.parseInt(Day) - 1;
			}
			Day = Integer.toString(i);
			Year = Integer.parseInt(year) - Integer.parseInt(Age);
			DOB = month + "/" + Day + "/" + Year;
			return DOB;
		} catch (Exception e) {
			report.updateTestLog("Calculate Age", "Age not calculated from DOB: " + DOB, StatusReport.FAIL);
			return DOB;
		}
	}

	public List<String> getDropDownFirstValue(By objName) {
		List<String> OptionValues = new ArrayList<>();
		List<WebElement> Options = new ArrayList<>();
		try {
			Select select = new Select(objdriver.getDriver().findElement(objName));
			Options = select.getOptions();
			for (WebElement option : Options) {
				OptionValues.add(option.getText());
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return OptionValues;
	}

	public String getDropDownSelectedValue(By objName) {
		String OptionValues = null;
		try {
			Select select = new Select(objdriver.getDriver().findElement(objName));
			WebElement option = select.getFirstSelectedOption();
			OptionValues = option.getText();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return OptionValues;
	}

	public WebElement getElement(String locator) {
		WebElement ele = objdriver.getDriver().findElement(By.xpath(locator));
		return ele;
	}

	public List<WebElement> getElements(String locator) {
		List<WebElement> lst = objdriver.getDriver().findElements(By.xpath(locator));
		return lst;
	}

	public String getElementTypeById(String objId) {
		WebElement element = objdriver.getDriver().findElement(By.id(objId));
		if (element.getTagName().equalsIgnoreCase("input")) {
			return element.getAttribute("type");
		} else {
			return element.getTagName();
		}
	}

	public String getElementTypeByXpath(String obj) {
		WebElement element = objdriver.getDriver().findElement(By.xpath(obj));
		if (element.getTagName().equalsIgnoreCase("input")) {
			return element.getAttribute("type");
		} else {
			return element.getTagName();
		}
	}

	public String getEval(String script) {
		Object jsResult = ((JavascriptExecutor) objdriver.getDriver()).executeScript(script);
		String result = (jsResult == null) ? "" : jsResult.toString();
		if (Boolean.valueOf(result)) {
			threadSleep(500);
		}
		if (!Boolean.valueOf(result)) {
			threadSleep(100);
		}
		return result;
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param handsetFile
	 * @param repositoryFile
	 */
	protected void getFileOnDevice(final String handsetFile, final String repositoryFile) {
		perfectoCommand.put(REPO_FILE, repositoryFile);
		perfectoCommand.put(HANDSET_FILE, handsetFile);
		objdriver.getAppiumDriver().executeScript("mobile:media:get", perfectoCommand);
		perfectoCommand.clear();
	}

	public String getFullMonth(Date date) {
		String fullmonth;
		fullmonth = new SimpleDateFormat("MMMM").format(date);
		return fullmonth;
	}

	public int getHeight(By byObject, String strdesc) {
		int getHeight = 0;
		WebElement webElement = objdriver.getDriver().findElement(byObject);
		getHeight = webElement.getSize().getHeight();
		return getHeight;
	}

	public void GetIntoFrame(By frameID) {
		threadSleep(3500);
		WebElement ele = objdriver.getDriver().findElement(frameID);
		objdriver.getDriver().switchTo().frame(ele);
	}

	public void GetIntoFrameByIndex(int index) {
		objdriver.getDriver().switchTo().frame(index);
	}

	public List<String> getListofDropDownValues(By objName) {
		List<String> getListofValues = new ArrayList<>();
		List<WebElement> getListofDropDownValues = new ArrayList<>();
		try {
			Select select = new Select(objdriver.getDriver().findElement(objName));
			getListofDropDownValues = select.getOptions();
			for (WebElement getListofDropDownValue : getListofDropDownValues) {
				getListofValues.add(getListofDropDownValue.getText());
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
		}
		return getListofValues;
	}

	public List<String> getListofDropDownValuesForPegaCPL(By objName) {
		List<String> getListofValues = new ArrayList<>();
		List<WebElement> getListofDropDownValues = new ArrayList<>();
		try {
			Select select = new Select(objdriver.getDriver().findElement(objName));
			getListofDropDownValues = select.getOptions();
			for (WebElement getListofDropDownValue : getListofDropDownValues) {
				getListofValues.add(getListofDropDownValue.getAttribute(LABEL));
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
		}
		return getListofValues;
	}

	public List<WebElement> getListOfElements(By mySelector) {
		List<WebElement> myElements = objdriver.getDriver().findElements(mySelector);
		return myElements;
	}

	// Gets the objects X location in pixels
	private String getLocationX(MobileElement me) {
		int x = me.getLocation().x;
		int width = (Integer.parseInt(me.getAttribute("width")) / 2) + x;
		return width + "";
	}

	// Gets the objects X location in pixels
	private String getLocationY(MobileElement me) {
		int y = me.getLocation().y;
		int height = (Integer.parseInt(me.getAttribute("height")) / 2) + y;
		return height + "";
	}

	public int getMaximumDaysinMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	public String getmonth(Date date) {
		String month;
		month = new SimpleDateFormat("M").format(date);
		return month;
	}

	public int getMonth_in_Number() {
		return (Calendar.getInstance().get(Calendar.MONTH) + 1);
	}

	public String getMonthForInt(int m) {
		String month = "invalid";
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] months = dfs.getMonths();
		if (m >= 0 && m <= 11) {
			month = months[m];
		}
		return month;
	}

	public int getMonthInt(String month) {
		int monthInt = 0;
		switch (month) {
		case "Jan":
		case "January":
			monthInt = 1;
			break;
		case "February":
		case "Feb":
			monthInt = 2;
			break;
		case "March":
		case "Mar":
			monthInt = 3;
			break;
		case "April":
		case "Apr":
			monthInt = 4;
			break;
		case "May":
			monthInt = 5;
			break;
		case "June":
		case "Jun":
			monthInt = 6;
			break;
		case "July":
		case "Jul":
			monthInt = 7;
			break;
		case "August":
		case "Aug":
			monthInt = 8;
			break;
		case "September":
		case "Sep":
			monthInt = 9;
			break;
		case "October":
		case "Oct":
			monthInt = 10;
			break;
		case "November":
		case "Nov":
			monthInt = 11;
			break;
		case "December":
		case "Dec":
			monthInt = 12;
			break;
		default:
			break;
		}
		return monthInt;
	}

	public By GetObject(int ObjectIndex, String ObjectTemplate) {
		String ObjectSubName = Integer.toString(ObjectIndex);
		By ReturnObject = By.xpath((ObjectTemplate.replace(REPLACE_ME1, ObjectSubName)));
		return ReturnObject;
	}

	public By GetObject(String objectName) {
		By returnObject = By.xpath(objectName);
		return returnObject;
	}

	public By GetObject(String ObjectName, int ObjectIndex, String ObjectTemplate) {
		String ObjectSubName = Integer.toString(ObjectIndex);
		By ReturnObject = By.xpath(
				(ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"")).replace(REPLACE_ME1, ObjectSubName));
		return ReturnObject;
	}

	public By GetObject(String ObjectName, String ObjectTemplate) {
		ObjectTemplate = ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"");
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate.replace(REPLACE_ME, "'" + ObjectName + "'"));
		return ReturnObject;
	}

	public By GetObject(String ObjectName, String ObjectSubName, String ObjectSubName1, String ObjectTemplate) {
		ObjectTemplate = ((ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"")).replace(replaceme,
				"\"" + ObjectSubName + "\"")).replace(REPLACEME_2, "\"" + ObjectSubName1 + "\"");
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate);
		return ReturnObject;
	}

	public By GetObject(String ObjectName, String ObjectSubName, String ObjectSubName1, String ObjectTemplate,
			int ObjectInstance) {
		ObjectTemplate = "(" + ((ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"")).replace(REPLACE_ME1,
				"\"" + ObjectSubName + "\"")).replace(REPLACEME_2, "\"" + ObjectSubName1 + "\"") + ")";
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate + "[" + ObjectInstance + "]");
		return ReturnObject;
	}

	public By GetObject(String ObjectName, String ObjectSubName, String ObjectSubName1, String ObjectSubName2,
			String ObjectTemplate) {
		ObjectTemplate = "(" + (((ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"")).replace(REPLACE_ME1,
				"\"" + ObjectSubName + "\"")).replace(REPLACEME_2, "\"" + ObjectSubName1 + "\""))
						.replace("<<REPLACE ME3>>", "\"" + ObjectSubName2 + "\"")
				+ ")";
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate);
		return ReturnObject;
	}

	public By GetObjectByIndex(By Object, int instance) {
		By returnObject = By.xpath("(" + Object.toString().replace(BY_XPATH, "") + ")[" + instance + "]");
		return returnObject;
	}

	public By GetObjectWithQuotes(String ObjectName, String ObjectTemplate, int ObjectInstance) {
		ObjectTemplate = "(" + (ObjectTemplate.replace(REPLACE_ME, "\"" + ObjectName + "\"")) + ")";
		ObjectTemplate = removeQuotesInArrayIndex(ObjectTemplate);
		By ReturnObject = By.xpath(ObjectTemplate + "[" + ObjectInstance + "]");
		return ReturnObject;
	}

	public void GetOutofFrame() {
		objdriver.getDriver().switchTo().defaultContent();
		threadSleep();
	}

	public String getPopUpMessage() {
		String message;
		Alert Prompt = objdriver.getDriver().switchTo().alert();
		message = Prompt.getText();
		return message;
	}

	public int getRandomNumberInRange(int min, int max) {
		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}
		return random.nextInt((max - min) + 1) + min;
	}

	public String getRandomPhoneNumber() {
		int num1, num2, num3;
		int set2, set3;
		num1 = random.nextInt(7) + 1;
		num2 = random.nextInt(8);
		num3 = random.nextInt(8);
		set2 = random.nextInt(643) + 100;
		set3 = random.nextInt(8999) + 1000;
		return (num1 + "" + num2 + "" + num3 + set2 + set3);
	}

	public String getRandomPostalCode() {
		int randomPIN = random.nextInt() * 9000 + 100000;
		return String.valueOf(randomPIN);
	}

	public RemoteWebDriver getRemoteWebDriver() {
		return (RemoteWebDriver) objdriver.getDriver();
	}

	private String GetrgbaColorCode(String color) {
		String strColorCodetoVerify = "";
		if (color.equalsIgnoreCase("Yellow"))
			strColorCodetoVerify = "rgba(255, 255, 0, 1)";
		else if (color.equalsIgnoreCase("Red"))
			strColorCodetoVerify = "rgba(243, 62, 62, 1)";
		else if (color.equalsIgnoreCase("Grey"))
			strColorCodetoVerify = "rgba(221, 221, 221, 1)";
		else if (color.equalsIgnoreCase("Black"))
			strColorCodetoVerify = "rgba(0, 0, 0, 1)";
		else if (color.equalsIgnoreCase("Blue"))
			strColorCodetoVerify = "rgba(0, 0, 255, 1)";
		else if (color.equalsIgnoreCase("Dark red"))
			strColorCodetoVerify = "rgba(255, 0, 0, 1)";
		else if (color.equalsIgnoreCase("Purple"))
			strColorCodetoVerify = "rgba(106, 114, 222, 1)";
		else if (color.equalsIgnoreCase("Strong red"))
			strColorCodetoVerify = "rgba(189, 0, 0, 1)";
		else if (color.equalsIgnoreCase("Reddish"))
			strColorCodetoVerify = "rgba(204, 51, 0, 1)";
		else
			strColorCodetoVerify = "";
		return strColorCodetoVerify;
	}

	public int getRowWithCellData(By strObject, String strExpected) {
		int intRow = 1;
		WebElement table = objdriver.getDriver().findElement(strObject);
		List<WebElement> allRows = table.findElements(By.tagName("tr"));
		for (WebElement row : allRows) {
			if (row.getText().contains(strExpected)) {
				break;
			}
			intRow++;
		}
		return intRow;
	}

	public String[] GetSelectAllOptions(By objId, String strdesc) {
		String selectedvalue[] = null;
		int i = 0;
		try {
			ImplicitWaitSwitchOFF();
			Select select = new Select(objdriver.getDriver().findElement(objId));
			List<WebElement> Options = select.getOptions();
			selectedvalue = new String[Options.size()];
			for (WebElement option : Options) {
				selectedvalue[i] = option.getText().trim();
				i = i + 1;
			}
			report.updateTestLog("Select Values", "All option values of " + strdesc + " are extracted successfully",
					StatusReport.PASS);
			ImplicitWaitSwitchON();
			LOGGER.info("start");
			for (String woorkweek : selectedvalue)
				LOGGER.info(woorkweek);
			LOGGER.info("End");
			return selectedvalue;
		} catch (NoSuchElementException e) {
			report.updateTestLog(SELECT_VALUE, "Option values of " + strdesc + " are not extracted successfully",
					StatusReport.FAIL);
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}

	/**
	 * Function to get the {@link String} object from Selected value from the
	 * WebElement of the Object
	 *
	 * @param report   The {@link Report} object
	 * @param strdesc  The {@link String} object
	 * @param strValue The {@link String} object
	 * @param strobj   The {@link By} object
	 *
	 * @return The {@link String} object
	 */
	public String GetSelectValue(By objId, String strdesc) {
		String selectedvalue = null;
		try {
			ImplicitWaitSwitchOFF();
			Select cmbObject = new Select(objdriver.getDriver().findElement(objId));
			selectedvalue = cmbObject.getFirstSelectedOption().getText();
			report.updateTestLog(SELECT_VALUE, selectedvalue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			report.updateTestLog(SELECT_VALUE, selectedvalue + IS_SELECTED_IN + strdesc, StatusReport.FAIL);
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}

	public String GetSelectValue_NoReport(By objId, String strdesc) {
		String selectedvalue = null;
		try {
			ImplicitWaitSwitchOFF();
			Select cmbObject = new Select(objdriver.getDriver().findElement(objId));
			selectedvalue = cmbObject.getFirstSelectedOption().getText();
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			report.updateTestLog(SELECT_VALUE, "No Such element " + strdesc, StatusReport.FAIL);
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}

	public String GetSelectValueIndex(By objId, Integer intIndexNum) {
		String selectedvalue = null;
		try {
			ImplicitWaitSwitchOFF();
			Select cmbObject = new Select(objdriver.getDriver().findElement(objId));
			cmbObject.selectByIndex(intIndexNum);
			selectedvalue = cmbObject.getFirstSelectedOption().getText();
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			return selectedvalue;
		}
	}

	public String getShortMonth(Date date) {
		String shortMonth;
		shortMonth = new SimpleDateFormat("MMM").format(date);
		return shortMonth;
	}

	public String getStartingDateofCurrentMonth() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return new SimpleDateFormat(MM_DD_YYYY).format(calendar.getTime());
	}

	public String getStartingDateofMonthAfterNextMonth() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 2);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return new SimpleDateFormat(MM_DD_YYYY).format(calendar.getTime());
	}

	public String getStartingDateofMonthAfterNextMonth_React() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 2);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return new SimpleDateFormat(YYYY_MM_DD).format(calendar.getTime());
	}

	public String getStartingDateofNextMonth() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 1);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return new SimpleDateFormat(MM_DD_YYYY).format(calendar.getTime());
	}

	public String getStartingDateofNextMonth_react() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 1);
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return new SimpleDateFormat(YYYY_MM_DD).format(calendar.getTime());
	}

	public boolean getTextBoxState(By ObjId, String boolObjectState, String objdesc) {
		final String TEXT_BOX_STATE = "Text Box State";
		try {
			String tempAttrValue = objdriver.getDriver().findElement(ObjId).getAttribute(READONLY);
			String AttrValue = tempAttrValue == null ? "" : tempAttrValue;
			if (AttrValue.equalsIgnoreCase("true") && boolObjectState.equalsIgnoreCase("disabled")
					|| (AttrValue.equals("") && boolObjectState.equalsIgnoreCase("enabled"))) {
				report.updateTestLog(TEXT_BOX_STATE, objdesc + " is " + boolObjectState, StatusReport.PASS);
				return true;
			} else {
				report.updateTestLog(TEXT_BOX_STATE, objdesc + " is NOT " + boolObjectState, StatusReport.FAIL);
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public String GetTextValue(By objId) {
		String selectedvalue = null;
		try {
			threadSleep(1000);
			ImplicitWaitSwitchOFF();
			selectedvalue = objdriver.getDriver().findElement(objId).getText();
			if (selectedvalue.isEmpty()) {
				selectedvalue = objdriver.getDriver().findElement(objId).getAttribute(VALUE);
			}
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}

	/**
	 * Function to get the {@link WebDriver} object
	 *
	 * @param report       The {@link Report} object
	 * @param strdesc      The {@link String} object
	 * @param elementQuery The {@link By} object
	 *
	 * @return The {@link String} object
	 */
	public String GetTextValue(By string, String strdesc) {
		String selectedvalue = null;
		try {
			ajaxFluentPredicateWait();
			ImplicitWaitSwitchOFF();
			selectedvalue = objdriver.getDriver().findElement(string).getText();
			if (selectedvalue.isEmpty()) {
				selectedvalue = objdriver.getDriver().findElement(string).getAttribute(VALUE);
			}
			report.updateTestLog("Text Value", selectedvalue + " is populated in " + strdesc, StatusReport.PASS);
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			report.updateTestLog("Text Value", "No value is populated in " + strdesc, StatusReport.FAIL);
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}
	
	public String GetTextValue_mobile(By string, String strdesc) {
		String selectedvalue = null;
		try {
			ajaxFluentPredicateWait();
			ImplicitWaitSwitchOFF_Mobile();
			selectedvalue = objdriver.getAppiumDriver().findElement(string).getText();
			if (selectedvalue.isEmpty()) {
				selectedvalue = objdriver.getAppiumDriver().findElement(string).getAttribute(VALUE);
			}
			report.updateTestLog("Text Value", selectedvalue + " is populated in " + strdesc, StatusReport.PASS);
			ImplicitWaitSwitchON_Mobile();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			report.updateTestLog("Text Value", "No value is populated in " + strdesc, StatusReport.FAIL);
			ImplicitWaitSwitchON_Mobile();
			return selectedvalue;
		}
	}

	public String GetTextValue_Noreport(By string, String strdesc) {
		String selectedvalue = null;
		try {
			ajaxFluentPredicateWait();
			ImplicitWaitSwitchOFF();
			selectedvalue = objdriver.getDriver().findElement(string).getText();
			if (selectedvalue.isEmpty()) {
				selectedvalue = objdriver.getDriver().findElement(string).getAttribute(VALUE);
			}
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}

	public String GetTextValue_NoWait(By string) {
		String selectedvalue = null;
		try {
			ajaxFluentPredicateWait();
			ImplicitWaitSwitchOFF();
			selectedvalue = objdriver.getDriver().findElement(string).getText();
			if (selectedvalue.isEmpty()) {
				selectedvalue = objdriver.getDriver().findElement(string).getAttribute(VALUE);
			}
			return selectedvalue;
		} catch (NoSuchElementException e) {
			return selectedvalue;
		}
	}

	public String GetTextValueByJs(By objId) {
		String value = null;
		try {
			WebElement element = objdriver.getDriver().findElement(objId);
			JavascriptExecutor executor = (JavascriptExecutor) objdriver.getDriver();
			value = (String) executor.executeScript("return arguments[0].innerHTML", element);
			return value;
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			return value;
		}
	}

	public String getTimeStamp() {
		String timestamp = (new Timestamp(new Date().getTime())).toString().replace(":", "-").replace(" ", "_");
		return (timestamp.substring(0, 19));
	}

	public String GetTitleTextValue(By objId) {
		String selectedvalue = null;
		try {
			ImplicitWaitSwitchOFF();
			selectedvalue = objdriver.getDriver().findElement(objId).getAttribute("title");
			ImplicitWaitSwitchON();
			return selectedvalue;
		} catch (NoSuchElementException e) {
			ImplicitWaitSwitchON();
			return selectedvalue;
		}
	}

	public String getTodaysDate(String testCaseName) {
		String currentDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		currentDate = formatter.format(date);
		report.updateTestLog("Today Date", "Today's Date : " + currentDate, StatusReport.PASS);
		return currentDate;
	}

	public String getTodaysDate_withoutTime() {
		String currentDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat(MM_DD_YYYY);
		Date date = new Date();
		currentDate = formatter.format(date);
		return currentDate;
	}

	public WebElement GetWebElement(By obj) {
		WebElement e = objdriver.getDriver().findElement(obj);
		return e;
	}

	public int getWidth(By byObject, String strdesc) {
		int getwidth = 0;
		WebElement webElement = objdriver.getDriver().findElement(byObject);
		getwidth = webElement.getSize().getWidth();
		return getwidth;
	}

	public int getWindowHandles() {
		int windowCount = objdriver.getDriver().getWindowHandles().size();
		return windowCount;
	}

	public String getWindowId() {
		return objdriver.getDriver().getWindowHandle();
	}

	public String getWindowTitle() {
		return objdriver.getDriver().getTitle();
	}

	public String GetXMLDocNodeAttributeValue(Document doc, String strNodeName, String attribute) {
		String strElementContent = "";
		NodeList nodeList = doc.getElementsByTagName(strNodeName);
		if (nodeList.getLength() == 1) {
			Node nNode = nodeList.item(0);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				strElementContent = eElement.getAttribute(attribute);
			}
		}
		return strElementContent;
	}

	public String GetXMLDocNodeValue(Document doc, String strNodeName) {
		String strElementContent = "";
		NodeList nodeList = doc.getElementsByTagName(strNodeName);
		if (nodeList.getLength() == 1) {
			Node nNode = nodeList.item(0);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				strElementContent = eElement.getTextContent();
			}
		}
		return strElementContent;
	}

	// Parses webelement to retrieve the xpath used for identification
	private String getXpathFromElement(MobileElement me) {
		return (me.toString().split("-> xpath: ")[1]).substring(0, (me.toString().split("-> xpath: ")[1]).length() - 1);
	}

	public String getYear(Date date) {
		String year;
		year = new SimpleDateFormat("yyyy").format(date);
		return year;
	}

	public int getYear_in_Number() {
		return Calendar.getInstance().get(Calendar.YEAR);
	}

	public void goback() {
		objdriver.getDriver().navigate().back();
	}

	public void handle_ajaxFluentPredicateWait(String timeout) {
		String message = "Waiting for all active application data transfers to finish during " + timeout
				+ " milliseconds... ";
		final String CATCH = "catch(err) {}";
		String applicationHasFinishedDataLoading = "pageHasLoaded = window.document.readyState == 'complete';"
				+ "if(!pageHasLoaded) {return false;}"
				+ "try { ajaxActiveRequests = window.jQuery.active==0; if(!ajaxActiveRequests) {return false;}}" + CATCH
				+ "try { ajaxActiveRequestcount = window.Ajax.activeRequestCount==0; if(!ajaxActiveRequestcount) {return false;}}"
				+ CATCH
				+ "try { dojolength = window.dojo.io.XMLHTTPTransport.inFlight.length==0; if(!dojolength) {return false;}}"
				+ CATCH
				+ "try { webformsinstance = window.Sys.WebForms.PageRequestManager.getInstance().get_isInAsyncPostBack()==false; if(!webformsinstance) {return false;}}"
				+ CATCH
				+ "try { tapestryreq = window.tapestry.isServingRequests()==false; if(!tapestryreq) {return false;}}"
				+ CATCH
				+ "try { ajaxIsNotDisplyed = window.document.getElementById('BusyBoxDiv').style.display=='none'; if(!ajaxIsNotDisplyed) {return false;}}"
				+ CATCH;
		applicationHasFinishedDataLoading = applicationHasFinishedDataLoading + "return true;";
		try {
			waitForCondition(applicationHasFinishedDataLoading, timeout, 1000);
			threadSleep(200);
		} catch (RuntimeException e) {
			if (isTimeoutException(e)) {
				message += "AJAX requests didn't finished in specified timeout!";
				report.updateTestLog("Ajax wait Timed Complete", message, StatusReport.INFO);
			} else {
				message += e.getMessage();
				report.updateTestLog("Ajax wait General Complete", message, StatusReport.INFO);
			}
		}
	}

	public void HasSelectedText(By object, String text, String desc) {
		String strGetText = GetSelectValue(object, desc);
		if (strGetText.equals(text)) {
			report.updateTestLog(TEXT_VERIFICATION, desc + "is displayed", StatusReport.PASS);
		} else {
			report.updateTestLog(TEXT_VERIFICATION, desc + "is not displayed", StatusReport.FAIL);
		}
	}

	public void HasText(By object, String text, String desc) {
		String strGetText = objdriver.getDriver().findElement(object).getText();
		if (strGetText.equals(text)) {
			report.updateTestLog(TEXT_VERIFICATION, desc + IS_DISPLAYED, StatusReport.PASS);
		} else {
			report.updateTestLog(TEXT_VERIFICATION, desc + IS_NOT_DISPLAYED, StatusReport.FAIL);
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param imagePath
	 */
	protected Boolean imageCheckpoint(String imagePath) {
		perfectoCommand.put(CONTENT, imagePath);
		perfectoCommand.put(THRESHOLD, "90");
		perfectoCommand.put("screen.top", "0%");
		perfectoCommand.put("screen.height", "100%");
		perfectoCommand.put("screen.left", "0%");
		perfectoCommand.put("screen.width", "100%");
		Object result = ((JavascriptExecutor) objdriver.getDriver()).executeScript("mobile:image:find",
				perfectoCommand);
		final boolean resultBool = Boolean.parseBoolean(result.toString());
		perfectoCommand.clear();
		return resultBool;
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param imagePath
	 */
	protected void imageClick(String imagePath) {
		perfectoCommand.put(CONTENT, imagePath);
		perfectoCommand.put(TIMEOUT, "5");
		perfectoCommand.put("screen.top", "0%");
		perfectoCommand.put("screen.height", "100%");
		perfectoCommand.put("screen.left", "0%");
		perfectoCommand.put("screen.width", "100%");
		((JavascriptExecutor) objdriver.getDriver()).executeScript("mobile:image:select", perfectoCommand);
		perfectoCommand.clear();
	}

	public void ImplicitWaitSwitchOFF() {
		objdriver.getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
	}

	public void ImplicitWaitSwitchOFF_Mobile() {
		objdriver.getAppiumDriver().manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
	}

	public void ImplicitWaitSwitchON() {
		objdriver.getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}

	public void ImplicitWaitSwitchON(long time) {
		objdriver.getDriver().manage().timeouts().implicitlyWait(time, TimeUnit.MILLISECONDS);
	}

	public void ImplicitWaitSwitchON_Mobile() {
		//ImplicitWaitSwitchON(5000);
		objdriver.getAppiumDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public void importDocument_AnyFormat(String strFileName) throws AWTException {
		ajaxFluentPredicateWait();
		String importPath = Utility.fnReadPropFile("externalBusinessFiles");
		File foldercheck = new File(importPath);
		if (!foldercheck.exists()) {
			report.updateTestLog("File upload", "Folder not present ", StatusReport.FAIL);
		} else {
			importPath = importPath + File.separator + strFileName;
			try {
				String filesavepath = "\"" + importPath + "\"";
				String toolName;
				if ((System.getProperty("browser.type").equalsIgnoreCase("CHROME"))
						|| (System.getProperty("browser.type").toString().equalsIgnoreCase("EDGE"))) {
					toolName = "Open.exe";
				} else {
					toolName = "Open_V2.exe";
				}
				String autoExecutablePath = Utility.fnReadPropFile("supportlibraries") + File.separator + toolName
						+ File.separator;
				Runtime.getRuntime().exec(autoExecutablePath + " " + filesavepath, null);
				threadSleep();
			} catch (Exception e) {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
				report.updateTestLog("File Open to upload", "File did not Opened", StatusReport.FAIL);
			}
		}
	}

	@Override
	public boolean isAlertPresent() {
		try {
			objdriver.getDriver().switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	public boolean isCheckedById(By objId) {
		String selectedvalue = null;
		boolean flag = false;
		try {
			selectedvalue = objdriver.getDriver().findElement(objId).getAttribute("checked");
			if (selectedvalue.equalsIgnoreCase("true")) {
				flag = true;
			}
			return flag;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method is used to check whether a button is clickable or not.
	 */
	public boolean isClickable(By strobj, String strButtonName) {
		try {
			WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), 180);
			wait.until(ExpectedConditions.elementToBeClickable(strobj));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public List<String> isDataPresentChecking(HSSFSheet sheet, HSSFWorkbook workbook, int colIndex) {
		try {
			DataFormatter dataFormatter = new DataFormatter();
			List<String> dataList = new ArrayList<>();
			int rowCount = sheet.getLastRowNum();
			String val = null;
			for (int i = 1; i <= rowCount; i++) {
				Row newRow = sheet.getRow(i);
				FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
				Cell cell = newRow.getCell(colIndex);
				if (cell == null || cell.getCellType() == CellType._NONE || cell.getCellType() == CellType.BLANK) {
					LOGGER.info(val + " is empty");
				} else {
					if (formulaEvaluator.evaluate(cell).getCellType() == CellType.ERROR) {
						throw new UserdefinedException(
								"Error in formula within this cell! " + "Error code: " + cell.getErrorCellValue());
					} else {
						val = dataFormatter.formatCellValue(formulaEvaluator.evaluateInCell(cell));
						dataList.add(val);
					}
				}
			}
			return dataList;
		} catch (Exception e) {
			throw new UserdefinedException(e.getMessage());
		}
	}

	@SuppressWarnings("resource")
	public boolean isDataPresentinExcel(String excelPath, String sheetName, String colName, String strData) {
		FileInputStream fileinputstream = null;
		HSSFWorkbook workbook;
		HSSFSheet sheet;
		Row row = null;
		Cell cell = null;
		int colIndex = 0;
		try {
			fileinputstream = new FileInputStream(excelPath);
			workbook = new HSSFWorkbook(fileinputstream);
			sheet = workbook.getSheet(sheetName);
			if (sheet == null) {
				throw new UserdefinedException(
						"The specified sheet \"" + sheetName + "\"" + "does not exist within the workbook \"");
			}
			DataFormatter dataFormatter = new DataFormatter();
			Iterator<Row> rowIterator = sheet.rowIterator();
			boolean colNotFound = true;
			while (rowIterator.hasNext() && colNotFound) {
				row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					cell = cellIterator.next();
					String cellValue = dataFormatter.formatCellValue(cell);
					if (cellValue.trim().equals(colName)) {
						colIndex = cell.getColumnIndex();
						colNotFound = false;
						break;
					}
					break;
				}
			}
			List<String> dataList = isDataPresentChecking(sheet, workbook, colIndex);
			for (String expData : dataList) {
				if (expData.trim().equals(strData)) {
					workbook.close();
					return true;
				}
			}
			workbook.close();
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
			throw new UserdefinedException("The specified file \"" + excelPath + "\" does not exist!");
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		return false;
	}

	public boolean isDateWithinRange(Date startDate, Date endDate, Date refDate) {
		return !(refDate.before(startDate) || refDate.after(endDate));
	}

	public boolean isDisabled(By ObjId, String objdesc) {
		Boolean enabled = true;
		try {
			ImplicitWaitSwitchOFF();
			enabled = objdriver.getDriver().findElement(ObjId).isEnabled();
			if (enabled) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_ENABLED, StatusReport.FAIL);
				ImplicitWaitSwitchON();
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_ENABLED, StatusReport.PASS);
				ImplicitWaitSwitchON();
			}
			return !enabled;
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_ENABLED, StatusReport.FAIL);
			ImplicitWaitSwitchON();
			return !enabled;
		}
	}

	public boolean isDisplayed(By ObjId, String objdesc) {
		Boolean displayed = false;
		try {
			ajaxFluentPredicateWait();
			threadSleep(2000);
			ImplicitWaitSwitchOFF();
			displayed = objdriver.getDriver().findElement(ObjId).isDisplayed();
			if (displayed) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_DISPLAYED, StatusReport.PASS);
				ImplicitWaitSwitchON();
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.INFO);
				ImplicitWaitSwitchON();
			}
			return displayed;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.INFO);
			ImplicitWaitSwitchON();
			return displayed;
		}
	}

	public boolean isDisplayed_MobileApp(By ObjId, String objdesc) {
		Boolean displayed = false;
		try {
			//ImplicitWaitSwitchON();
			ImplicitWaitSwitchOFF_Mobile();
			displayed = objdriver.getAppiumDriver().findElement(ObjId).isDisplayed();
			if (displayed) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_DISPLAYED, StatusReport.PASS);
				ImplicitWaitSwitchON_Mobile();
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.FAIL);
			}
			return displayed;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.INFO);
			LOGGER.error(e.getMessage());
			return displayed;
		}
	}

	public boolean isDisplayed_MobileAppWithSS(By ObjId, String objdesc) {
		Boolean displayed = false;
		try {
			displayed = objdriver.getAppiumDriver().findElement(ObjId).isDisplayed();
			if (displayed) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_DISPLAYED, StatusReport.PASS);
				ImplicitWaitSwitchON_Mobile();
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.FAIL);
				ImplicitWaitSwitchON_Mobile();
			}
			return displayed;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.FAIL);
			ImplicitWaitSwitchON_Mobile();
			LOGGER.error(e.getMessage());
			return displayed;
		}
	}

	public boolean isDisplayed_NoReport(By ObjId, String objdesc) {
		Boolean displayed = false;
		try {
			ajaxFluentPredicateWait();
			ImplicitWaitSwitchOFF();
			displayed = objdriver.getDriver().findElement(ObjId).isDisplayed();
			if (displayed) {
				ImplicitWaitSwitchON();
			}
			return displayed;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.INFO);
			ImplicitWaitSwitchON();
			return displayed;
		}
	}

	public boolean isDisplayed_NoReportMob(By ObjId, String objdesc) {
		Boolean displayed = false;
		try {
			ImplicitWaitSwitchOFF_Mobile();
			displayed = objdriver.getAppiumDriver().findElement(ObjId).isDisplayed();
			if (displayed) {
				ImplicitWaitSwitchON_Mobile();
			}
			return displayed;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.FAIL);
			ImplicitWaitSwitchON_Mobile();
			return displayed;
		}
	}

	public void isDisplayed_report(By ObjId, String objdesc) {
		Boolean displayed = false;
		try {

			displayed = objdriver.getDriver().findElement(ObjId).isDisplayed();
			if (displayed) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_DISPLAYED, StatusReport.PASS);
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.FAIL);
			}
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_DISPLAYED, StatusReport.FAIL);
		}
	}

	public boolean isEnabled(By ObjId, String objdesc) {
		Boolean enabled = false;
		try {
			ImplicitWaitSwitchOFF();
			enabled = objdriver.getDriver().findElement(ObjId).isEnabled();
			if (enabled) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_ENABLED, StatusReport.PASS);
				ImplicitWaitSwitchON();
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_ENABLED, StatusReport.INFO);
				ImplicitWaitSwitchON();
			}
			return enabled;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + IS_NOT_ENABLED, StatusReport.INFO);
			ImplicitWaitSwitchON();
			return enabled;
		}
	}

	public boolean isEnabled_NoReport(By ObjId, String objdesc) {
		Boolean enabled = false;
		try {
			ImplicitWaitSwitchOFF();
			enabled = objdriver.getDriver().findElement(ObjId).isEnabled();
			ImplicitWaitSwitchON();
			return enabled;
		} catch (Exception e) {
			ImplicitWaitSwitchON();
			return enabled;
		}
	}

	/**
	 * Constructor to Verify the Web Element of the Object Availability
	 *
	 * @param report  The {@link Report} object
	 * @param strdesc The {@link String} object
	 * @param strobj  The {@link By} object
	 */
	public boolean IsObjectPresent(By strobj, String objdesc) {
		try {
			ImplicitWaitSwitchOFF();
			List<WebElement> Element = objdriver.getDriver().findElements(strobj);
			if (Element.size() > 0) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + PRESENCE, StatusReport.PASS);
				ImplicitWaitSwitchON();
				return true;
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " not Presence", StatusReport.INFO);
				ImplicitWaitSwitchON();
				return false;
			}
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + "not Presence", StatusReport.INFO);
			ImplicitWaitSwitchON();
			return false;
		}
	}

	public boolean IsObjectPresentWithoutAjaxWait(By strobj, String objdesc) {
		try {
			ImplicitWaitSwitchOFF();
			List<WebElement> Element = objdriver.getDriver().findElements(strobj);
			if (Element.size() > 0) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + PRESENCE, StatusReport.PASS);
				return true;
			} else {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " not Presence", StatusReport.INFO);
				return false;
			}
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + PRESENCE, StatusReport.INFO);
			ImplicitWaitSwitchON();
			return false;
		}
	}

	public boolean isSelected(By objId, String objdesc) {
		Boolean displayed = false;
		try {
			ImplicitWaitSwitchON();
			displayed = objdriver.getDriver().findElement(objId).isSelected();
			if (displayed) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " is Selected", StatusReport.PASS);
			}
			return displayed;
		} catch (Exception e) {
			report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " is not Selected", StatusReport.INFO);
			ImplicitWaitSwitchON();
			return displayed;
		}
	}

	public void isTextBoxBlank(By objID, String strDesc) {
		String blankTextBox;
		try {
			WebElement element = objdriver.getDriver().findElement(objID);
			blankTextBox = element.getText();
			if (blankTextBox.isEmpty()) {
				report.updateTestLog(TEXT_BOX, "'" + strDesc + "' is blank", StatusReport.PASS);
			}
		} catch (Exception e) {
			report.updateTestLog(TEXT_BOX, "'" + strDesc + IS_NOT_BLANK, StatusReport.FAIL);
			report.updateTestLog("Text Box", EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public boolean isTextBoxDisabled(By ObjId, String objdesc) {
		try {
			String AttrValue = objdriver.getDriver().findElement(ObjId).getAttribute(READONLY);
			if (AttrValue.equalsIgnoreCase("true")) {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SyntheticMonitoring")) {
					report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " is Disabled", StatusReport.PASS);
				}
				return true;
			} else {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SyntheticMonitoring")) {
					report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " is not Disabled", StatusReport.FAIL);
				}
				return false;
			}
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SyntheticMonitoring")) {
				report.updateTestLog(ELEMENT_VERIFICATION, objdesc + " is not Disabled", StatusReport.FAIL);
			}
			return false;
		}
	}

	public boolean isTextBoxDisabled_noReport(By ObjId, String objdesc) {
		try {
			String AttrValue = objdriver.getDriver().findElement(ObjId).getAttribute(READONLY);
			if (!AttrValue.equalsIgnoreCase("true")) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isTextBoxEmpty(By objID, String strDesc) {
		boolean isTextBoxEmpty = false;
		String blankTextBox;
		try {
			WebElement element = objdriver.getDriver().findElement(objID);
			blankTextBox = element.getText();
			if (blankTextBox.isEmpty()) {
				isTextBoxEmpty = true;
				report.updateTestLog(TEXT_BOX, "'" + strDesc + "' is blank", StatusReport.PASS);
			} else {
				isTextBoxEmpty = false;
				report.updateTestLog(TEXT_BOX, "'" + strDesc + IS_NOT_BLANK, StatusReport.INFO);
			}
		} catch (Exception e) {
			report.updateTestLog(TEXT_BOX, "'" + strDesc + IS_NOT_BLANK, StatusReport.FAIL);
			report.updateTestLog("Text Box", EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
		return isTextBoxEmpty;
	}

	public boolean isTextPresent(String textToVerify) {
		Boolean textAvail = objdriver.getDriver().getPageSource().contains(textToVerify);
		return textAvail;
	}

	private boolean isTimeoutException(RuntimeException e) {
		return e != null && e.getMessage() != null && e.getMessage().matches("^Timed out after \\d+ms$");
	}

	/**
	 * Constructor to Select the multiple value from Web Element of the Object
	 *
	 * @param report   The {@link Report} object
	 * @param strdesc  The {@link String} object
	 * @param strValue The {@link String} object
	 * @param objName  The {@link By} object
	 */
	public void ListMultiSelectValue(By objName, String strValue, String strdesc) {
		try {
			ImplicitWaitSwitchOFF();
			Select select = new Select(objdriver.getDriver().findElement(objName));
			if (strValue != null) {
				select.deselectAll();
				select.selectByVisibleText(strValue);
			}
			report.updateTestLog(SELECT_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
			ImplicitWaitSwitchON();
		} catch (NoSuchElementException e) {
			report.updateTestLog(SELECT_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.FAIL);
			ImplicitWaitSwitchON();
		}
	}

	public void maximizeWindow() {
		objdriver.getDriver().manage().window().maximize();
	}

	public void ModifyXMLNodeValue(Document doc, String strNodeName, String strUpdatedValue) {
		NodeList nodeList = doc.getElementsByTagName(strNodeName);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node nNode = nodeList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				eElement.setTextContent(strUpdatedValue);
			}
		}
	}

	public void MouseHover(By strMouseOverobj, String strButtonName) {
		WebElement elementMouseHover = objdriver.getDriver().findElement(strMouseOverobj);
		try {
			Actions actionBuilder = new Actions(objdriver.getDriver());
			actionBuilder.moveToElement(elementMouseHover).perform();
			threadSleep(500);
			report.updateTestLog(MOUSE_HOVER, "Successfully mouse hover on the element: " + strButtonName, StatusReport.PASS);
		} catch (WebDriverException e) {
			if (e.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
				((JavascriptExecutor) objdriver.getDriver())
						.executeScript(WINDOW_SCROLL + elementMouseHover.getLocation().y + ")");
				try {
					Actions actionBuilder = new Actions(objdriver.getDriver());
					actionBuilder.moveToElement(elementMouseHover).perform();
					report.updateTestLog(MOUSE_HOVER, "Successfully mouse hover on the element: " + strButtonName,
							StatusReport.PASS);
				} catch (Exception e1) {
					moveToLocationAndClick(strButtonName, elementMouseHover, e1);
				}
			} else {
				report.updateTestLog(MOUSE_HOVER, "Mouse Hover to element: " + strButtonName + " not Done",
						StatusReport.FAIL);
				report.updateTestLog(MOUSE_HOVER, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog(MOUSE_HOVER, "Mouse Hover to element: " + strButtonName + " not Done", StatusReport.FAIL);
			report.updateTestLog(MOUSE_HOVER, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
		}
	}

	public void MouseHoverWithSS(By strMouseOverobj) {
		WebElement elementMouseHover = objdriver.getDriver().findElement(strMouseOverobj);
		Actions actionBuilder = new Actions(objdriver.getDriver());
		actionBuilder.moveToElement(elementMouseHover).perform();
		report.updateTestLog("Scroll", "Successfully scrolled", StatusReport.PASS);
	}

	public void MoveScrollbarToBottom() {
		try {
			((JavascriptExecutor) objdriver.getDriver()).executeScript("window.scrollTo(0,document.body.scrollHeight)");
		} catch (ElementNotVisibleException e) {
			LOGGER.error(e.getLocalizedMessage());
		}
	}

	public void MoveScrollbarToElement(By objHiddenElement) {
		objdriver.getDriver().findElement(objHiddenElement);
		((JavascriptExecutor) objdriver.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
				objdriver.getDriver().findElement(objHiddenElement));
		threadSleep(500);
		((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLLBY_0 + -50 + ");");
		threadSleep(500);
	}

	public void MoveScrollbarToTop() {
		try {
			((JavascriptExecutor) objdriver.getDriver()).executeScript("window.scrollTo(0,0)");
		} catch (ElementNotVisibleException e) {
			LOGGER.error(e.getLocalizedMessage());
		}
	}

	private void moveToLocationAndClick(String strButtonName, WebElement element, Exception e1) {
		if (e1.getMessage().contains(IS_NOT_CLICKABLE_AT_POINT)) {
			int y = element.getLocation().y - 200;
			((JavascriptExecutor) objdriver.getDriver()).executeScript(WINDOW_SCROLL + y + ")");
			try {
				threadSleep(1000);
				element.click();
				ajaxFluentPredicateWait();
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + CLICKED, StatusReport.PASS);
			} catch (Exception e2) {
				if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
					report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
					report.updateTestLog(CLICK_BUTTON, EXCEPTION + e2.getLocalizedMessage(), StatusReport.FAIL);
				}
			}
		} else {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog(CLICK_BUTTON, "'" + strButtonName + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e1.getLocalizedMessage(), StatusReport.FAIL);
			}
		}
	}

	public long noOfDaysInbetweenTwoDays(String dateString1, String dateString2, String format) throws ParseException {
		double daysBetween = 0;
		long difference = 0;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date date1 = sdf.parse(dateString1);
		Date date2 = sdf.parse(dateString2);
		difference = date1.getTime() - date2.getTime();
		daysBetween = (difference / (1000 * 60 * 60 * 24D));
		return Math.round(daysBetween);
	}

	public int NumberOfRows_CSS(By css) {
		ajaxFluentPredicateWait();
		threadSleep();
		int size = objdriver.getDriver().findElements(css).size();
		return size;
	}

	public int NumberOfRows_XPATH(By xpath) {
		ajaxFluentPredicateWait();
		int size = objdriver.getDriver().findElements(xpath).size();
		return size;
	}

	protected void openApp(final String context, final String appName) {
		if (context.equals(NATIVE_APP)) {
			final Map<String, Object> perfectoCommandnew = new HashMap<>();
			perfectoCommandnew.put("name", appName);
			objdriver.getAppiumDriver().executeScript("mobile:application:open", perfectoCommand);
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param context - Context of App like NATIVE_APP or WEB
	 * @param appName - Identifier of the App.
	 */
	protected void openAppWithIdentifier(final String context, final String identifer) {
		if (context.equals(NATIVE_APP)) {
			perfectoCommand.put("identifier", identifer);
			objdriver.getAppiumDriver().executeScript("mobile:application:open", perfectoCommand);
			perfectoCommand.clear();
		}
	}

	public void PageRefreshTillElementPresence(final By ObjID) {
		int i = 0;
		while (i++ <= 24) {
			objdriver.getDriver().navigate().refresh();
			objdriver.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			if (objdriver.getDriver().findElements(ObjID).size() > 0) {
				break;
			}
		}
	}

	/**
	 * Function Applicable to Pause the Script, Generic Application
	 *
	 * @param How_Long_To_Pause
	 */
	public void PauseScript(int How_Long_To_Pause) {
		How_Long_To_Pause = How_Long_To_Pause * 1000;
		threadSleep(How_Long_To_Pause);
	}

	public void peformCanvasSignature(By Objid) {
		WebElement element = objdriver.getDriver().findElement(Objid);
		Actions builder = new Actions(objdriver.getDriver());
		int i = 0;
		try {
			while (i < 20) {
				for (i = 0; i <= 20; i++) {
					org.openqa.selenium.interactions.Action drawAction = builder.moveToElement(element, 135, 15)
							.doubleClick().moveByOffset(135, 20).doubleClick().build();
					drawAction.perform();
				}
				threadSleep(1000);
				i++;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param repositoryFile
	 * @param handsetFile
	 */
	protected void putFileOnDevice(final String repositoryFile, final String handsetFile) {
		perfectoCommand.put(REPO_FILE, repositoryFile);
		perfectoCommand.put(HANDSET_FILE, handsetFile);
		objdriver.getAppiumDriver().executeScript("mobile:media:put", perfectoCommand);
		perfectoCommand.clear();
	}

	public boolean readOnly(By objId, String strdes) {
		WebElement element = objdriver.getDriver().findElement(objId);
		String h = element.getAttribute(CLASS);
		if (h.contains("ReviewDropdownReadonly")) {
			return false;
		} else {
			return true;
		}
	}

	public void refreshPage() {
		objdriver.getDriver().navigate().refresh();
	}

	public void rejectPopUp() {
		ajaxFluentPredicateWait();
		Alert Prompt = objdriver.getDriver().switchTo().alert();
		Prompt.dismiss();
		ajaxFluentPredicateWait();
	}

	public String replaceSlash(String text) {
		try {
			if (text.contains("/")) {
				String[] strSplit = text.split("\\/");
				String replacChar = "/";
				int val = strSplit[0].length();
				int val1 = strSplit[1].length();
				int valSplit = strSplit.length;
				if (valSplit == 3) {
					if (val == 1 && val1 == 1) {
						text = "0" + strSplit[0] + replacChar + "0" + strSplit[1] + replacChar + strSplit[2];
					} else if (val == 1) {
						text = "0" + text;
					} else if (val1 == 1) {
						text = strSplit[0] + replacChar + "0" + strSplit[1] + replacChar + strSplit[2];
					}
				}
			}
			return text;
		} catch (Exception e) {
			throw new UserdefinedException(e.getMessage());
		}
	}

	public String roundTwoDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.00");
		return twoDForm.format(d);
	}

	public boolean runningVBScript(BufferedReader bufReader) throws IOException {
		try {
			boolean autoItKilled = true;
			String line = null;
			while ((line = bufReader.readLine()) != null) {
				LOGGER.info("Process: " + line);
				if (line.contains("wscript")) {
					autoItKilled = false;
					break;
				}
			}
			return autoItKilled;
		} catch (Exception e) {
			throw new UserdefinedException(e.getMessage());
		}
	}

	public void RunVBScript(String command[]) {
		final String RUN_VBS = "Run VBS";
		Runtime runvBS = Runtime.getRuntime();
		long start = 0, end = 0;
		try {
			if (command.length > 0) {
				start = new Date().getTime();
				runvBS.exec(command);
				threadSleep(500);
				boolean autoItKilled = false;
				while (true) {
					Process p = Runtime.getRuntime().exec(System.getenv("windir") + "\\system32\\tasklist.exe");
					BufferedReader bufReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
					autoItKilled = runningVBScript(bufReader);
					if (autoItKilled) {
						bufReader.close();
						break;
					}
					bufReader.close();
					threadSleep(1000);
					end = new Date().getTime();
					if (Integer.parseInt(new SimpleDateFormat("mm").format(new Date(end - start))) > 2) {
						report.updateTestLog(RUN_VBS,
								"VBScript is being executed for more than 2 mins. Terminated abruptly.", StatusReport.PASS);
						return;
					}
				}
				report.updateTestLog(RUN_VBS, "VBScript is executed Successfully", StatusReport.PASS);
			} else {
				report.updateTestLog(RUN_VBS, "Empty command cannot be executed!!", StatusReport.FAIL);
			}
		} catch (SecurityException e) {
			LOGGER.error(e.getMessage());
			report.updateTestLog(RUN_VBS, "Not enough permission to execute vbscript. " + e.getMessage(), StatusReport.FAIL);
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
			report.updateTestLog(RUN_VBS, "IO Exception occurred during execution of vbscript. " + e.getMessage(),
					StatusReport.FAIL);
		} catch (NullPointerException e) {
			LOGGER.error(e.getMessage());
			report.updateTestLog(RUN_VBS,
					"Null Pointer Exception occurred during execution of vbscript. " + e.getMessage(), StatusReport.FAIL);
		}
	}

	@SuppressWarnings("rawtypes")
	public void scrollAndSearch(IOSDriver driver, String value, MobileElement me, Boolean direction) {
		String x = getLocationX(me);
		String y = getLocationY(me);
		while (!driver.findElementByXPath(getXpathFromElement(me)).getText().contains(value)) {
			swipe(driver, x, y, direction);
		}
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param objdriver.getDriver()
	 * @param list
	 */
	@SuppressWarnings("rawtypes")
	protected void scrollChecker(IOSDriver driver, String[] list) {
		for (int i = 0; i < list.length; i++) {
			MobileElement me = (MobileElement) driver.findElement(By.xpath("//UIAPickerWheel[" + (i + 1) + "]"));
			int mget = getMonthInt(me.getText().split(",")[0]);
			if (i == 0) {
				if (mget > getMonthInt(list[i])) {
					scrollAndSearch(driver, list[i], me, true);
				} else {
					scrollAndSearch(driver, list[i], me, false);
				}
			} else {
				if (Integer.parseInt(me.getText().split(",")[0]) > Integer.parseInt(list[i])) {
					scrollAndSearch(driver, list[i], me, true);
				} else {
					scrollAndSearch(driver, list[i], me, false);
				}
			}
		}
	}

	public void scrollInsideElement_Screenshot(By element, int numOfScrolls, String stepName, String description) {
		int viewHieght = Integer.parseInt(getClientHeight(element));
		String className = GetAttributeValue(element, CLASS);
		JavascriptExecutor js = (JavascriptExecutor) objdriver.getDriver();
		for (int i = 0; i < numOfScrolls; i++) {
			report.updateTestLog(stepName, description, StatusReport.PASS);
			ajaxFluentPredicateWait();
			js.executeScript("document.getElementsByClassName(\'" + className + "\')[0].scrollTop+=" + viewHieght);
		}
	}

	public void scrolltoElement(By strObj, String strButtonName) {
		WebElement element = objdriver.getDriver().findElement(strObj);
		try {
			((JavascriptExecutor) objdriver.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			report.updateTestLog("Move to element", "Not moved to " + strButtonName, StatusReport.FAIL);
		}
	}

	public void selectCheckBoxAllValue(By strTableObject, String text) {
		try {
			ajaxFluentPredicateWait();
			List<WebElement> CheckBoxs = objdriver.getDriver().findElements(strTableObject);
			int Loopcounter;
			int LoopcounterEnd = CheckBoxs.size();
			for (Loopcounter = 1; Loopcounter <= LoopcounterEnd; Loopcounter++) {
				ajaxFluentPredicateWait();
				CheckBoxs.get(Loopcounter - 1).click();
				ajaxFluentPredicateWait();
				if (Loopcounter != LoopcounterEnd) {
					CheckBoxs.clear();
					CheckBoxs = objdriver.getDriver().findElements(strTableObject);
				}
			}
			report.updateTestLog("Select Mulitple Check Box",
					"Selection of Multiple check box in the section - " + text + " - is successfull ", StatusReport.PASS);
		} catch (Exception e) {
			report.updateTestLog("Select Mulitple Check Box",
					"Selection of Multiple check box in the section - " + text + " - is NOT successfull ", StatusReport.FAIL);
		}
	}

	public void selectDropDownFirstValue(By objName) {
		Select select = new Select(objdriver.getDriver().findElement(objName));
		WebElement selectedvalue = select.getFirstSelectedOption();
		if (StringUtils.isEmpty(selectedvalue.getText())) {
			for (WebElement option : select.getOptions()) {
				if (StringUtils.isNotEmpty(option.getText())) {
					selectedvalue = option;
					option.click();
					break;
				}
			}
		}
		report.updateTestLog(DROP_DOWN, selectedvalue + " is selected", StatusReport.INFO);
	}

	public void selectDropDownFirstValue(By objName, String strValue) {
		Select select = new Select(objdriver.getDriver().findElement(objName));
		WebElement selectedvalue = select.getFirstSelectedOption();
		if (selectedvalue.getText().contains(strValue)) {
			report.updateTestLog(DROP_DOWN, strValue + " is selected", StatusReport.PASS);
		} else {
			report.updateTestLog(DROP_DOWN, strValue + " is not selected", StatusReport.FAIL);
		}
	}

	public void selectDropDownValue(By objName, String strValue, String strdesc) {
		List<WebElement> Options = new ArrayList<>();
		try {
			ajaxFluentPredicateWait();
			Select select = new Select(objdriver.getDriver().findElement(objName));
			Options = select.getOptions();
			for (WebElement option : Options) {
				if (option.getText().trim().equalsIgnoreCase(strValue)) {
					option.click();
					ajaxFluentPredicateWait();
					report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
					return;
				}
			}
			report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_NOT_AVAILABLE_IN + strdesc, StatusReport.FAIL);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_NOT_AVAILABLE_IN + strdesc, StatusReport.FAIL);
		}
	}

	public void selectDropDownValue_NoReport(By objName, String strValue, String strdesc) {
		List<WebElement> Options = new ArrayList<>();
		try {
			Select select = new Select(objdriver.getDriver().findElement(objName));
			Options = select.getOptions();
			for (WebElement option : Options) {
				if (option.getText().trim().equalsIgnoreCase(strValue)) {
					option.click();
					ajaxFluentPredicateWait();
					return;
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	public void selectDropDownValueContains(By objName, String strValue, String strdesc) {
		Select select = new Select(objdriver.getDriver().findElement(objName));
		List<WebElement> Options = select.getOptions();
		for (WebElement option : Options) {
			if (option.getText().toLowerCase().contains(strValue.toLowerCase())) {
				option.click();
				ajaxFluentPredicateWait();
				report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
				return;
			}
		}
		report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_NOT_AVAILABLE_IN + strdesc, StatusReport.FAIL);
	}

	public void selectDropDownValueContainsForPegaCPL(By objName, String strValue, String strdesc) {
		Select select = new Select(objdriver.getDriver().findElement(objName));
		List<WebElement> Options = select.getOptions();
		for (WebElement option : Options) {
			if (option.getAttribute(LABEL).contains(strValue)) {
				option.click();
				ajaxFluentPredicateWait();
				report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_SELECTED_IN + strdesc, StatusReport.PASS);
				return;
			}
		}
		ajaxFluentPredicateWait();
		report.updateTestLog(SELECT_DROP_DOWN_VALUE, strValue + IS_NOT_AVAILABLE_IN + strdesc, StatusReport.FAIL);
	}

	public void selectItemInGroupByValue(String ObjCheckBoxGroup, String strValue, String strdesc) {
		By objCheckBoxsname = By.xpath(ObjCheckBoxGroup + "/..");
		By objCheckBoxs = By.xpath(ObjCheckBoxGroup);
		List<WebElement> CheckBoxs = objdriver.getDriver().findElements(objCheckBoxs);
		List<WebElement> CheckBoxsNames = objdriver.getDriver().findElements(objCheckBoxsname);
		for (int i = 0; i < CheckBoxsNames.size(); i++) {
			if (CheckBoxsNames.get(i).getText().contains(strValue)) {
				CheckBoxs.get(i).click();
				ajaxFluentPredicateWait();
				break;
			}
		}
	}

	public boolean SelectRadioButtonById(Boolean doflag, By objId, String strValueToSelect) {
		Boolean flag = null;
		try {
			List<WebElement> elements = objdriver.getDriver().findElements(objId);
			for (WebElement ele : elements) {
				if (ele.isDisplayed()) {
					ele.click();
					break;
				}
			}
			flag = doflag;
			return flag;
		} catch (Exception e) {
			return false;
		}
	}

	public void SelectRadioButtonInGroup(By strobjWithXpath, String strdesc) {
		try {
			ajaxFluentPredicateWait();
			ClickElement(strobjWithXpath, strdesc);
			report.updateTestLog(RADIO_GROUP_SELECTION, SELECTED + strdesc, StatusReport.PASS);
		} catch (Exception e) {
			LOGGER.error(e.getLocalizedMessage());
			report.updateTestLog(RADIO_GROUP_SELECTION, "Error While Selecting: " + strdesc, StatusReport.FAIL);
		}
	}

	public void SelectRadioButtonInGroup(By strobjWithXpath, String strValue, String strdesc) {
		try {
			threadSleep(1000);
			if (strobjWithXpath.toString().contains(REPLACEME_2)) {
				String strExpXpath = strobjWithXpath.toString().replace(BY_XPATH, "").replace(REPLACEME_2,
						"\"" + strValue + "\"");
				By ObjExpXPath = By.xpath(strExpXpath);
				ClickElement(ObjExpXPath, strdesc);
				report.updateTestLog(RADIO_GROUP_SELECTION, SELECTED + strdesc, StatusReport.PASS);
			} else {
				String strExpXpath = strobjWithXpath.toString().replace(BY_XPATH, "").replace(REPLACE_ME1,
						"\"" + strValue + "\"");
				By ObjExpXPath = By.xpath(strExpXpath);
				ClickElement(ObjExpXPath, strdesc);
				report.updateTestLog(RADIO_GROUP_SELECTION, SELECTED + strdesc, StatusReport.PASS);
			}
		} catch (Exception e) {
			LOGGER.error(e.getLocalizedMessage());
			report.updateTestLog(RADIO_GROUP_SELECTION, "Error While Selecting: " + strdesc, StatusReport.FAIL);
		}
	}

	public boolean SelectRadioButtonYN(By objIdYes, By objIdNo, String strValueToSelect) {
		try {
			if (strValueToSelect.equalsIgnoreCase("Yes")) {
				WebElement element = objdriver.getDriver().findElement(objIdYes);
				element.click();
			} else if (strValueToSelect.equalsIgnoreCase("No")) {
				WebElement element = objdriver.getDriver().findElement(objIdNo);
				element.click();
			}
			return true;
		} catch (NullPointerException n) {
			throw new UserdefinedException("WebElement is empty");
		} catch (WebDriverException e) {
			if (e.getMessage().contains("not clickable at point")) {
				try {
					checkingSelectRadioButton(objIdYes, objIdNo, strValueToSelect);
					return true;
				} catch (Exception e1) {
					return false;
				}
			} else {
				report.updateTestLog(CLICK_BUTTON, "'" + strValueToSelect + NOT_CLICKED, StatusReport.FAIL);
				report.updateTestLog(CLICK_BUTTON, EXCEPTION + e.getLocalizedMessage(), StatusReport.FAIL);
				return false;
			}
		}
	}

	public boolean SelectValueByIdIndex(By objId, Integer intIndexNum) {
		try {
			Select cmbObject = new Select(objdriver.getDriver().findElement(objId));
			cmbObject.selectByIndex(intIndexNum);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public int SelectValueCount(By objName) {
		try {
			WebElement select = objdriver.getDriver().findElement(objName);
			List<WebElement> options = select.findElements(By.tagName("option"));
			return options.size();
		} catch (NoSuchElementException e) {
			return 0;
		}
	}

	public void SendEnter(By ObjID) {
		ajaxFluentPredicateWait();
		try {
			objdriver.getDriver().findElement(ObjID).sendKeys(Keys.ENTER);
			ajaxFluentPredicateWait();
		} catch (StaleElementReferenceException e) {
			report.updateTestLog("SendEnter", "Exception found in SendEnter", StatusReport.FAIL);
		}
	}

	public void sendKeys(By xpath, String text) {
		objdriver.getDriver().findElement(xpath).sendKeys(text);
	}

	public void SendTAB(By ObjID) {
		ajaxFluentPredicateWait();
		try {
			objdriver.getDriver().findElement(ObjID).sendKeys(Keys.TAB);
			ajaxFluentPredicateWait();
		} catch (StaleElementReferenceException e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLog(SEND_TAB, "Exception found in SendTab", StatusReport.FAIL);
		}
	}

	public void SendTAB_old(By ObjID) {
		try {
			if (!objdriver.getDriver().findElement(By.id("BusyBoxDiv")).isDisplayed()) {
				objdriver.getDriver().findElement(ObjID).sendKeys(Keys.TAB);
				ajaxFluentPredicateWait();
			} else {
				long startTime = (System.currentTimeMillis()) / 1000;
				long stopTime = (System.currentTimeMillis()) / 1000;
				boolean broke = false;
				while ((stopTime - startTime) < 360) {
					if (!objdriver.getDriver().findElement(By.id("BusyBoxDiv")).isDisplayed()) {
						broke = true;
						ajaxFluentPredicateWait();
						break;
					}
					stopTime = (System.currentTimeMillis()) / 1000;
				}
				if (!broke) {
					objdriver.getDriver().navigate().refresh();
				}
			}
		} catch (StaleElementReferenceException e) {
			report.updateTestLog(SEND_TAB, "Exception found in SendTab", StatusReport.FAIL);
		}
		ajaxFluentPredicateWait();
	}

	public Date setDate(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.getTime();
	}

	public Date setRelativeDatefromGivenDate(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}

	public Date setRelativeDatefromToday(int numberOfDays) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, numberOfDays);
		return cal.getTime();
	}

	public Date setRelativeDatefromToday(String strInterval, int total) {
		Calendar cal = Calendar.getInstance();
		switch (strInterval.toUpperCase()) {
		case "D":
		case "DD":
		case "DAYS":
			cal.add(Calendar.DATE, total);
			break;
		case "M":
		case "MM":
		case "MON":
		case "MONTH":
			cal.add(Calendar.MONTH, total);
			break;
		case "YYYY":
		case "YEARS":
			cal.add(Calendar.YEAR, total);
			break;
		default:
			cal.add(Calendar.DATE, total);
			break;
		}
		return cal.getTime();
	}

	public void SetTextValuebyXpath(By ObjID, String ValuetoSet) {
		objdriver.getDriver().findElement(ObjID).clear();
		objdriver.getDriver().findElement(ObjID).sendKeys(ValuetoSet);
		ajaxFluentPredicateWait();
	}

	public void SetTextValuebyXpath(String ObjID, String ValuetoSet) {
		objdriver.getDriver().findElement(By.xpath("//input[@id=" + "'" + ObjID + "'" + "]")).sendKeys(ValuetoSet);
		ajaxFluentPredicateWait();
	}

	public int showRandomInteger(int aStart, int aEnd, Random aRandom) {
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		long range = aEnd - aStart + 1L;
		long fraction = (long) (range * aRandom.nextDouble());
		int randomNumber = (int) (fraction + aStart);
		return randomNumber;
	}

	public long showRandomIntegerLong(int aStart, long aEnd, Random aRandom) {
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		long range = aEnd - aStart + 1L;
		long fraction = (long) (range * aRandom.nextDouble());
		int randomNumber = (int) (fraction + aStart);
		return randomNumber;
	}

	public void SleepWait_milliseconds(int millisecs) {
		threadSleep(millisecs);
	}

	public boolean StaleClickFunction(By objIdYes, By objIdNo, String SelVal) {
		try {
			boolean check = checkingStaleClick(objIdYes, objIdNo, SelVal);
			return check;
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING"))
			report.updateTestLog("Stale Click Radio button", "Radio button is not selected as " + SelVal, StatusReport.FAIL);
			return false;
		}
	}

	public boolean StaleClickRadioFunction(By strobj, String objDesc) {
		boolean b = false;
		try {
			b = checkingStaleClickRadio(strobj, objDesc);
		} catch (Exception e) {
			b = false;
		}
		return b;
	}

	public boolean staleEnteringText(By strobj, String SelVal, String strdesc) {
		int count = 0;
		while (count < 200) {
			try {
				WebElement element = objdriver.getDriver().findElement(strobj);
				SelVal = SelVal.trim();
				element.clear();
				element.sendKeys(SelVal);
				ajaxFluentPredicateWait();
				ajaxFluentPredicateWait();
				count = count + 201;
			} catch (StaleElementReferenceException e) {
				count = count + 1;
				ajaxFluentPredicateWait();
			}
		}
		report.updateTestLog(ENTER_TEXT, SelVal + IS_ENTERED_IN + strdesc, StatusReport.PASS);
		return true;
	}

	public boolean StaleEnterTextFunction(By strobj, String SelVal, String strdesc) {
		try {
			boolean checkStale = staleEnteringText(strobj, SelVal, strdesc);
			return checkStale;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return false;
		}
	}

	public boolean StaleFunction(By strobj) {
		boolean b = false;
		try {
			b = checkingStaleFunction(strobj);
		} catch (Exception e) {
			b = false;
		}
		return b;
	}

	public boolean StaleSelectFunction(By strobj, String SelVal) {
		try {
			boolean checkStaleSelect = checkingStateSelectFunction(strobj, SelVal);
			return checkStaleSelect;
		} catch (Exception e) {
			if (!configProps.getProperty("ProjectName").equalsIgnoreCase("SYNTHETICMONITORING")) {
				report.updateTestLog("Stale Select Function", strobj + " Lsitbox is not selected as " + SelVal,
						StatusReport.FAIL);
			} else {
				report.updateTestLog("Stale Select Function", strobj + " Lsitbox is not selected as " + SelVal,
						StatusReport.INFO);
			}
			return false;
		}
	}

	public boolean StaleTabOutFunction(By ObjID) {
		try {
			boolean check = checkTab(ObjID);
			return check;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return false;
		}
	}

	// Performs the swipe and search operation
	// Code here shouldn't be modified
	@SuppressWarnings("rawtypes")
	private void swipe(IOSDriver driver, String start, String end, Boolean up) {
		String direction;
		if (up) {
			direction = start + "," + (Integer.parseInt(end) + 70);
		} else {
			direction = start + "," + (Integer.parseInt(end) - 70);
		}
		Map<String, Object> params1 = new HashMap<>();
		params1.put(LOCATION, start + "," + end);
		params1.put("operation", "down");
		driver.executeScript("mobile:touch:tap", params1);
		Map<String, Object> params2 = new HashMap<>();
		List<String> coordinates2 = new ArrayList<>();
		coordinates2.add(direction);
		params2.put(LOCATION, coordinates2);
		params2.put("auxiliary", "notap");
		params2.put("duration", "3");
		driver.executeScript(MOBILE_TOUCH, params2);
		Map<String, Object> params3 = new HashMap<>();
		params3.put(LOCATION, direction);
		params3.put("operation", "up");
		driver.executeScript("mobile:touch:tap", params3);
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 */
	protected void swipe(final String x1, final String y1, final String x2, final String y2) {
		final List<String> swipeCoordinates = new ArrayList<>();
		swipeCoordinates.add(x1 + ',' + y1);
		swipeCoordinates.add(x2 + ',' + y2);
		perfectoCommand.put(LOCATION, swipeCoordinates);
		objdriver.getAppiumDriver().executeScript(MOBILE_TOUCH, perfectoCommand);
		perfectoCommand.clear();
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param textToFind
	 */
	protected void swipeTillText(String textToFind) {
		perfectoCommand.put(CONTENT, textToFind);
		perfectoCommand.put("scrolling", "scroll");
		perfectoCommand.put("maxscroll", "10");
		perfectoCommand.put("next", "SWIPE_UP");
		((JavascriptExecutor) objdriver.getDriver()).executeScript("mobile:text:select", perfectoCommand);
		perfectoCommand.clear();
	}

	public void switchTabs(int tabIndex) {
		ArrayList<String> tabs = new ArrayList<>(objdriver.getDriver().getWindowHandles());
		if (!tabs.isEmpty()) {
			objdriver.getDriver().switchTo().window(tabs.get(tabIndex));
		} else {
			report.updateTestLog("Switch Tab", "Tabs are not present", StatusReport.FAIL);
		}
	}

	public boolean switchToNewWindow() {

		/**
		 * @Description: This function will switch to a new window
		 */
		String parentWindowHandle = objdriver.getDriver().getWindowHandle();
		threadSleep(2000);
		Set<String> newWindowHandle = objdriver.getDriver().getWindowHandles();
		String newWindow = null;

		for (String window : newWindowHandle) {

			if (!parentWindowHandle.equals(window)) {
				newWindow = window;
				break;
			}
		}
		if (!parentWindowHandle.equals(newWindow)) {
			objdriver.getDriver().switchTo().window(newWindow);
			return true;

		}
		return false;

	}

	public void switchToWindow(String window) {
		objdriver.getDriver().switchTo().window(window);
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param textToFind - text that has to be searched
	 * @param timeout
	 */
	protected Boolean textCheckpoint(final String textToFind, final Integer timeout) {
		perfectoCommand.put(CONTENT, textToFind);
		perfectoCommand.put(TIMEOUT, timeout);
		final Object result = objdriver.getAppiumDriver().executeScript("mobile:checkpoint:text", perfectoCommand);
		final boolean resultBool = Boolean.parseBoolean(result.toString());
		perfectoCommand.clear();
		return resultBool;
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param textToFind - text that has to be searched
	 * @param timeout
	 */
	protected void textClick(final String textToFind, final Integer timeout) {
		perfectoCommand.put(CONTENT, textToFind);
		perfectoCommand.put(TIMEOUT, timeout);
		objdriver.getAppiumDriver().executeScript("mobile:text:select", perfectoCommand);
		perfectoCommand.clear();
	}

	private void urlLinkStatus(String[] responseArray) {
		try {
			String linkValue = responseArray[0];
			String responseValue = responseArray[1];
			responseCode = Integer.valueOf(responseValue);
			String responseStatus = responseArray[2];
			switch (responseCode) {
			case 2:
				report.updateTestLog(linkValue, RESPONSE_CODE + responseStatus + " - OK", StatusReport.PASS);
				break;
			case 3:
				report.updateTestLog(linkValue, "Unknown Responce Code", StatusReport.FAIL);
				break;
			case 4:
				report.updateTestLog(linkValue, RESPONSE_CODE + responseStatus + " - Client error", StatusReport.FAIL);
				break;
			case 5:
				report.updateTestLog(linkValue, RESPONSE_CODE + responseStatus + " - Internal Server Error",
						StatusReport.FAIL);
				break;
			default:
				report.updateTestLog(linkValue, "Unknown Responce Code", StatusReport.FAIL);
				break;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		} finally {
			httpURLConnect.disconnect();
		}
	}

	public boolean validateDate(String getDate, String format) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		simpleDateFormat.setLenient(false);
		try {
			simpleDateFormat.parse(getDate);
			return true;
		} catch (ParseException parseException) {
			return false;
		}
	}

	public void ValidateError(String ActualError, String ExpectedError, String objdesc) {
		if (ActualError.equals(ExpectedError)) {
			report.updateTestLog("Error Validation",
					"Error message for field " + objdesc + " is displayed as expected " + ExpectedError, StatusReport.PASS);
		} else {
			report.updateTestLog("Error Validation", "Error message for field " + objdesc
					+ " is not displayed as expected " + ExpectedError + " Actual Error - " + ActualError, StatusReport.FAIL);
		}
	}

	private String[] validationOfLinks(String urlToValidate) {
		String[] responseArray = new String[3];
		int responseStatus = 0;
		try {
			URL url = new URL(urlToValidate);
			httpURLConnect = (HttpURLConnection) url.openConnection();
			httpURLConnect.setConnectTimeout(3000);
			httpURLConnect.connect();
			responseStatus = httpURLConnect.getResponseCode();
			responseCode = responseStatus / 100;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		responseArray[0] = urlToValidate;
		responseArray[1] = String.valueOf(responseCode);
		responseArray[2] = String.valueOf(responseStatus);
		return responseArray;
	}

	public boolean VerifyBackgroundColor(By element, String color) {
		boolean comparecolor = false;
		String strColorinUI, strColorCodetoVerify;
		strColorCodetoVerify = GetrgbaColorCode(color);
		if (strColorCodetoVerify.equalsIgnoreCase("")) {
			report.updateTestLog("Color Verification", "Invalid Color Name: " + strColorCodetoVerify, StatusReport.FAIL);
			return false;
		}
		if (IsObjectPresent(element, "Object Availability:Color Verification")) {
			strColorinUI = objdriver.getDriver().findElement(element).getCssValue("background-color").toString();
			if (strColorinUI.equalsIgnoreCase(strColorCodetoVerify))
				comparecolor = true;
			else
				comparecolor = false;
		} else {
			return false;
		}
		return comparecolor;
	}

	public boolean VerifyFontColor(By element, String color) {
		boolean comparecolor = false;
		String strColorinUI, strColorCodetoVerify = "";
		strColorCodetoVerify = GetrgbaColorCode(color);
		if (strColorCodetoVerify.equalsIgnoreCase("")) {
			report.updateTestLog("Color Verification", "Invalid Color Name: " + strColorCodetoVerify, StatusReport.FAIL);
			return false;
		}
		if (IsObjectPresent(element, "Object Availability:Color Verification")) {
			strColorinUI = objdriver.getDriver().findElement(element).getCssValue("color").toString();
			if (strColorinUI.equalsIgnoreCase(strColorCodetoVerify))
				comparecolor = true;
			else
				comparecolor = false;
		} else {
			return false;
		}
		return comparecolor;
	}

	public boolean VerifyXMLDocNodeValue(Document doc, String strNodeName, String strExpectedValue) {
		boolean blnVerified = false;
		NodeList nodeList = doc.getElementsByTagName(strNodeName);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node nNode = nodeList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				String strElementContent = eElement.getTextContent();
				if (strElementContent.equalsIgnoreCase(strExpectedValue)) {
					blnVerified = true;
				} else {
					blnVerified = false;
				}
			}
		}
		return blnVerified;
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param label     - text that has to be searched
	 * @param timeout
	 * @param threshold
	 */
	protected void visualClick(final String label, final Integer timeout, final Integer threshold) {
		perfectoCommand.put(LABEL, label);
		perfectoCommand.put(THRESHOLD, threshold);
		perfectoCommand.put(TIMEOUT, timeout);
		objdriver.getAppiumDriver().executeScript(MOBILE_CLICK, perfectoCommand);
		perfectoCommand.clear();
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param label          - text that has to be searched
	 * @param timeout
	 * @param threshold
	 * @param labelDirection
	 * @param labelOffset
	 */
	protected void visualClick(final String label, final Integer timeout, final Integer threshold,
			final String labelDirection, final String labelOffset) {
		perfectoCommand.put(LABEL, label);
		perfectoCommand.put(THRESHOLD, threshold);
		perfectoCommand.put(TIMEOUT, timeout);
		perfectoCommand.put("label.direction", labelDirection);
		perfectoCommand.put("label.offset", labelOffset);
		objdriver.getAppiumDriver().executeScript(MOBILE_CLICK, perfectoCommand);
		perfectoCommand.clear();
	}

	/**
	 * Function Applicable only when the ExecutionMode used is <b>PERFECTO
	 *
	 * @param label     - text that has to be searched
	 * @param threshold
	 */
	protected void visualScrollToClick(final String label, final Integer threshold) {
		perfectoCommand.put(LABEL, label);
		perfectoCommand.put(THRESHOLD, threshold);
		perfectoCommand.put("scrolling", "scroll");
		objdriver.getAppiumDriver().executeScript(MOBILE_CLICK, perfectoCommand);
		perfectoCommand.clear();
	}

	@SuppressWarnings({ "deprecation" })
	public void waitForCondition(String script, String timeOutInMilliseconds, int askEvery) {
		WebDriverWait wait = new WebDriverWait(objdriver.getDriver(), Integer.valueOf(timeOutInMilliseconds) / 1000);
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		wait.until(pageLoadCondition);
		class JScriptReturnsTrue implements ExpectedCondition<Boolean> {
			String script;

			public JScriptReturnsTrue(String script) {
				this.script = script;
			}

			@Override
			public Boolean apply(WebDriver d) {
				return Boolean.valueOf(getEval(script));
			}
		}
		wait.pollingEvery(askEvery, TimeUnit.MILLISECONDS).ignoring(WebDriverException.class)
				.until(new JScriptReturnsTrue(script));
	}

	@SuppressWarnings("deprecation")
	public WebElement WaitForElement(final By ObjId) {
		new FluentWait<>(objdriver.getDriver()).withTimeout(60, TimeUnit.SECONDS)
				.pollingEvery(100, TimeUnit.MILLISECONDS).until(new Function<WebDriver, Boolean>() {
					// @Override
					@Override
					public Boolean apply(WebDriver Webdriver) {
						try {
							Boolean booFlag = objdriver.getDriver().findElement(ObjId).isDisplayed();
							if (booFlag)
								return true;
							else
								return false;
						} catch (Exception e) {
							return false;
						}
					}
				});
		return objdriver.getDriver().findElement(ObjId);
	}

	protected String yesterday(String format) {
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String formattedDate = formatter.format(cal.getTime());
		return formattedDate;
	}

	public boolean zipResolverId(Boolean zipcodeflag, Boolean zipformatflag, String testdata, By objId,
			String strdesc) {
		final String ZIPCODE_RESOLVER = "Zipcode Resolver";
		try {
			String strgetCity = GetTextValue(objId, strdesc);
			if (strgetCity.equalsIgnoreCase(testdata)) {
				report.updateTestLog(ZIPCODE_RESOLVER, "US Zip code is entered and City is Prefilled", StatusReport.PASS);
			} else if (!strgetCity.equals("") && zipcodeflag == true) {
				report.updateTestLog(ZIPCODE_RESOLVER, "Non US Zip code is entered and City is Not Prefilled",
						StatusReport.PASS);
				EnterText(objId, testdata, strdesc);
				SendTAB(objId);
			} else if (!strgetCity.equals("") && zipformatflag == true) {
				report.updateTestLog(ZIPCODE_RESOLVER, "US Zip code is entered and City is Not Prefilled", StatusReport.FAIL);
			} else if (!strgetCity.equals("") && !zipcodeflag) {
				report.updateTestLog(ZIPCODE_RESOLVER,
						"Non US Zip code is entered and Error Message Fails:Zip code entered cannot be found ",
						StatusReport.FAIL);
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void saveDocByCoordinates(String windowHandle, String docName, String formate, int x, int y) {
		/**
		 * Designed By: HCL : Save document using Co-ordinates
		 * 
		 */
		try {
			threadSleep();
			switchToNewWindow();
			objdriver.getDriver().manage().window().maximize();

			Robot robot;
			robot = new Robot();
			robot.mouseMove(x, y);
			robot.delay(2000);
			robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
			if (saveDoc(docName, formate)) {
				report.updateTestLog("PDF file", docName + " pdf is present", StatusReport.PASS);
			} else {
				report.updateTestLog("PDF file", docName + " pdf is not present", StatusReport.INFO);
			}
			objdriver.getDriver().close();
			objdriver.getDriver().switchTo().window(windowHandle);
		} catch (Exception e) {
			LOGGER.debug("pdf is not present");
		}
	}
	public void saveDocByRightClickSaveAs(String windowHandle, String docName,

			String format) { 

		try {

			Thread.sleep(5000);

			// switchToNewWindow();

			// driver.getWebDriver().manage().window().maximize();

			Robot robot;

			robot = new Robot();

			robot.mouseMove(800, 500);

			robot.delay(3000);

			robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);

			robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);

			robot.delay(3000);

			robot.mouseMove(830, 515);

			robot.delay(1000);

			robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);

			robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

			if (SaveDocumentByName(docName, format))

				report.updateTestLog(docName, docName + " pdf is present", StatusReport.PASS);

			else

				report.updateTestLog(docName, docName + " pdf is not present", StatusReport.INFO);

			// driver.getWebDriver().close();

			// switchToWindow(windowHandle);

		} catch (Exception e) {

			report.updateTestLog(docName, docName + " pdf is not present", StatusReport.FAIL);

			e.printStackTrace();

		}

	}
	public static boolean saveDoc(String fileName, String formate) throws IOException {
		boolean status = false;

		URL url = new URL(objdriver.getDriver().getCurrentUrl());
		try (InputStream in = url.openStream();
				FileOutputStream fos = new FileOutputStream(file + "\\" + fileName + formate)) {

			LOGGER.debug("reading from resource and writing to file...");
			int length = -1;
			byte[] buffer = new byte[1024];// buffer for portion of data from
			// connection
			while ((length = in.read(buffer)) > -1) {
				fos.write(buffer, 0, length);
				status = true;
			}
		} catch (Exception e) {
			LOGGER.debug("Unable to write a file...");
		} finally {
			LOGGER.debug("File downloaded, Closing a connection");
		}
		return status;
	}
	public boolean SaveDocumentByName(String fileName, String fileExtension) {
        try {
            // ajaxFluentPredicateWait();
            
            String savepath = file + File.separator + SAVED_FILES + File.separator;
            System.out.println(savepath);
            File foldercheck = new File(savepath);
            if (!foldercheck.exists()) {
                foldercheck.mkdir();
            }
            String strFileName = fileName;
            savepath = savepath + strFileName;
            if (fileExtension.startsWith("."))
                savepath = savepath + fileExtension;
            else
                savepath = savepath + "." + fileExtension;
            String fileSavePath = "\"" + savepath + "\"";
            String autoITsaveExecutable =System.getProperty("user.dir") +File.separator+"src\test\resources"

					+ File.separator + "Tools"

					+ File.separator + "Save-As-File_V2.exe" + File.separator ;
            System.out.println(autoITsaveExecutable + fileSavePath);
            Runtime.getRuntime().exec(autoITsaveExecutable + " " + fileSavePath, null);
            try {
                Thread.sleep(12000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            checkProcessKilledByName("Save-As-File_V2");
            return IsFileExist(strFileName, fileExtension);
        } catch (Exception e) {
            report.updateTestLog("File Save", "File did not saved", StatusReport.INFO);
            return false;
        }
    }
	
	public void checkProcessKilledByName(String processName) throws Exception {
		String line;
		boolean autoItKilled = false;
		while (true) {
			Process p = Runtime.getRuntime().exec(System.getenv("windir") + "\\system32\\tasklist.exe");
			BufferedReader bufReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			ajaxFluentPredicateWait();
			while ((line = bufReader.readLine()) != null) {
				if (line.contains(processName)) {
					autoItKilled = false;
					break;
				} else {
					autoItKilled = true;
				}
			}
			if (autoItKilled) {
				bufReader.close();
				break;
			}
			bufReader.close();
			threadSleep();
		}
	}
	
	public boolean IsFileExist(String fileName, String fileExtension) {

		ajaxFluentPredicateWait();
		String pathToScan = file + File.separator + SAVED_FILES + File.separator;
		String fileThatYouWantToFilter;
		threadSleep();
		File folderToScan = new File(pathToScan);
		File[] listOfFiles = folderToScan.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				fileThatYouWantToFilter = listOfFiles[i].getName();
				if (fileThatYouWantToFilter.startsWith(fileName) && fileThatYouWantToFilter.endsWith(fileExtension)) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	public boolean SaveDocument_OpenedinNewWindow(String fileName, String strFileExtension) {

		/**
		 * 
		 * @author Pradheep Raaj Description: saves document opened in new Window with
		 * 
		 *         the specified File name and extension. It saves document by creating
		 * 
		 *         separate folder for a particular testcase
		 * 
		 */

		String mainWinId = objdriver.getDriver().getWindowHandle();

		Set<String> availableWindows = objdriver.getDriver().getWindowHandles(); // Gets

		String newWindow = null;

		for (String window : availableWindows)

			if (!mainWinId.equals(window)) {

				newWindow = window;

			}

		if (!mainWinId.equals(newWindow)) {

			try {

				Thread.sleep(2500);

			} catch (InterruptedException e) {

				e.printStackTrace();

			}

			objdriver.getDriver().switchTo().window(newWindow);

			objdriver.getDriver().manage().window().maximize();

			// ((TakesScreenshot)

			// objdriver.getDriver().getWebobjdriver.getDriver()()).getScreenshotAs(OutputType.FILE);

			String savepath = file + File.separator + SAVED_FILES + File.separator;

			File foldercheck = new File(savepath);

			if (!foldercheck.exists()) {

				foldercheck.mkdir();

			}
			 savepath = file + File.separator + SAVED_FILES + File.separator +objdriver.getTestCaseName() +File.separator;

			

			File foldercheck2 = new File(savepath);

			if (!foldercheck2.exists()) {

				foldercheck2.mkdir();

			}

			String strFileName = fileName;

			savepath = savepath + strFileName;

			if (strFileExtension.startsWith("."))

				savepath = savepath + strFileExtension;

			else

				savepath = savepath + "." + strFileExtension;

			// report.updateTestLog("Switch Window", "Switched to new Window",

			// Status.PASS);

			try {

				Robot robot = new Robot();

				robot.delay(3000);

				robot.keyPress(KeyEvent.VK_ESCAPE);

				robot.keyRelease(KeyEvent.VK_ESCAPE);

				robot.keyPress(KeyEvent.VK_CONTROL);

				if (objdriver.getTestCaseName().equalsIgnoreCase("BFO")

						|| System.getProperty("Browser").toString().equalsIgnoreCase("INTERNET_EXPLORER")) {

					robot.keyPress(KeyEvent.VK_SHIFT);

				}

				robot.keyPress(KeyEvent.VK_S);

				robot.keyRelease(KeyEvent.VK_S);

				if (objdriver.getTestCaseName().equalsIgnoreCase("BFO")

						|| System.getProperty("Browser").toString().equalsIgnoreCase("INTERNET_EXPLORER")) {

					robot.keyRelease(KeyEvent.VK_SHIFT);

				}

				robot.keyRelease(KeyEvent.VK_CONTROL);

				robot.delay(3000);

				String filesavepath = "\"" + savepath + "\"";

				String autoExecutablePath = file

						+ File.separator + "supportlibraries"

						+ File.separator + "Tools"

						+ File.separator + "Save-As-File_V2.exe" + "\"";

				System.out.println(autoExecutablePath + filesavepath);

				Thread.sleep(1000);

				autoExecutablePath = autoExecutablePath + " " + filesavepath;

				Runtime.getRuntime().exec(autoExecutablePath);

				Thread.sleep(10000);

				checkProcessKilledByName("Save-As-File_V2");

			} catch (Exception e) {

				report.updateTestLog("File Save", "File did not saved", StatusReport.FAIL);

			}

			objdriver.getDriver().close();

			objdriver.getDriver().switchTo().window(mainWinId);

			return IsFileExist(strFileName, strFileExtension);

		} else {

			report.updateTestLog("New Window Open", "New Window did not open for saving a file", StatusReport.FAIL);

			return false;

		}

	}
	
	
	public boolean SaveDocument(String fileExtension) {

		try {
			ajaxFluentPredicateWait();

			String savepath = file + File.separator + SAVED_FILES + File.separator;

			File foldercheck = new File(savepath);
			if (!foldercheck.exists()) {
				foldercheck.mkdir();
			}
			String strFileName = objdriver.getTestCaseName() + "_" + getTimeStamp();
			savepath = savepath + strFileName;
			if (fileExtension.startsWith("."))
				savepath = savepath + fileExtension;
			else
				savepath = savepath + "." + fileExtension;
			String pdfsavepath = "\"" + savepath + "\"";
			String autoITsavePDF = Utility.fnReadPropFile(SUPPORTR_LIBRARIES) + File.separator + "Save-As-File.exe"
					+ File.separator;
			ajaxFluentPredicateWait();
			Runtime.getRuntime().exec(autoITsavePDF + " " + pdfsavepath, null);
			threadSleep();
			ajaxFluentPredicateWait();
			checkProcessKilledByName("Save-As-File");

			threadSleep();
			return IsFileExist(strFileName, fileExtension);
		} catch (Exception e) {
			report.updateTestLog("File Save", "File did not saved", StatusReport.FAIL);
			return false;
		}
	}
	public void ScrollDownByActionElement(By element) {
		Actions action = new Actions(objdriver.getDriver());
		action.moveToElement(objdriver.getDriver().findElement(element)).build().perform();
		threadSleep(1000);
	}
}
