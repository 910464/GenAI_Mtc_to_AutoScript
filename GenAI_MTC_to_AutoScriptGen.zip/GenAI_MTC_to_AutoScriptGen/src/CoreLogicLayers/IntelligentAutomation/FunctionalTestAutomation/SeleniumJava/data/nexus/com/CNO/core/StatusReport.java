package com.cnoinc.qa.support;

public enum StatusReport {
	PASS, FAIL, FATAL, ERROR, WARNING, INFO, SKIP, SCREENSHOT, DONE, UNKNOWN;

	@Override
	public String toString() {
		switch (this) {
		case PASS:
			return "PASS";
		case FAIL:
			return "FAIL";
		case FATAL:
			return "FATAL";
		case ERROR:
			return "ERROR";
		case WARNING:
			return "WARNING";
		case INFO:
			return "INFO";
		case DONE:
			return "INFO";
		case SKIP:
			return "SKIP";
		case SCREENSHOT:
			return "SCREENSHOT";
		default:
			return "unknown";
		}
	}
}
