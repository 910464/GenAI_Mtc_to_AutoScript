/**
 * Package containing reusable libraries which are specific on Selenium
 *
 * @author HCL
 */
package com.cnoinc.qa.accelerators;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.opera.OperaOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import com.cnoinc.qa.support.ExtentManager;
import com.cnoinc.qa.support.ReportEvent;
import com.cnoinc.qa.utilities.ConfiguratorSupport;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Primary engine to manage the Selenium WebDriver and its common functions.
 */
public class TestEngine {
	private static final Logger LOGGER = LogManager.getLogger(TestEngine.class.getName());
	protected static ConfiguratorSupport configProps = new ConfiguratorSupport("config.properties");
	protected static final String TEST_ENV = "test.env";
	private static final String PROXY = "proxy";
	private static final String LOCAL_DRIVER = "LOCAL";
	private static final String GRID_DRIVER = "GRID";
	private static final String GLOBAL_DRIVER = "GLOBAL";
	private static final String GRID_TYPE_MESSAGE = "Please set grid.type as Local or grid..";
	protected static String stdTimeStamp = ExtentManager.dynamicTimeStamp();
	protected static DriverFactory objdriver = new DriverFactory();
	protected static int errorcount;
	protected static int warningcount;
	protected static String ScreenDoc = "";
	public static ReportEvent report = new ReportEvent();
	protected static final String passScreenshotCapture = configProps.getProperty("takescreenshot_Pass");
	protected static final String failScreenshotCapture = configProps.getProperty("takescreenshot_Fail");
	protected static final String ScreenshotCapture = configProps.getProperty("takescreenshot_Screenshot");
	protected static final String projectIDName =configProps.getProperty("ProjectName");

	private DesiredCapabilities cap;
	protected RemoteWebDriver RwebDriver;
	protected ChromeOptions cOptions = new ChromeOptions();
	protected FirefoxOptions ffOptions = new FirefoxOptions();
	protected InternetExplorerOptions ieOptions = new InternetExplorerOptions();
	protected EdgeOptions edgeOptions = new EdgeOptions();
	protected OperaOptions operaOptions = new OperaOptions();
	protected SafariOptions safariOptions = new SafariOptions();
	protected static File file = ExtentManager.dynamictestResultFolder(stdTimeStamp);
	protected static String fileSavepath = "";

	protected TestEngine() {
	}

	/**
	 * Delete all the cookies for the current domain.
	 *
	 * @param driver Selenium WebDriver managing the browser from which to delete
	 *               the cookies.
	 */
	public static void deleteCookie(WebDriver driver) {
		driver.manage().deleteAllCookies();
	}

	/**
	 * Get a string representing the current URL that the browser is looking at.
	 *
	 * @param driver Selenium WebDriver managing the browser whose URL should be
	 *               retrieved.
	 *
	 * @return a string containing the current URL.
	 */
	public static String getAppUrl(WebDriver driver) {
		return driver.getCurrentUrl();
	}

	/**
	 * Get the source of the last loaded page.
	 *
	 * @param driver Selenium WebDriver managing the browser from which to retrieve
	 *               the page source.
	 *
	 * @return a string containing the source of the page.
	 */
	public static String getPageSource(WebDriver driver) {
		return driver.getPageSource();
	}

	/**
	 * The title of the current page.
	 *
	 * @param driver Selenium WebDriver managing the browser from which the title
	 *               should be retrieved.
	 *
	 * @return a string containing the title of the currently loaded page.
	 */
	public static String getTitleOfWebPage(WebDriver driver) {
		return driver.getTitle();
	}

	/**
	 * Specifies the amount of time the driver should wait when searching for an
	 * element if it is not immediately present.
	 *
	 * @param driver          Selenium WebDriver upon which to set the timeout.
	 * @param timeUnitSeconds time in seconds to wait.
	 */
	public static void implicitWait(WebDriver driver, int timeUnitSeconds) {
		driver.manage().timeouts().implicitlyWait(timeUnitSeconds, TimeUnit.SECONDS);
	}

	/**
	 * Retrieve the value for the specified key in the chosen environment. <br>
	 * <br>
	 * This method will attempt to load the properties file
	 * "Environment.properties". In the typical scenario this has been located in
	 * the root of the project. If that file is not found, an attempt is then made
	 * to load the file from the resources directory. <br>
	 * <br>
	 * The best practice is to place the project configuration files in the proper
	 * resources directory.
	 *
	 * @param strEnv   environment which has the desired value (PRD, ACC, SYS, etc).
	 * @param strValue the key that is specific to the requested environment.
	 *
	 * @return the value of the specified environment/key requested, null if not
	 *         found.
	 */
	public static String loadEnvironment(String strEnv, String strValue) {
		// ensure we got a proper request
		if (strEnv == null) {
			throw new UserdefinedException("Test environment was not set.");
		}
		if (strValue == null) {
			throw new UserdefinedException("Request key was not set.");
		}
		String key = strEnv.concat(strValue);

		String filename = "Environment.properties";
		Properties properties = new Properties();
		try (FileInputStream fin = new FileInputStream(filename)) {
			// attempt to load from legacy location (root of project)
			properties.load(fin);
			fin.close();
		} catch (SecurityException e) {
			LOGGER.error("Unable to read " + filename, e);
			throw new UserdefinedException("Unable to read file " + filename);
		} catch (Exception e) {
			LOGGER.error("Environment file not found in legacy location " + filename, e);
			throw new UserdefinedException("An error occurred reading a file " + filename);
		}
		return properties.getProperty(key);
	}

	/**
	 * Maximizes the current window if it is not already maximized.
	 *
	 * @param driver Selenium WebDriver managing the browser to maximize.
	 *
	 * @throws InterruptedException
	 */
	public static void maximizeWindow(WebDriver driver) {
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
		driver.manage().window().maximize();
	}

	/**
	 * Move back a single "item" in the browser's history.
	 *
	 * @param driver Selenium WebDriver managing the browser to retrieve the back
	 *               command.
	 */
	public static void navigateBack(WebDriver driver) {
		driver.navigate().back();
	}

	/**
	 * Move a single "item" forward in the browser's history.
	 *
	 * @param driver Selenium WebDriver managing the browser to retrieve the forward
	 *               command.
	 */
	public static void navigateForward(WebDriver driver) {
		driver.navigate().forward();
	}

	/**
	 * Quits this driver, closing every associated window.
	 *
	 * @param driver Selenium WebDriver managing the browser to close all windows.
	 */
	public static void quitBrowser(WebDriver driver) {
		driver.quit();
	}

	/**
	 * Define Chrme browser 1. setCapability 2. connecting in to chrome instance
	 * ChromeOption for capabilities from chrome browser
	 */
	public void chromeBrowser(Proxy proxy, String grid) throws IOException {
		fileSavepath = System.getProperty("user.dir") + "\\Results\\TestResult_"
				+ stdTimeStamp.toString().replace("/", "_").replace(":", "_").replace(" ", "_") + "\\Saved_Files";
		        //File foldercheck = new File(fileSavepath);
		        //if (!foldercheck.exists()) {
		        //    foldercheck.mkdirs();
		        //}

		cOptions.addArguments("test-type");
		cOptions.addArguments("--start-maximized");
		cOptions.addArguments("--js-flags=--expose-gc");
		cOptions.addArguments("--enable-precise-memory-info");
		cOptions.addArguments("--disable-popup-blocking");
		cOptions.addArguments("--disable-default-apps");
		cOptions.addArguments("--disable-extensions");
		cOptions.addArguments("--disable-infobars");
		cOptions.addArguments("chrome.switches", "--disable-extensions");



		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", fileSavepath);
		cOptions.setExperimentalOption("prefs", chromePrefs);

		cOptions.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		cOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap = DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setBrowserName("chrome");
		if (proxy.getHttpProxy() != null) {
			cap.setCapability(CapabilityType.PROXY, proxy);
		}
		cOptions.merge(cap);

		try {
			switch (grid.toUpperCase()) {
			case LOCAL_DRIVER:
				System.setProperty("webdriver.chrome.driver", configProps.getProperty("Browser_Chrome"));
				objdriver.setDriver(new ChromeDriver(cOptions));
				break;
			case GRID_DRIVER:
				RwebDriver = new RemoteWebDriver(new URL(loadEnvironment(System.getProperty(TEST_ENV), ".GRID")), cOptions);
				objdriver.setDriver(RwebDriver);
				break;
			case GLOBAL_DRIVER:
				WebDriverManager.chromedriver().setup();
				objdriver.setDriver(new ChromeDriver(cOptions));
				break;
			default:
				throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
			}

		} catch (Exception e) {
			new UserdefinedException(GRID_TYPE_MESSAGE + e.getMessage());
		}
	}

	/**
	 * Define Edge browser
	 */
	public void edgeBrowser(String grid) throws IOException {
		try {
			switch (grid.toUpperCase()) {
			case LOCAL_DRIVER:
				System.setProperty("webdriver.chrome.driver", configProps.getProperty("Browser_Chrome"));
				objdriver.setDriver(new EdgeDriver(edgeOptions));
				break;
			case GRID_DRIVER:
				RwebDriver = new RemoteWebDriver(new URL(loadEnvironment(System.getProperty(TEST_ENV), ".GRID")), edgeOptions);
				objdriver.setDriver(RwebDriver);
				break;
			case GLOBAL_DRIVER:
				WebDriverManager.edgedriver().setup();
				objdriver.setDriver(new EdgeDriver(edgeOptions));
				break;
			default:
				throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
			}

		} catch (Exception e) {
			new UserdefinedException(GRID_TYPE_MESSAGE + e.getMessage());
		}
	}

	/**
	 * Define Firefox browser
	 */
	public void firefoxBrowser(Proxy proxy, String grid) throws IOException {
		ffOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		ffOptions.setCapability("disable-popup-blocking", true);
		if (proxy.getHttpProxy() != null) {
			cap.setCapability(CapabilityType.PROXY, proxy);
		}
		ffOptions.merge(cap);

		try {
			switch (grid.toUpperCase()) {
			case LOCAL_DRIVER:
				System.setProperty("webdriver.gecko.driver", configProps.getProperty("Browser_Firefox"));
				objdriver.setDriver(new FirefoxDriver(ffOptions));
				break;
			case GRID_DRIVER:
				RwebDriver = new RemoteWebDriver(new URL(loadEnvironment(System.getProperty(TEST_ENV), ".GRID")), ffOptions);
				objdriver.setDriver(RwebDriver);
				break;
			case GLOBAL_DRIVER:
				WebDriverManager.firefoxdriver().setup();
				objdriver.setDriver(new FirefoxDriver(ffOptions));
				Thread.sleep(5000);
				break;
			default:
				throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
			}

		} catch (Exception e) {
			new UserdefinedException(GRID_TYPE_MESSAGE + e.getMessage());
		}
	}

	/**
	 * Start the browser. If grid value is passed as local , script executes in
	 * local machine or else execute in Selenium Grid machine
	 *
	 * @return Selenium WebDriver that manages the opened browser.
	 *
	 * @throws IOException if unable to get system properties from the environment.
	 */
	public void getBrowser(String url, String browser) throws IOException {

		Proxy proxy = new Proxy();
		String grid;
		// Allow the override of the grid setting in the Environment.properties
		if (System.getProperty("grid.hub") == null) {
			throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
		} else {
			grid = System.getProperty("grid.hub");
		}
		proxy = setProxy(proxy);
		if (proxy.getHttpProxy() != null) {
			//LOGGER.info("Browser Proxy is set to "+ proxy.getHttpProxy());
		}
		if (("firefox").equalsIgnoreCase(browser)) {
			firefoxBrowser(proxy, grid);
		} else if (("chrome").equalsIgnoreCase(browser)) {
			chromeBrowser(proxy, grid);
		} else if (("IE").equalsIgnoreCase(browser)) {
			ieBrowser(proxy, grid);
		} else if (("edge").equalsIgnoreCase(browser)) {
			edgeBrowser(grid);
		} else if (("htmlunit").equalsIgnoreCase(browser)) {
			cap = DesiredCapabilities.htmlUnit();
			RwebDriver = new RemoteWebDriver(new URL(grid), cap);
		} else if (("safari").equalsIgnoreCase(browser)) {
			safariBrowser(proxy, grid);
		} else if (("opera").equalsIgnoreCase(browser)) {
			operaBrowser(grid);
		} else if (("chromium").equalsIgnoreCase(browser)) {
			chromeBrowser(proxy, grid);
		} else {
			throw new UserdefinedException("Browser type was not set.");
		}
		maximizeWindow(objdriver.getDriver());

		if (url != null) {
			objdriver.getDriver().get(url);
		} else {
			if(!loadEnvironment(System.getProperty(TEST_ENV), ".Url").isEmpty())
				objdriver.getDriver().get(loadEnvironment(System.getProperty(TEST_ENV), ".Url"));
		}
	}

	/**
	 * Define IE browser
	 */
	public void ieBrowser(Proxy proxy, String grid) throws IOException {
		ieOptions.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		ieOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		ieOptions.setCapability("disable-popup-blocking", true);
		if (proxy.getHttpProxy() != null) {
			cap.setCapability(CapabilityType.PROXY, proxy);
		}
		ieOptions.merge(cap);
		try {
			switch (grid.toUpperCase()) {
			case LOCAL_DRIVER:
				System.setProperty("webdriver.ie.driver", configProps.getProperty("Browser_IE"));
				objdriver.setDriver(new InternetExplorerDriver(ieOptions));
				break;
			case GRID_DRIVER:
				RwebDriver = new RemoteWebDriver(new URL(loadEnvironment(System.getProperty(TEST_ENV), ".GRID")), ieOptions);
				objdriver.setDriver(RwebDriver);
				break;
			case GLOBAL_DRIVER:
				WebDriverManager.iedriver().setup();
				objdriver.setDriver(new InternetExplorerDriver(ieOptions));
				break;
			default:
				throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
			}

		} catch (Exception e) {
			new UserdefinedException(GRID_TYPE_MESSAGE + e.getMessage());
		}
	}

	/**
	 * Define Opera browser
	 */
	public void operaBrowser(String grid) throws IOException {
		try {
			switch (grid.toUpperCase()) {
			case LOCAL_DRIVER:
				System.setProperty("webdriver.ie.driver", configProps.getProperty("Browser_IE"));
				objdriver.setDriver(new InternetExplorerDriver(ieOptions));
				break;
			case GRID_DRIVER:
				RwebDriver = new RemoteWebDriver(new URL(loadEnvironment(System.getProperty(TEST_ENV), ".GRID")), operaOptions);
				objdriver.setDriver(RwebDriver);
				break;
			case GLOBAL_DRIVER:
				WebDriverManager.operadriver().setup();
				objdriver.setDriver(new OperaDriver(operaOptions));
				break;
			default:
				throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
			}

		} catch (Exception e) {
			new UserdefinedException(GRID_TYPE_MESSAGE + e.getMessage());
		}
	}

	/**
	 * Define safari browser
	 */
	public void safariBrowser(Proxy proxy, String grid) throws IOException {
		if (proxy.getHttpProxy() != null) {
			cap.setCapability(CapabilityType.PROXY, proxy);
		}
		safariOptions.merge(cap);
		try {
			switch (grid.toUpperCase()) {
			case GRID_DRIVER:
				RwebDriver = new RemoteWebDriver(new URL(loadEnvironment(System.getProperty(TEST_ENV), ".GRID")), safariOptions);
				objdriver.setDriver(RwebDriver);
				break;
			case GLOBAL_DRIVER:
				WebDriverManager.safaridriver().setup();
				objdriver.setDriver(new SafariDriver(safariOptions));
				break;
			default:
				throw new IllegalArgumentException(GRID_TYPE_MESSAGE);
			}

		} catch (Exception e) {
			new UserdefinedException(GRID_TYPE_MESSAGE + e.getMessage());
		}
	}

	public Proxy setProxy(Proxy proxy) {
		Proxy subProxy = new Proxy();
		if (System.getProperty(PROXY) != null) {
			proxy.setHttpProxy(System.getProperty(PROXY));
		} else if (configProps.getProperty(PROXY) != null) {
			proxy.setHttpProxy(configProps.getProperty(PROXY));
		} else if (loadEnvironment(System.getProperty(TEST_ENV), ".Proxy") != null) {
			proxy.setHttpProxy(loadEnvironment(System.getProperty(TEST_ENV), ".Proxy"));
		} else {
			//LOGGER.info("Browser Proxy is set to " + proxy.getHttpProxy());
		}
		return subProxy;
	}

	public static String frameworkPath(String folderName) {
		String localPath = "Results//TestResult_"
				+ stdTimeStamp.toString().replace("/", "_").replace(":", "_").replace(" ", "_") + File.separator
				+ folderName;

		return localPath;
	}
	
	public void getMobileDriver() throws IOException {
		String username = System.getenv("BROWSERSTACK_USERNAME");
		String accessKey = System.getenv("BROWSERSTACK_ACCESS_KEY");
		String buildName = System.getenv("BROWSERSTACK_BUILD_NAME");
		if (buildName==null) {
			buildName=configProps.getProperty("ProjectName")+" "+System.getProperty("test.env");
		}
		ActionEngine ae = new ActionEngine();
		String server ="hub-cloud.browserstack.com";
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		String[] deviceName =System.getProperty("test.device").split("_");
		
		switch (System.getProperty("test.os").toUpperCase()) {

			case "ANDROID":
				 		  
				desiredCapabilities.setCapability("project", configProps.getProperty("ProjectName"));
				desiredCapabilities.setCapability("browserstack.user", username);
				desiredCapabilities.setCapability("browserstack.key", accessKey);
				desiredCapabilities.setCapability("app_url", configProps.getProperty("AndroidAppURL"));
				desiredCapabilities.setCapability("device", String.join(" ", deviceName));
				desiredCapabilities.setCapability("os_version", System.getProperty("device.OSversion"));					
				desiredCapabilities.setCapability("buildName",buildName);
				desiredCapabilities.setCapability("interactiveDebugging", "True");
				desiredCapabilities.setCapability("browserstack.video", "True");
							  
				objdriver.setAppiumDriver(new AndroidDriver(new URL("http://"+username+":"+accessKey+"@"+server+"/wd/hub"), desiredCapabilities));
				
				break;

			case "IOS":
				
				desiredCapabilities.setCapability("project", configProps.getProperty("ProjectName"));
				desiredCapabilities.setCapability("browserstack.user", username);
				desiredCapabilities.setCapability("browserstack.key", accessKey);
				desiredCapabilities.setCapability("app_url", configProps.getProperty("IOSAppURL"));
				desiredCapabilities.setCapability("device", String.join(" ", deviceName));
				desiredCapabilities.setCapability("os_version", System.getProperty("device.OSversion"));
				desiredCapabilities.setCapability("buildName", buildName);
				desiredCapabilities.setCapability("interactiveDebugging", "True");
				desiredCapabilities.setCapability("browserstack.video", "True");
				
				objdriver.setAppiumDriver(new IOSDriver (new URL("http://"+username+":"+accessKey+"@"+server+"/wd/hub"), desiredCapabilities));
				
				break;
			
			case "WEB":
				
				HashMap<String, Boolean> networkLogsOptions = new HashMap<>();
				networkLogsOptions.put("captureContent", true);
				
				MutableCapabilities caps =new MutableCapabilities();
			 	caps.setCapability("os_version", System.getProperty("device.OSversion"));
				caps.setCapability("device",String.join(" ", deviceName)); 
				caps.setCapability("browserstack.local" , "true");
				caps.setCapability("browserName" ,System.getProperty("browser.type"));
				caps.setCapability("browserstack.user" ,username);
				caps.setCapability("browserstack.key", accessKey);
				caps.setCapability("browserstack.debug", "true");
				caps.setCapability("buildName", buildName);
				caps.setCapability("browserstack.interactiveDebugging", "true");
				caps.setCapability("browserstack.video", "True");
				caps.setCapability("browserstack.seleniumLogs", "true");
				caps.setCapability("browserstack.appiumLogs", "true");
				caps.setCapability("browserstack.networkLogs", true);
				caps.setCapability("browserstack.networkLogsOptions", networkLogsOptions);
				caps.setCapability("browserstack.idleTimeout", "180");
				
				objdriver.setDriver(new RemoteWebDriver(new URL("https://"+server+"/wd/hub"),caps));
				
				break;
			}
	}
	
}
