/**
 * Package containing Unchecked Runtime Exception in Java
 *
 * @author HCL
 */
package com.cnoinc.qa.accelerators;

/**
 * @author HCL0R9
 */
public class UserdefinedException extends RuntimeException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 *
	 * @DataType String
	 */
	public UserdefinedException(String message) {
		super(message);
	}

}
