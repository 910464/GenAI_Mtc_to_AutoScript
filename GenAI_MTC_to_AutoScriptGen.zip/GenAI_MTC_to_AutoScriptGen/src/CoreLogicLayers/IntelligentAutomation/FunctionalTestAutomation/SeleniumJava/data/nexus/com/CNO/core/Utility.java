/**
 * Package: A Utility class used to provide methods that are general to the
 * framework.
 *
 * @author HCL 05 May,2022
 */
package com.cnoinc.qa.utilities;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;
import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.cnoinc.qa.accelerators.ReusableLibrary;
import com.cnoinc.qa.accelerators.UserdefinedException;
import com.cnoinc.qa.support.ExtentManager;

/**
 * A Utility class used to provide methods that are general to the framework.
 */
public class Utility extends ReusableLibrary {
	private static final ConfiguratorSupport configProps = new ConfiguratorSupport("config.properties");
	private static final Logger LOGGER = LogManager.getLogger(Utility.class.getName());
	private static final String DOT_DOCX = ".docx";

	/**
	 * Wait for the specified number of milliseconds.
	 *
	 * @param timeout number of milliseconds to wait before continuing execution.
	 */
	public static void appWait(int timeout) {
		LOGGER.trace("appWait() - Entry");
		try {
			Thread.sleep(timeout);
		} catch (InterruptedException e) {
			LOGGER.debug("Sleep Interrupted", e);
			Thread.currentThread().interrupt();
			throw new UserdefinedException("Failed to wait the specified time, thread was interrupted.");
		}
	}

	/**
	 * Date : Apr 29, 2022 Method Description : captureScreenshot
	 *
	 * @param driver
	 * @param testname
	 * @param comment
	 * @param Status
	 *
	 * @return
	 */
	public static String captureScreenshot(String comment, String fullcomments, String status) {
		String pathScreenshotCapturedSteps = null;
		if (comment.length() > 50) {
			comment = comment.substring(0, 45);
		}
		comment = comment + generateAlphaNumeric(5);
		// Taking a " + status + "ed step screenshot.");
		if (Utility.fnReadPropFile("resultsScreens") != null) {
			String path = "Results//TestResult_"
					+ stdTimeStamp.toString().replace("/", "_").replace(":", "_").replace(" ", "_");
			pathScreenshotCapturedSteps = takeScreenShot(path, status + "_" + comment, fullcomments, status);
			if (pathScreenshotCapturedSteps == null) {
				throw new IllegalArgumentException("Path to captured screenshot was null.");
			}
		} else {
			LOGGER.warn(status + "ed screenshot directory not setup, no screenshot will be taken.");
		}
		return pathScreenshotCapturedSteps;
	}

	/**
	 * Create a directory with specified path.
	 *
	 * @param path Location of the new directory
	 *
	 * @return The path is returned on success and null on failure.
	 */
	public static String createNewDirectory(String path) {
		File file = new File(path);
		if (file.exists()) {
			LOGGER.debug("Directory already exists: " + path);
			return path;
		}
		if (file.mkdir()) {
			LOGGER.debug("Directory was created: " + path);
			return path;
		}
		LOGGER.error("Failed to create directory: " + path);
		return null;
	}

	/**
	 * Capture a screenshot of a failed test step.
	 *
	 * @param testname describes the Test case Name folder to store the screenshot
	 * @param comment  describes the failed test step comment.
	 *
	 * @return path to screenshot on the filesystem or null if screenshot path not
	 *         set in configuration.
	 */
	public static String failScreenshotCapture(String comment, String fullcomments) {
		return captureScreenshot(comment, fullcomments, "Fail");
	}

	/**
	 * Decode the supplied Base64 encoding to the string.
	 *
	 * @param strToBeEncoded string to be encoded.
	 *
	 * @return decoded string.
	 */
	public static String fnPasswordDecoding(String strToBeDecoded) {
		// fnPasswordDecoding() - Entry");
		byte[] decodedValue = Base64.decodeBase64(strToBeDecoded.getBytes());
		return new String(decodedValue);
	}

	/**
	 * Encode the supplied string with Base64 encoding.
	 *
	 * @param strToBeEncoded string to be encoded.
	 *
	 * @return encoded string.
	 */
	public static String fnPasswordEncoding(String strToBeEncoded) {
		// fnPasswordEncoding() - Entry");
		byte[] encodedValue = Base64.encodeBase64(strToBeEncoded.getBytes());
		LOGGER.debug("Encoded String -> " + new String(encodedValue));
		return new String(encodedValue);
	}

	/**
	 * Read back the value from the configuration file referenced by the supplied
	 * key.
	 *
	 * @param strVal key whose value should be returned.
	 *
	 * @return a string containing the value of the key, or null if key wasn't
	 *         found.
	 */
	public static String fnReadPropFile(String strVal) {
		return configProps.getProperty(strVal);
	}

	/**
	 * Function to return the current time, formatted as per the DateFormatString
	 * setting
	 *
	 * @param dateFormatString The date format string to be applied
	 *
	 * @return The current time, formatted as per the date format string specified
	 *
	 * @see #getCurrentTime()
	 * @see #getFormattedTime(Date, String)
	 */
	public static String getCurrentFormattedTime(String dateFormatString) {
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		Calendar calendar = Calendar.getInstance();
		return dateFormat.format(calendar.getTime());
	}

	/**
	 * Return the location of the HTML report.
	 *
	 * @return path to the generated HTML report.
	 */
	public static String htmlReportPathGenerated() {
		// Path of the HTML report generated dynamically: " +
		// ExtentManager.dynamicHtmlReportPath);
		return ExtentManager.dynamicHtmlReportPath;
	}

	/**
	 * Capture a screenshot of a passed test step.
	 *
	 * @param testname describes the Test case Name folder to store the screenshot
	 * @param comment  describes the passed test step comment.
	 *
	 * @return path to screenshot on the filesystem or null if screenshot path not
	 *         set in configuration.
	 */
	public static String passScreenshotCapture(String comment, String fullcomments) {
		return captureScreenshot(comment, fullcomments, "Pass");
	}

	/**
	 * Capture a screenshot and write it to the specified path.
	 *
	 * @param path location on the filesystem to write the screenshot.
	 *
	 * @return full path to the captured screenshot.
	 */
	private static String takeScreenShot(String path, String comment, String detailedComment, String reportstatus) {
		// takeScreenShot() - Entry");
		String screenshotPathdirT = "target//reports//html" + "//Screenshots";
		String screenshotPathdir = path + "//Screenshots";
		String docscreenshotPathdir = path + "//Document";
		Path screenshotPathT = Paths.get(screenshotPathdirT.replace('\\', File.separatorChar));
		Path screenshotPath = Paths.get(screenshotPathdir.replace('\\', File.separatorChar));
		Path docPath = Paths.get(docscreenshotPathdir.replace('\\', File.separatorChar));
		if (!screenshotPath.toFile().exists()) {
			try {
				// Attempting to create directories for screenshots...");
				Files.createDirectories(screenshotPath);
			} catch (IOException e) {
				LOGGER.error("Creating directory failed.", e);
				throw new UserdefinedException("Unable to create directory " + screenshotPath.toString());
			}
		}
		if (!screenshotPathT.toFile().exists()) {
			try {
				// Attempting to create directories for screenshots...");
				Files.createDirectories(screenshotPathT);
			} catch (IOException e) {
				LOGGER.error("Creating directory failed.", e);
				throw new UserdefinedException("Unable to create directory " + screenshotPathT.toString());
			}
		}            
		if (!docPath.toFile().exists()) {
			try {
				// Attempting to create directories for screenshots...");
				Files.createDirectories(docPath);
			} catch (IOException e) {
				LOGGER.error("Creating directory failed.", e);
				throw new UserdefinedException("Unable to create directory " + docPath.toString());
			}
		}
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		String dateString = now.format(fmt);
		dateString = dateString.replace("/", "_");
		dateString = dateString.replace(" ", "_");
		dateString = dateString.replace(":", "_");
		comment = comment.replaceAll("[^A-Za-z0-9]", "");
		String file = screenshotPath.toString() + File.separator + "Screenshot_" + comment.replace(" ", "") + "_"
				+ dateString + ".jpg";
		String fileT = screenshotPathT.toString() + File.separator + "Screenshot_" + comment.replace(" ", "") + "_"
				+ dateString + ".jpg";
		try {
			TakesScreenshot scrShot = ((TakesScreenshot) objdriver.getDriver());
			File scrFile = scrShot.getScreenshotAs(OutputType.FILE);
			File destFile = new File(file);
			File destFileT = new File(fileT);
			Files.copy(scrFile.toPath(), destFile.toPath(), REPLACE_EXISTING);
			Files.copy(scrFile.toPath(), destFileT.toPath(), REPLACE_EXISTING);

			File newFile = new File(docPath.toString() + File.separator + objdriver.getTestCaseName() + DOT_DOCX);
			if (!newFile.exists()) {
				isdocxNotexit(newFile);
			}
			InputStream pic = new FileInputStream(
					docPath.toString() + File.separator + objdriver.getTestCaseName() + DOT_DOCX);
			XWPFDocument document = new XWPFDocument(pic);
			XWPFParagraph paragraph = document.createParagraph();
			XWPFRun run = paragraph.createRun();
			ImageIO.read(destFile);
			attachingScreenshotIntoDox(destFile, paragraph, run, detailedComment, reportstatus, file);
			pic.close();
			document.write(new FileOutputStream(
					new File(docPath.toString() + File.separator + objdriver.getTestCaseName() + DOT_DOCX)));
			document.close();
		} catch (Exception e) {
			LOGGER.error("Failed to record screenshot", e);
			return null;
		}
		LOGGER.debug("Captured screenshot to " + file);
		return file;
	}

	private static void isdocxNotexit(File newFile) {
		try (FileOutputStream out = new FileOutputStream(newFile)) {
			XWPFDocument document1 = new XWPFDocument();
			document1.write(out);
			document1.close();
		} catch (Exception e) {
			LOGGER.error("Failed to write in document", e);
		}
	}

	private static void attachingScreenshotIntoDox(File fileImage, XWPFParagraph paragraph, XWPFRun run,
			String detailedComment, String reportStatus, String screenshotDes) {
		try (InputStream pic1 = new FileInputStream(fileImage)) {
			paragraph.setAlignment(ParagraphAlignment.CENTER);
			run.setBold(true);
			run.setFontFamily(Utility.fnReadPropFile("FontType"));
			run.addBreak();
			run.setText(ScreenDoc + "-" + detailedComment);
			run.addBreak();
			if (reportStatus.equalsIgnoreCase("PASS")) {
				run.setColor("00CC00");
				run.setText("PASS");
			} else {
				run.setColor("FF0000");
				run.setText("FAIL");
			}

			run.addBreak();
			run.addPicture(pic1, getImageFormate(Utility.fnReadPropFile("ScreenshotPicType")), screenshotDes,
					Units.toEMU(Integer.parseInt(Utility.fnReadPropFile("ScreenshotWidth"))),
					Units.toEMU(Integer.parseInt(Utility.fnReadPropFile("ScreenshotHeight"))));
			run.addBreak();
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			LOGGER.error("Failed to attach screenshot in document", e);
		}
	}

	private static int getImageFormate(String imgFileName) {
		int formate;
		if (imgFileName.endsWith(".png"))
			formate = XWPFDocument.PICTURE_TYPE_PNG;
		else if (imgFileName.endsWith(".jpeg") || imgFileName.endsWith(".jpg"))
			formate = XWPFDocument.PICTURE_TYPE_JPEG;
		else {
			return 0;
		}
		return formate;
	}

	/**
	 * Dummy constructor to prevent class instantiation.
	 */
	private Utility() {
		super();
		throw new IllegalStateException("Utility class - static methods only");
	}

}
