/**
 * accelerator package contains framework specific Java classes
 *
 * @author Test Engineer
 */
/**
 * accelerator package has five different support class
 */
package com.cnoinc.qa.accelerators;
