import os
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources import config
from langchain.chat_models import AzureChatOpenAI

class AzureOpenAI:

    def __init__(self):
        os.environ["OPENAI_API_TYPE"] = config.OPENAI_API_TYPE
        os.environ["OPENAI_API_VERSION"] = config.OPENAI_API_VERSION
        os.environ["OPENAI_API_BASE"] = config.OPENAI_API_BASE
        os.environ["OPENAI_API_KEY"] = config.OPENAI_API_KEY

    def load_openai_model(self):
        llm = AzureChatOpenAI(deployment_name="cno-openai-dev-eu2-qa-automation-35-turbo-16k", model_name="gpt-35-turbo-16k", temperature=0.3)
        return llm
