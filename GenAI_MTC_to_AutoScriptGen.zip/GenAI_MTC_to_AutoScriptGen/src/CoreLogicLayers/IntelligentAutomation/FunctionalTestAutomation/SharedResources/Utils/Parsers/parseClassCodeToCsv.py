# import javalang
# import csv
# import os
#
#
# class ParseDataToCsv:
#
#     def __init__(self):
#         pass
#
#     def is_public(self, method):
#         return 'public' in method.modifiers
#
#     def extract_method_info(self, file_path):
#         with open(file_path, 'r') as java_file:
#             source_code = java_file.read()
#
#         tree = javalang.parse.parse(source_code)
#
#         method_info_list = []
#
#         package_name = None
#         class_name = None
#
#         for path, node in tree:
#             if isinstance(node, javalang.tree.PackageDeclaration):
#                 package_name = node.name
#             elif isinstance(node, javalang.tree.ClassDeclaration):
#                 class_name = node.name
#             elif isinstance(node, javalang.tree.MethodDeclaration) and self.is_public(node):
#                 method_name = node.name
#                 method_docs = node.documentation
#
#                 method_info = {
#                     'Package': package_name,
#                     'Class': class_name,
#                     'Method': method_name,
#                     'Documentation': method_docs,
#                     'Code': source_code
#                 }
#
#                 method_info_list.append(method_info)
#
#         return method_info_list
#
#     def save_to_csv(self, file_path, method_info_list):
#         with open(file_path, 'w', newline='', encoding='utf-8') as csvfile:
#             fieldnames = ['Package', 'Class', 'Method', 'Documentation', 'Code']
#             writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
#
#             writer.writeheader()
#             writer.writerows(method_info_list)
#
#     def parse_data(self, folder_path):
#         for filename in os.listdir(folder_path):
#             file_path = os.path.join(folder_path, filename)
#             if os.path.isfile(file_path):
#                 with open(file_path, 'r') as file:
#                     method_info_list = self.extract_method_info(file_path)
#                     output_path = file_path.split("\\")[-1].strip(".java")
#                     self.save_to_csv(f"./data/csv_data/{output_path}.csv", method_info_list)
import csv
import javalang
import json
import os

class ParseClassCodeToCsv:

    def __init__(self):
        pass

    def get_documentation(self, node):
        if node.documentation:
            # Join the lines of documentation with a space to remove line breaks
            return ' '.join(node.documentation.splitlines())
        return ""

    def extract_attributes(self, node):
        attributes = []
        for member in node.body:
            if isinstance(member, javalang.tree.FieldDeclaration):
                for declarator in member.declarators:
                    attribute_name = declarator.name
                    # attribute_type = member.type.name if isinstance(member.type, javalang.tree.BasicType) else member.type.name.value
                    attributes.append(attribute_name)
        return attributes

    def extract_java_info(self, file_path):
        with open(file_path, 'r') as file:
            java_code = file.read()

        tree = javalang.parse.parse(java_code)
        result = []

        for path, node in tree:
            if isinstance(node, javalang.tree.PackageDeclaration):
                package_name = node.name
            elif isinstance(node, javalang.tree.ClassDeclaration):
                class_name = node.name
                public_methods = []
                constructors = []

                for member in node.body:
                    if isinstance(member, javalang.tree.MethodDeclaration) and ('public' or 'protected') in member.modifiers:
                        method_name = member.name
                        parameters = ", ".join(str(param.name) for param in member.parameters)
                        documentation = self.get_documentation(member)
                        public_methods.append(method_name +"("+ parameters +")")

                    elif isinstance(member, javalang.tree.ConstructorDeclaration) and ('public' or 'protected') in member.modifiers:
                        parameters = ", ".join(str(param.name) for param in member.parameters)
                        documentation = self.get_documentation(member)
                        constructors.append("Parameters: "+ parameters)

                attributes = self.extract_attributes(node)

                result.append({'package_name': package_name, 'class_name': class_name, 'attributes': attributes, 'methods': public_methods, 'constructors': constructors})

        return result

    def write_to_csv(self, output_file, data):
        with open(output_file, 'w', newline='') as csvfile:
            fieldnames = ['package_name', 'class_name', 'attributes', 'methods', 'constructors']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()

            for class_info in data:
                writer.writerow({
                    'package_name': class_info['package_name'],
                    'class_name': class_info['class_name'],
                    'attributes': json.dumps(class_info['attributes'], indent=4),
                    'methods': json.dumps(class_info['methods'], indent=4),
                    'constructors': json.dumps(class_info['constructors'], indent=4)
                })

    def parse_data(self, input_path, output_path):
        for filename in os.listdir(input_path):
            file_path = os.path.join(input_path, filename)
            if os.path.isfile(file_path):
                with open(file_path, 'r') as file:
                    try:
                        class_info_list = self.extract_java_info(file_path)
                        output_file = file_path.split("\\")[-1].strip(".java")
                        self.write_to_csv(f"{output_path}/{output_file}.csv", class_info_list)
                    except:
                        print("Cannot parse Java")
