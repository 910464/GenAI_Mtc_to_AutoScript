class MergeSameClassCode:

    def __init__(self):
        pass

    def merge_java_code(self, existing_code, new_methods_code):
        # Extract the class name from the existing code
        class_name = None
        class_declaration_index = None
        for i, line in enumerate(existing_code.split('\n')):
            if line.strip().startswith("public class") or line.strip().startswith("class"):
                class_name = line.split()[-1].split("(")[0]
                class_declaration_index = i
                break

        existing_code_lines = existing_code.split('\n')
        new_methods = []
        new_locators = []

        # Capture non-constructor methods and locator variables from the new code
        capturing_methods = False
        capturing_locators = False

        for line in new_methods_code.split('\n'):
            stripped_line = line.strip()

            if capturing_methods:
                new_methods.append(line)
            elif capturing_locators:
                new_locators.append(line)

            if (stripped_line.startswith("public") or stripped_line.startswith(
                    "private")) and not stripped_line.startswith(
                    f"public {class_name}(") and not stripped_line.startswith(f"private {class_name}("):
                capturing_methods = True
            elif stripped_line.startswith("private By "):
                capturing_locators = True
            elif stripped_line == "}":
                capturing_methods = False
                capturing_locators = False

        # Check if locators already exist inside the class declaration and add only if not present
        if class_declaration_index is not None:
            for locator in new_locators:
                if locator.strip() not in existing_code_lines[class_declaration_index:]:
                    existing_code_lines.insert(class_declaration_index + 1, locator)

        # Find the index where methods need to be added
        insert_index = None
        for i in range(len(existing_code_lines) - 1, -1, -1):
            if existing_code_lines[i].strip().startswith("}"):
                insert_index = i
                break

        # If a valid insertion point is found, insert the new methods
        if insert_index is not None:
            merged_code_lines = existing_code_lines[:insert_index] + new_methods + existing_code_lines[insert_index:]
        else:
            # If no insertion point is found, just append the new methods to the end
            merged_code_lines = existing_code_lines + new_methods

        # Join the lines back into a single string
        merged_code = '\n'.join(merged_code_lines)
        print("Code Merged Successfully ")

        return merged_code
