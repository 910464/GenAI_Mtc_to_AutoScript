import re

import pandas as pd
from src.DAOLayer.ChromaDBConnector import ChromaDBConnector

seleJavaPath = "../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava"

def concatenate_columns(row):
    return f"\n{row['action']} {row['object']}"

def retrieve_exist_code(page_name, page_data):
    db = ChromaDBConnector(f"{seleJavaPath}/data/embed_data_gen/code")
    db2 = ChromaDBConnector(f"{seleJavaPath}/data/embed_data_gen/csv")

    details = page_data.apply(concatenate_columns, axis=1)
    try:
        # exist_page = validate_word_in_content(db.retrieval(
        #     f"Get Page Class code for {page_name}Page where locators and method defined for {details}", 3),
        #     "package pages")

        exist_page_name = page_name+'Page'
        exist_page = db.get_doc_by_id(exist_page_name)
        exist_page_code = exist_page['documents'][0]

        missing_methods = []
        # Iterate through rows in the DataFrame
        previous_index = -1
        for index, row in page_data.iterrows():

            method_content = ""
            if row['action'] == "Select" and not pd.isna(row['data']):
                method_content = db2.retrieval(
                    f"Get method details for '{row['action']} {row['object']} {row['data']}' from class {exist_page_name}", 3)
            else:
                method_content = db2.retrieval(
                    f"Get method details for '{row['action']} {row['object']}' from class {exist_page_name}", 3)

            for i in range(len(method_content)):
                pattern = r'Class:\s*(\w+)'
                class_name = re.search(pattern, method_content[i].page_content).group(1)
                if class_name == exist_page_name:
                    method_details = method_content[i].page_content
                    break

            # Use regex to search for the method in the Java class code
            pattern = r'Method:\s*(\w+)'
            method_name = re.search(pattern, method_details).group(1)
            method_pattern = f"public void {method_name}\(\) \{{"
            match = re.search(method_pattern, exist_page_code)

            if match:
                method_start_index = match.start()
                if method_start_index > previous_index:
                    print(f"Method '{method_name}' found in Java class code at index {method_start_index}")
                    previous_index = method_start_index
                else:
                    print(f"Method '{method_name}' found out of sequence")
                    # If method is out of sequence, add it to the missing_methods_df
                    missing_methods = missing_methods.append({'Method_Name': method_name})
            else:
                print(f"Method '{method_name}' not found in Java class code")
                # If method is missing, add it to the missing_methods_df
                missing_methods = missing_methods.append({'Method_Name': method_name})

        return pd.DataFrame(missing_methods), exist_page_code
    except Exception as e:
        print(e)
        return page_data, ""
