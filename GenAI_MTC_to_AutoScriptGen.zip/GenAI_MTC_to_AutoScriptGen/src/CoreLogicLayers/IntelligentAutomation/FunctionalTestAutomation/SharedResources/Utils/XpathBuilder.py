from bs4 import BeautifulSoup, Tag
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import math
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException, ElementNotInteractableException


class XpathBuilder:
    def __init__(self, xp):
        self.xpath = xp

    def calculate_distance(self, element1, element2):
        x1, y1 = element1.location['x'], element1.location['y']
        x2, y2 = element2.location['x'], element2.location['y']

        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        return distance

    def create_xpath_from_link_text(self, soup, link_text, driver):
        """
        Takes BeautifulSoup, link text, and a Selenium webdriver as inputs and returns a list
        of XPath expressions to select elements that have the specified link text and are visible on the page.
        """
        found = False
        elements = []
        xpaths = []
        driver.switch_to.default_content()
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        while not found:
            elements = soup.find_all(text=lambda text: link_text in str(text))
            if elements:
                found = True
            else:
                soup = BeautifulSoup(driver.page_source, 'html.parser')
        for elem in elements:
            xpath_parts = []
            actual_node = elem.parent
            # build the xpath by traversing the element's ancestors
            while elem.parent is not None:
                # siblings = elem.parent.find_all(text=lambda text: link_text in str(text), recursive=False)

                xpath_tag = elem.name if isinstance(elem, Tag) else ""
                siblings = elem.parent.find_all(xpath_tag, recursive=False)
                if len(siblings) > 1:
                    sibling_index = siblings.index(elem) + 1
                    xpath_parts.append(f"{xpath_tag}[{sibling_index}]")
                else:
                    xpath_parts.append(xpath_tag)
                elem = elem.parent
            xpath_parts.reverse()
            xpath = "/".join(xpath_parts)
            xpaths.append(xpath)
        return xpaths

    def get_nearest_input(self, soup, link_text, driver):
        found = False
        elements = []
        xpaths = []
        # driver.switch_to.default_content()
        while not found:
            elements = soup.find_all(text=lambda text: link_text in str(text))
            if elements:
                check_if_any_have_link_text = False
                for elem in elements:
                    if elem.text.find(link_text) != -1:
                        check_if_any_have_link_text = True
                if check_if_any_have_link_text:
                    found = True
                else:
                    driver.switch_to.default_content()
                    soup = BeautifulSoup(driver.page_source, 'html.parser')
            else:
                driver.switch_to.default_content()
                soup = BeautifulSoup(driver.page_source, 'html.parser')
        for elem in elements:
            if elem.text.find(link_text) != -1:
                xpath_parts = []
                # build the xpath by traversing the element's ancestors
                while elem.parent is not None:
                    # siblings = elem.parent.find_all(text=lambda text: link_text in str(text), recursive=False)

                    xpath_tag = elem.name if isinstance(elem, Tag) else ""
                    siblings = elem.parent.find_all(xpath_tag, recursive=False)
                    if len(siblings) > 1:
                        sibling_index = siblings.index(elem) + 1
                        xpath_parts.append(f"{xpath_tag}[{sibling_index}]")
                    else:
                        xpath_parts.append(xpath_tag)
                    elem = elem.parent
                xpath_parts.reverse()
                xpath = "/".join(xpath_parts)
                xpaths.append(xpath)
        # ll select the first one as default selection option
        for xp in xpaths:
            get_el_xp = str(xp).rpartition("/")[0]
            get_el = driver.find_element(By.XPATH, get_el_xp)
            # print('get_el: ', get_el)
        link_text_element = str(xpaths[0]).rpartition("/")[0]
        lt_element = driver.find_element(By.XPATH, link_text_element)
        driver.execute_script("arguments[0].style.border='3px solid red'", lt_element)
        input_ele = driver.find_elements(By.TAG_NAME, 'input')
        # need to change above to get xpaths
        input_list = soup.find_all('input')
        kb_attr_list = ['id', 'name', 'placeholder', 'value', 'title', 'type', 'class']
        distance = 0
        actual_in = None
        rxp = ''
        for in_el in input_list:
            final_xpath_of_in = XpathBuilder.generate_xpath(XpathBuilder, soup, in_el, driver)
            check_for_visible_element = driver.find_element(By.XPATH, final_xpath_of_in)
            if XpathBuilder.is_element_interactable(XpathBuilder, driver, check_for_visible_element):
                mark = XpathBuilder.calculate_distance(XpathBuilder, lt_element, check_for_visible_element)
                # driver.execute_script("arguments[0].style.border='3px solid red'", inp)
                if distance == 0:
                    distance = mark
                    actual_in = check_for_visible_element
                    rxp = final_xpath_of_in
                elif mark < distance:
                    distance = mark
                    actual_in = check_for_visible_element
                    rxp = final_xpath_of_in
                # print('distance: ', mark)
            print("Xpath: ", final_xpath_of_in)
            #       Keep below code for future reference
            # if (not input_ele.has_attr("type")) or (input_ele.has_attr("type") and input_ele['type'] != "hidden"):
            #     for attr in kb_attr_list:
            #         if input_ele.has_attr(attr):
            #             locator = XpathBuilder.calc_xpath(XpathBuilder, 'input', attr, input_ele)
            #             print(attr, ":", locator)

        driver.execute_script("arguments[0].style.border='3px solid red'", actual_in)
        return rxp, actual_in

    def is_element_interactable(self, driver, by_locator, timeout=10):
        try:
            WebDriverWait(driver, timeout).until(EC.element_to_be_clickable(by_locator))
            return True
        except (TimeoutException, ElementNotInteractableException):
            return False

    def calc_xpath(self, tag, attr, element):
        if type(element[attr]) is list:
            element[attr] = [i.encode('utf-8').decode('latin-1') for i in element[attr]]
            element[attr] = ' '.join(element[attr])
            xpath = "//%s[@%s='%s']" % (tag, attr, element[attr])
            return xpath

    def generate_xpath(self, soup, elem, driver):
        # driver.switch_to.default_content()
        # soup = BeautifulSoup(driver.page_source, 'html.parser')
        xpath_parts = []
        # build the xpath by traversing the element's ancestors
        while elem.parent is not None:
            # siblings = elem.parent.find_all(text=lambda text: link_text in str(text), recursive=False)

            xpath_tag = elem.name if isinstance(elem, Tag) else ""
            siblings = elem.parent.find_all(xpath_tag, recursive=False)
            if len(siblings) > 1:
                sibling_index = siblings.index(elem) + 1
                xpath_parts.append(f"{xpath_tag}[{sibling_index}]")
            else:
                xpath_parts.append(xpath_tag)
            elem = elem.parent
        xpath_parts.reverse()
        xpath = "/".join(xpath_parts)
        return xpath
