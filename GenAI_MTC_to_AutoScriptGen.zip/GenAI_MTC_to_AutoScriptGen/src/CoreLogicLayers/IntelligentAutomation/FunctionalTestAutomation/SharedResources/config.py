OPENAI_API_TYPE = "azure"
OPENAI_API_VERSION = "2024-02-15-preview"
OPENAI_API_BASE = "https://cno-openai-dev-eu2-qa-automation.openai.azure.com/"
OPENAI_API_KEY = "f5ee12416c914b92b2b06787f1a3428d"