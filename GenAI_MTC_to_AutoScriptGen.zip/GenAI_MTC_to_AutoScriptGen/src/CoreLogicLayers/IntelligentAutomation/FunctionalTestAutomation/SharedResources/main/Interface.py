import os
import shutil

from src.Constants import DBConstants
from src.DAOLayer.MongoReadWrite import mongoReadWrite
from datetime import datetime
import time
import pandas as pd
from src.CoreLogicLayers.IntelligentAutomation.FunctionalTestAutomation.SharedResources.main import ScriptGeneration
from src.Utilities.FileHandling.FileHandling import create_zip

mongo_obj = mongoReadWrite()

def generate_automation_script(processing_json):
   start = time.time()
   print(processing_json['jobID'])
   execution_details = {'jobID': processing_json['jobID'], 'description': 'Not decided yet',
                         'useCaseName': processing_json['useCaseName'],
                         'generationOption': str(processing_json), 'input': 1, 'output': 'N/A',
                         'executedOn': datetime.now().strftime("%dth %b, %Y %H:%M:%S"), 'timeTaken': 0,
                         'executedBy': processing_json['executedBy'], 'executionStatus': 'Generating'}

   timestamp = execution_details['executedOn'].replace(' ','').replace(':','')
   execution_details_df = pd.DataFrame(execution_details, index=[0])
   mongo_obj.write_data('ExecutionSummary', execution_details_df)
   try:
        content = mongo_obj.read_filecontent_from_gridfs(DBConstants.FILES_COLLECTION, processing_json['fileName'])
        ScriptGeneration.generate(content.decode(), processing_json)
        execution_details['executionStatus'] = 'Completed'
        execution_details['output'] = 7
        execution_details['timeTaken'] = (time.time() - start).__round__()
        execution_details_df = pd.DataFrame(execution_details, index=[0])
        mongo_obj.update_data_based_on_jobid('ExecutionSummary', execution_details_df, execution_details['jobID'])
        if processing_json['language'] == "Selenium-Java":
            shutil.copytree("../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/data/craft/com",
                            f"../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/{processing_json['language']}Output/com",
                            dirs_exist_ok=True)
        create_zip(f"../CoreLogicLayers/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/{processing_json['language']}Output", f"../dataupload/{processing_json['fileName']}{timestamp}.zip")
        mongo_obj.store_zip_in_mongodb(DBConstants.SCRIPTS_COLLECTION, f"../dataupload/{processing_json['fileName']}{timestamp}.zip", execution_details['jobID'])

        # Clean up: remove the temporary ZIP file
        os.remove(f"../dataupload/{processing_json['fileName']}{timestamp}.zip")

        return {"message": "Script generated successfully"}
   except Exception as e:
       execution_details['executionStatus'] = 'Failed'
       execution_details['timeTaken'] = (time.time() - start).__round__()
       execution_details_df = pd.DataFrame(execution_details, index=[0])
       mongo_obj.update_data_based_on_jobid('ExecutionSummary', execution_details_df, execution_details['jobID'])
       print(e)
       return {"message": "Script generation failed"}
