import datetime
import os

from src.Constants import DBConstants
from src.DAOLayer.MongoReadWrite import mongoReadWrite
from src.EncryptionLayer.Decryption import FileDecryptor
from src.LLMLayer.LLM import LLM


def getBDD(query, context, input_param):
    isPositive = input_param['isPositive']
    isNegative = input_param['isNegative']
    isTestData = input_param['isTestData']
    isAdditionalAC = input_param['isAdditionalAC']
    isLLM = input_param['isLLM']
    ac_generated = ''

    mongo_obj = mongoReadWrite()
    file_decryptor = FileDecryptor()
    model = LLM()

    instruction = """-> Generate BDD Feature file STRICTLY sticking to the Valid CUCUMBER BDD FORMAT ONLY that have 'Feature' and either 'Scenario' or 'Scenario Outline'.
If the BDD scenario has Example, then it should be Called Scenario Outline, else it should be called Scenario.
DON'T give scenario heading as Positive Scenario: or Negative Scenario: as it is not a valid cucumber bdd format.

    -> In the example I have mentioned above, for the BDD you will generate, if the BDD steps are going to be the same,
    then reuse the BDD steps I have mentioned in the example above\n"""

    private_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION, "private_key.pem")
    encryption_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION,
                                                            "encryption_key.bin")

    PROMPT = file_decryptor.decrypt_file("../PromptLayer", "TestPlanningPrompt.enc", private_key,
                                         encryption_key)

    AC_PROMPT = PROMPT.decode('utf-8', errors='ignore').split('"""')[5]

    if isLLM == False:
        instruction += '-> Don\'t use your own intelligence while generating the output. STRICTLY stick to the format\n'

    if isAdditionalAC:
        ac_generated = model.send_request(input_param, AC_PROMPT, ["UserStory"], {"UserStory": query})
        query += '\n'
        query += ac_generated

    if isTestData:
        instruction += """-> To Generate Example for each BDD Scenario and add it at the end of each BDD.
        For scenarios where Test Data/Example is not applicable, then "STRICTLY" don't generate Examples.
        For scenarios where Test Data is applicable, "STRICTLY" ensure to put the variables inside "<>" inside BDD WITHOUT FAILURE.
        The variables inside <> HAS to be considered for test data in Examples.
        Below is an instance for reference: -
        Scenario Outline: Banker creates a Corporate Account for a customer
                When API_Banker creates Corporate Account with mandatory details such as "<customer_id>","<currency>","<arrangementEffectiveDate>"
                Then API_Banker should have corporate account Created successfully
                Examples:
                    | customer_id | currency | arrangementEffectiveDate |
                    | custId      | USD      | currentDate              |

        Here you can Clearly see that variables "<customer_id>","<currency>","<arrangementEffectiveDate>" are being considered for examples,
        because they are present in <> and are variables. In this case, this is the test data.
        So, Ensure that if test data is applicable, then it HAS to be present in <> STRICTLY and then the corrosponding data has to be present in Examples
        \n
        """

        # instruction = """To generate Examples for each BDD scenario and add it at the end of the BDD. The variable
        #                in Example needs to be present inside \"<>\" in the BDD corrosponding Scenario"""
    else:
        instruction += '-> Don\'t generate any example for any bdd scenario.\n'

    if not (isPositive is False and isNegative is False):
        if isPositive:
            instruction += '-> To Generate all possible positive BDD scenarios for the given UserStory\n'
        else:
            instruction += '-> Don\'t generate positive BDD scenarios for the given UserStory\n'

        if isNegative:
            instruction += '-> To Generate all possible negative BDD scenarios for the given UserStory\n'
        else:
            instruction += '-> Don\'t generate negative BDD scenarios for the given UserStory\n'

    BDD_PROMPT = PROMPT.decode('utf-8', errors='ignore').split('"""')[1]
    # BDD_PROMPT = """
    # I want you to act as a test engineer expert.
    # I am giving you User Story Description, User Story Acceptance Criteia and corresponding to these are mapped BDD scenarios.
    # Let's understand each pair one by one.
    # {context}
    #
    # From the above example, you can clearly see that for the Given UserStoryDescription and UserStoryAcceptanceCriteria, there are multiple BDD scenarios.
    #
    # Make sure to follow the below instructions STRICTLY WITHOUT FAIL.
    # Ensure to:
    # -> Generate BDD Feature file STRICTLY sticking to the Valid CUCUMBER BDD FORMAT ONLY.
    # If the BDD scenario has Example, then it should be Called Scenario Outline, else it should be called Scenario
    # DON'T give scenario heading as Positive Scenario: or Negative Scenario: as it is not a valid cucumber bdd format.
    # {instruction}
    #
    # Now you have a clear idea. I want you to generate BDD Scenarios for the below User Story Description and User Story Acceptance Criteria.
    # {UserStory}
    # """

    print(BDD_PROMPT + "\n" + instruction)

    output = model.send_request(input_param, BDD_PROMPT, ["context", "instruction", "UserStory"],
                                {"context": context, "instruction": instruction, "UserStory": query})

    output_dir = r"../CoreLogicLayer/TestPlanning/SharedResources/result_logs"
    try:
        os.makedirs(output_dir, exist_ok=True)
    except OSError as e:
        print(f"Error creating directory: {e}")

    # Combine the prefix, timestamp, and file extension to create the filename
    currtime = datetime.datetime.now()
    currtime = currtime.strftime("%Y-%m-%d-%H-%M-%S-%f")[:-3]
    output_path = f"{output_dir}/bdd_{currtime}.txt"

    with open(output_path, "a", encoding="utf-8") as file:
        file.write(output + "\n\n\n\n")
    print("BDD generated")
    return [output, ac_generated]


def getBDD_no_context(query, input_param):
    isPositive = input_param['isPositive']
    isNegative = input_param['isNegative']
    isTestData = input_param['isTestData']
    isAdditionalAC = input_param['isAdditionalAC']
    ac_generated = ''

    mongo_obj = mongoReadWrite()
    file_decryptor = FileDecryptor()
    model = LLM()
    instruction = """-> Generate BDD Feature file STRICTLY sticking to the Valid CUCUMBER BDD FORMAT ONLY that have 'Feature' and either 'Scenario' or 'Scenario Outline'.
If the BDD scenario has Example, then it should be Called Scenario Outline, else it should be called Scenario.
DON'T give scenario heading as Positive Scenario: or Negative Scenario: as it is not a valid cucumber bdd format.
    Make sure to merge all acceptance criteria and create one BDD scenario. Make sure to reduce number of scenarios covering all acceptance criteria.
    -> In the example I have mentioned above, for the BDD you will generate, if the BDD steps are going to be the same,
    then reuse the BDD steps I have mentioned in the example above\n"""

    private_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION, "private_key.pem")
    encryption_key = mongo_obj.read_filecontent_from_gridfs(DBConstants.KEY_FILES_COLLECTION,
                                                            "encryption_key.bin")

    PROMPT = file_decryptor.decrypt_file("../PromptLayer", "TestPlanningPrompt.enc", private_key,
                                         encryption_key)

    AC_PROMPT = PROMPT.decode('utf-8', errors='ignore').split('"""')[5]

    if isAdditionalAC:
        ac_generated = model.send_request(input_param, AC_PROMPT, ["UserStory"], {"UserStory": query})
        query += '\n'
        query += ac_generated

    if isTestData:
        instruction += """-> To Generate Example for each BDD Scenario and add it at the end of each BDD.
        For scenarios where Test Data/Example is not applicable, then "STRICTLY" don't generate Examples.
        For scenarios where Test Data is applicable, "STRICTLY" ensure to put the variables inside "<>" inside BDD WITHOUT FAILURE.
        The variables inside <> HAS to be considered for test data in Examples.
        Below is an instance for reference: -
        Scenario Outline: Banker creates a Corporate Account for a customer
                When API_Banker creates Corporate Account with mandatory details such as "<customer_id>","<currency>","<arrangementEffectiveDate>"
                Then API_Banker should have corporate account Created successfully
                Examples:
                    | customer_id | currency | arrangementEffectiveDate |
                    | custId      | USD      | currentDate              |

        Here you can Clearly see that variables "<customer_id>","<currency>","<arrangementEffectiveDate>" are being considered for examples,
        because they are present in <> and are variables. In this case, this is the test data.
        So, Ensure that if test data is applicable, then it HAS to be present in <> STRICTLY and then the corrosponding data has to be present in Examples
        \n
        """
    else:
        instruction += '-> Don\'t generate any example for any bdd scenario.\n'
    if isPositive and isNegative:
        instruction += '-> Generate both positive and negative BDD scenarios for the given UserStory\n'
    elif isPositive and not isNegative:
        instruction += '-> Generate all positive BDD scenarios for the given UserStory\n'
    elif isNegative and not isPositive:
        instruction += '-> Generate all negative BDD scenarios for the given UserStory\n'
    else:
        instruction += '-> Generate both positive and negative BDD scenarios for the given UserStory\n'

    BDD_PROMPT = """
        Act as an Test Engineer Expert. I am giving you a User Story, User Story Description and User Story Acceptance Criteria.
        Make sure to merge all acceptance criteria and create one BDD scenario. Make sure to reduce number of scenarios covering all acceptance criteria.
        While generating the BDD, make sure to follow the instructions strictly: -
        {instruction}
        Now, generate BDD for this scenario:
        {UserStory}
        BDD: 
    """

    output = model.send_request(input_param, BDD_PROMPT, ["instruction", "UserStory"],
                                {"instruction": instruction, "UserStory": query}, 0.05)

    output_dir = r"../CoreLogicLayer/TestPlanning/SharedResources/result_logs"
    try:
        os.makedirs(output_dir, exist_ok=True)
    except OSError as e:
        print(f"Error creating directory: {e}")

    # Combine the prefix, timestamp, and file extension to create the filename
    currtime = datetime.datetime.now()
    currtime = currtime.strftime("%Y-%m-%d-%H-%M-%S-%f")[:-3]
    output_path = f"{output_dir}/bdd_{currtime}.txt"

    with open(output_path, "a", encoding="utf-8") as file:
        file.write(output + "\n\n\n\n")
    print("BDD generated")
    return [output, ac_generated]

