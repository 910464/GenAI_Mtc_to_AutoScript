from src.Constants import DBConstants
from src.DAOLayer.MongoReadWrite import mongoReadWrite
from datetime import datetime
import time
from src.CoreLogicLayers.TestPlanning.BDDGeneration.Src.GenerateBDD import generate
import pandas as pd
import re
import traceback

mongo_obj = mongoReadWrite()

def generate_bdd(processing_json):
    print('Inside generateBDD')
    start = time.time()
    print(processing_json['jobID'])
    execution_details = {'jobID':processing_json['jobID'],'userStoryID':processing_json['userStoryID'],'description': 'Not decided yet', 'useCaseName': processing_json['useCaseName'],
                         'generationOption': str(processing_json), 'input': 1, 'output': 'N/A',
                         'executedOn': datetime.now().strftime("%dth %b, %Y %H:%M:%S"), 'timeTaken': 0,
                         'executedBy': processing_json['executedBy'], 'executionStatus': 'Generating',
                         'projectID': processing_json['projectID']}

    if processing_json['isMultipleUserStory']:
        execution_details['input'] = len(processing_json['multipleUserStory'])

    execution_details_df = pd.DataFrame(execution_details, index=[0])
    mongo_obj.write_data(DBConstants.EXECUTION_SUMMARY_COLLECTION, execution_details_df)
    try:
        generate(input_param=processing_json)
        if processing_json['isSingleUserStory']:
            data = []
            bdd_df = mongo_obj.read_data_with_filter(DBConstants.BDD_COLLECTION, "userStoryID::eq::" + processing_json['userStoryID'] + "<<>>jobID::eq::" + processing_json['jobID'], 0)
            scenarios = re.split(r"Scenario \d+: |Scenario Outline: |Scenario:", bdd_df.iloc[0]['generatedBDD'])[1:]

            for scenario in scenarios:
                lines = scenario.strip().split('\n')
                if lines:
                    scenario_outline = lines[0].strip()
                    feature = "\n".join(lines[1:])
                    data.append({
                        "scenarioOutline": scenario_outline.strip(),
                        "feature": "Scenario Outline: " + scenario_outline.strip() + "\n" + feature.strip()
                    })

            execution_details['executionStatus'] = 'Completed'
            execution_details['output'] = len(data)

            execution_details['timeTaken'] = time.time() - start
            execution_details_df = pd.DataFrame(execution_details, index=[0])

            mongo_obj.update_data_based_on_jobid(DBConstants.EXECUTION_SUMMARY_COLLECTION, execution_details_df, execution_details['jobID'])

            return {"message": 'BDD Generation Successful', "status": 200}

        else:
            multi_us = processing_json['multipleUserStory']
            data = []
            for userstory_id in multi_us:
                bdd_df = mongo_obj.read_data_with_filter(DBConstants.BDD_COLLECTION, "userStoryID::eq::" + userstory_id.split('.')[0] + "<<>>jobID::eq::" + processing_json['jobID'],
                                                         0)
                scenarios = re.split(r"Scenario \d+: |Scenario Outline: |Scenario:", bdd_df.iloc[0]['generatedBDD'])[1:]

                for scenario in scenarios:
                    lines = scenario.strip().split('\n')
                    if lines:
                        scenario_outline = lines[0].strip()
                        feature = "\n".join(lines[1:])
                        data.append({
                            "scenarioOutline": scenario_outline.strip(),
                            "feature": "Scenario Outline: " + scenario_outline.strip() + "\n" + feature.strip()
                        })

            execution_details['executionStatus'] = 'Completed'
            execution_details['output'] = len(data)

            execution_details['timeTaken'] = time.time() - start
            execution_details_df = pd.DataFrame(execution_details, index=[0])

            mongo_obj.update_data_based_on_jobid(DBConstants.EXECUTION_SUMMARY_COLLECTION, execution_details_df,
                                                execution_details['jobID'])

            return {"message": 'BDD Generation Successful', "status": 200}
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        execution_details['executionStatus'] = 'Failed'
        execution_details['timeTaken'] = time.time() - start
        execution_details_df = pd.DataFrame(execution_details, index=[0])
        mongo_obj.update_data_based_on_jobid(DBConstants.EXECUTION_SUMMARY_COLLECTION, execution_details_df, execution_details['jobID'])
        return {"message": 'BDD Generation Failed', "status": 500}


def get_bdd_result(jobID):
    bdd_df = mongo_obj.read_data_with_filter(DBConstants.BDD_COLLECTION, "jobID::eq::" + jobID, 50)
    results = []

    for scenarios in bdd_df[['generatedBDD','userStoryID','inputUserstory',"contextAndScore","useContextbool"]].values:
        bdd_scenario = re.split(r"Scenario \d+: |Scenario Outline: |Scenario:", scenarios[0])[1:]
        cont_bool = scenarios[4]
        data = []
        for scenario in bdd_scenario:
            lines = scenario.strip().split('\n')
            if lines:
                scenario_outline = lines[0].strip()
                feature = "\n".join(lines[1:])
                data.append({
                    "scenarioOutline": scenario_outline.strip(),
                    "feature": "Scenario Outline: " + scenario_outline.strip() + "\n" + feature.strip()
                })
        if len(data) == 0:
            results.append({"userStoryID": scenarios[1], "userStory": scenarios[2],
                        "message": 'BDD Generation Failed', "status": 500})
        else:
            if cont_bool:
                list_context = eval(scenarios[3])
                results.append({"userStoryID": scenarios[1], "userStory": scenarios[2],"contextAndscore":list_context,"useContextbool":scenarios[4],
                        "bddFeature": data})
            else:
                results.append({"userStoryID": scenarios[1], "userStory": scenarios[2],"bddFeature": data})
    return results

def read_bdd_data(jobID):
    bdd_df = mongo_obj.read_data_with_filter(DBConstants.BDD_COLLECTION, "jobID::eq::" + jobID, 0)
    return bdd_df