from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.document_loaders import DirectoryLoader, TextLoader
from langchain.schema.document import Document
from langchain.document_loaders.base import BaseLoader
import os
import chromadb
from datetime import datetime


# class vectordb:
#
#     def connect(self, collection_name):
#         client = chromadb.PersistentClient(path="./chroma_database")
#         collection = client.get_or_create_collection(name=collection_name)
#         return collection
#
#     def add_collection(self, collection_name, data, metadata, id_list):
#         collection = self.connect(collection_name)
#         collection.add(
#             documents=data,
#             metadatas=metadata,  # [{"source": "my_source"}, {"source": "my_source"}]
#             ids=id_list  # ["id1", "id2"]
#         )
#
#     def query(self, collection_name, query_text, n):
#         collection = self.connect(collection_name)
#         results = collection.query(
#             query_texts=[query_text],
#             n_results=n
#         )
#         # print(results)
#         return results


class ChromaDBConnector:

    def __init__(self, persist_directory):
        self.embeddings = HuggingFaceEmbeddings()
        self.persist_directory = persist_directory
        self.context = ''
        self.timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


    def vectordb_store_dir(self, data_path):
        loader = DirectoryLoader(data_path, glob="**/*.csv", loader_cls=CSVLoader)
        data = loader.load()
        # print(data)
        # load it into Chroma
        db = Chroma.from_documents(documents=data, embedding=self.embeddings,
                                   ids=[doc.metadata['source'].split("\\")[-1].split(".")[0] for doc in data], persist_directory=self.persist_directory)
        db.persist()

    def vectordb_store_doc(self, data_path):
        loader = CSVLoader(data_path)
        data = loader.load()
        # print(data)
        # load it into Chroma
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings)
        db.persist()
        ids = db.add_documents(documents=data)
        db.persist()
        return len(ids)

    def vectordb_store_code(self, code, f_name):
        data = Document(page_content=code)

        # load it into Chroma
        db = Chroma.from_documents(documents=[data], embedding=self.embeddings,
                                   persist_directory=self.persist_directory, ids=[f_name])
        db.persist()

    def retrieval(self, query, k):
        # if os.path.exists(self.persist_directory) and os.path.isdir(self.persist_directory):
        #     print("The folder exists.")
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings)
        retrieved_docs = db.similarity_search(query, k=k)
        return retrieved_docs

    def retrieval_context(self, query, k):

        retrieval_dir = r"../CoreLogicLayers/TestPlanning/SharedResources/data/retrieval_context"
        # try:
        #     os.makedirs(retrieval_dir, exist_ok=True)
        # except OSError as e:
        #     print(f"Error creating directory: {e}")

        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings)
        retrieved_docs = db.similarity_search(query, k=k)
        for doc in retrieved_docs:
            content = doc.page_content
            self.context += (content + '\n')

        output_path = f"{retrieval_dir}/retrieved_{self.timestamp}.txt"
        with open(output_path, "a", encoding="utf-8") as file:
            file.write(self.context)

        return self.context


    def get_docs(self):
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings)
        return db.get()

    def get_doc_by_id(self, id):
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings)
        return db.get(ids=[id])

    def vector_store(self, fpath):

        embedding_path = r"../CoreLogicLayers/TestPlanning/SharedResources/data/embed_data"

        try:
            os.makedirs(embedding_path, exist_ok=True)
        except OSError as e:
            print(f"Error creating directory: {e}")

        # load the json data
        loader = CSVLoader(file_path=fpath, encoding="utf-8")
        documents = loader.load()

        # load it into Chroma
        db = Chroma.from_documents(documents, self.embeddings, persist_directory=embedding_path)
        db.persist()

