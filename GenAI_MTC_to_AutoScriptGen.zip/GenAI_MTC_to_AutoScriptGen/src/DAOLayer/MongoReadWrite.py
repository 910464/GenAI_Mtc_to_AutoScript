import io
import json
import os
import re

import dateutil.parser
import pandas as pd
import pytz
from pymongo import MongoClient, DESCENDING
import datetime

# from AESCipher import AESCipher
from gridfs import GridFS
from bson import ObjectId
# from src.DAOLayer import decryption

from src.Constants import DBConstants


class mongoReadWrite:
    mongodbName = os.environ.get("MONGO_DB_NAME_GENAI")
    mongodbHost = os.environ.get("MONGO_HOST")
    mongodbPort = os.environ.get("MONGO_PORT")
    mongodbUName = os.environ.get("DB_USERNAME")
    mongodbPwd = os.environ.get("GENAIDB_PASSWORD")

    logger = None

    def validate_iso_date(self, str_val):
        iso_regex = r'^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01]' \
                    r'[0-9]):([0-5][0-9]):([0-5][0-9])(\.[0-9]+)?(Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$'
        match_iso8601 = re.compile(iso_regex).match
        if match_iso8601(str_val) is not None:
            return True
        else:
            return False

    def _connect_mongo(self):
        username = self.mongodbUName
        # password = AESCipher().decrypt_password(self.mongodbPwd)
        password = self.mongodbPwd
        # password = decryption.decrpyt(self.mongodbPwd)
        host = self.mongodbHost
        port = self.mongodbPort
        db = self.mongodbName

        if username and password:
            mongo_uri = 'mongodb://%s:%s@%s:%s/%s' % (username, password, host, port, db)
            conn = MongoClient(mongo_uri)
        else:
            conn = MongoClient(host, port)

        return conn[db]

    # def read_data_executedOn(self, collection_name, limit):
    #     # self.logger.info("inside mongo read")
    #     limit = int(limit)
    #     db = self._connect_mongo()
    #     cursor = db[collection_name].find({}).sort("executedOn", DESCENDING)
    #     df = pd.DataFrame(list(cursor))
    #     del df['_id']
    #
    #     # Convert the "executedOn" column to datetime
    #     df['executedOn'] = pd.to_datetime(df['executedOn'])
    #
    #     # Sort by "executedOn" in descending order
    #     df = df.sort_values(by='executedOn', ascending=False)
    #     # Convert the "executedOn" column back to a string format
    #     df['executedOn'] = df['executedOn'].dt.strftime("%dth %b, %Y %H:%M:%S")
    #
    #     if limit > 0:
    #         return df.head(limit)
    #     else:
    #         return df

    def read_data(self, collection_name, limit):
        limit = int(limit)
        db = self._connect_mongo()
        cursor = db[collection_name].find({})
        df = pd.DataFrame(list(cursor))
        del df['_id']

        if limit > 0:
            return df.head(limit)
        else:
            return df

    def read_data_filter(self, collection_name, filter_condition, limit):
        self.logger.info("inside mongo read")
        limit = int(limit)
        db = self._connect_mongo()
        cursor = db[collection_name].find({})
        df = pd.DataFrame(list(cursor))
        if len(df) > 0:
            del df['_id']
            filters = filter_condition.split("<<>>")
            for filter1 in filters:
                if filter1 != '':
                    next_filter = filter1.split("::")
                    col_name = next_filter[0]
                    operator = next_filter[1]
                    values = next_filter[2]
                    if operator.lower() == "btw":
                        # df['time'] = df[col_name].astype('datetime64[ns]')
                        df['time'] = pd.to_datetime(df[col_name], utc=True)
                        df = df[(df['time'] >= values.split(",")[0]) & (df['time'] <= values.split(",")[1])]
                    elif operator.lower() == "in":
                        df = df[df[col_name].isin(values.split(","))]
                    elif operator.lower() == "eq":
                        df = df[df[col_name] == values]
                    elif operator.lower() == "eqb":
                        if values == 'False':
                            df = df[df[col_name] == False]
                        else:
                            df = df[df[col_name] == True]
                    else:
                        df = df[~df[col_name].isin(values.split(","))]
        if limit > 0:
            return df.head(limit)
        else:
            return df

    def read_data_with_filter(self, collection_name, filter_condition, limit):
        db = self._connect_mongo()
        cursor = db[collection_name].find({})
        df = pd.DataFrame(list(cursor))
        limit = int(limit)
        if len(df) > 0:
            del df['_id']
            filters = filter_condition.split("<<>>")
            for filter1 in filters:
                if filter1 != '':
                    next_filter = filter1.split("::")
                    col_name = next_filter[0]
                    operator = next_filter[1]
                    values = next_filter[2]
                    if col_name == 'isValid':
                        values = True
                    if operator.lower() == "btw":
                        # df['time'] = df[col_name].astype('datetime64[ns]')
                        df['time'] = pd.to_datetime(df[col_name], utc=True)
                        df = df[(df['time'] >= values.split(",")[0]) & (df['time'] <= values.split(",")[1])]
                    elif operator.lower() == "in":
                        df = df[df[col_name].isin(values.split(","))]
                    elif operator.lower() == "eq":
                        df = df[df[col_name] == values]
                    elif operator.lower() == "eqb":
                        if values == 'False':
                            df = df[df[col_name] == False]
                        else:
                            df = df[df[col_name] == True]
                    else:
                        df = df[~df[col_name].isin(values.split(","))]

            if limit > 0:
                return df.head(limit)

        return df

    def read_data_with_filter_with_id(self, collection_name, filter_condition, limit):
        db = self._connect_mongo()
        cursor = db[collection_name].find({})
        df = pd.DataFrame(list(cursor))
        limit = int(limit)
        if len(df) > 0:
            # del df['_id']
            filters = filter_condition.split("<<>>")
            for filter1 in filters:
                if filter1 != '':
                    next_filter = filter1.split("::")
                    col_name = next_filter[0]
                    operator = next_filter[1]
                    values = next_filter[2]
                    if col_name == 'isValid':
                        values = True
                    if operator.lower() == "btw":
                        # df['time'] = df[col_name].astype('datetime64[ns]')
                        df['time'] = pd.to_datetime(df[col_name], utc=True)
                        df = df[(df['time'] >= values.split(",")[0]) & (df['time'] <= values.split(",")[1])]
                    elif operator.lower() == "in":
                        df = df[df[col_name].isin(values.split(","))]
                    elif operator.lower() == "eq":
                        df = df[df[col_name] == values]
                    elif operator.lower() == "eqb":
                        if values == 'False':
                            df = df[df[col_name] == False]
                        else:
                            df = df[df[col_name] == True]
                    else:
                        df = df[~df[col_name].isin(values.split(","))]

            if limit > 0:
                return df.head(limit)

        return df

    def read_data_with_filter_defect_ai_assist(self, collection_name, filter_condition, limit):
        # print(self.mongodbName)
        # print(self.mongodbHost)
        # print(self.mongodbPort)
        # print(self.mongodbUName)
        # print(self.mongodbPwd)
        db = self._connect_mongo()
        cursor = db[collection_name].find({})
        df = pd.DataFrame(list(cursor))
        limit = int(limit)
        if len(df) > 0:
            del df['_id']
            filters = filter_condition.split("<<>>")
            for filter1 in filters:
                if filter1 != '':
                    next_filter = filter1.split("::")
                    col_name = next_filter[0]
                    operator = next_filter[1]
                    values = next_filter[2]
                    if operator.lower() == "btw":
                        # df['time'] = df[col_name].astype('datetime64[ns]')
                        df['time'] = pd.to_datetime(df[col_name], utc=True)
                        df = df[(df['time'] >= values.split(",")[0]) & (df['time'] <= values.split(",")[1])]
                    elif operator.lower() == "in":
                        df = df[df[col_name].isin(values.split(","))]
                    elif operator.lower() == "eq":
                        if col_name != "_id":
                            df = df[df[col_name] == values]
                        else:
                            if not db[collection_name].find_one({"_id": values}) == None:
                                df = pd.DataFrame(db[collection_name].find_one({"_id": values})).groupby(
                                    ['_id']).agg(lambda x: set(x)).applymap(list).reset_index()
                            else:
                                df = pd.DataFrame(db[collection_name].find_one({"_id": values}))
                    elif operator.lower() == "eqb":
                        if values == 'False':
                            df = df[df[col_name] == False]
                        else:
                            df = df[df[col_name] == True]
                    else:
                        df = df[~df[col_name].isin(values.split(","))]

            if limit > 0:
                return df.head(limit)

        return df

    def read_data_with_filter_defect_ai_assist_open(self, collection_name, filter_condition, limit):
        db = self._connect_mongo()
        cursor = db[collection_name].find({})
        df = pd.DataFrame(list(cursor))
        limit = int(limit)
        if len(df) > 0:
            del df['_id']
            filters = filter_condition.split("<<>>")
            for filter1 in filters:
                if filter1 != '':
                    next_filter = filter1.split("::")
                    col_name = next_filter[0]
                    operator = next_filter[1]
                    values = next_filter[2]
                    if operator.lower() == "btw":
                       # df['time'] = df[col_name].astype('datetime64[ns]')
                        df['time'] = pd.to_datetime(df[col_name], utc=True)
                        start_dt = datetime.datetime.strptime(values.split(",")[0].strip()[:19], "%Y-%m-%dT%H:%M:%S")
                        end_dt = datetime.datetime.strptime(values.split(",")[1].strip()[:19], "%Y-%m-%dT%H:%M:%S")
                        start_dt = pd.to_datetime(start_dt, utc=True)
                        end_dt = pd.to_datetime(end_dt, utc=True)
                        df = df[(df['time'] >= start_dt) & (df['time'] <= end_dt)]
                    elif operator.lower() == "in":
                        df = df[df[col_name].isin(values.split(","))]
                    elif operator.lower() == "eq":
                        if col_name != "_id":
                            df = df[df[col_name] == values]
                        else:
                            if not db[collection_name].find_one({"_id": values}) is None:
                                df = pd.DataFrame(db[collection_name].find_one({"_id": values})).groupby(
                                    ['_id', 'modelid']).agg(lambda x: set(x)).applymap(list).reset_index()
                            else:
                                df = pd.DataFrame(db[collection_name].find_one({"_id": values}))
                    elif operator.lower() == "eqb":
                        if values == 'False':
                            df = df[df[col_name] == False]
                        else:
                            df = df[df[col_name] == True]
                    else:
                        df = df[~df[col_name].isin(values.split(","))]

            if limit > 0:
                return df.head(limit)

        return df

    def update_predicteddefect_data(self, collection_name, data_frame, project_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        for data in json_data:
            query = [{"defid": data['defid']}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_data_based_on_two_prim(self, collection_name, data_frame, project_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        for data in json_data:
            query = [{"userStoryID": data['userStoryID']}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_data_based_on_defid(self, collection_name, data_frame, project_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        for data in json_data:
            query = [{"defid": data['defid']}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_new_column(self, new_column_name, collection_name, old_field_values, field_column_name,
                          new_column_values):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]

        updates = [{"$set": {new_column_name: new_column_value}} for old_field_value, new_column_value in
                   zip(old_field_values, new_column_values)]
        for i, update in enumerate(updates):
            db_with_collection.update_many({field_column_name: old_field_values[i]}, update)

    def replace_column(self, collection_name, ids, field_column_name, texts, replace_column_name):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        for doc in db_with_collection.find({field_column_name: {"$in": ids}}):
            index = ids.index(doc[field_column_name])
            db_with_collection.update_one({field_column_name: doc[field_column_name]},
                                          {"$set": {replace_column_name: texts[index]}})

    def write_data(self, collection_name, data_frame):
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records", default_handler=str),
                               object_hook=self.datetime_parser)
        if len(json_data) > 0:
            db = self._connect_mongo()
            db_with_collection = db[collection_name]
            db_with_collection.insert_many(json_data)

    def write_json_data(self, collection_name, json_dump):
        json_data = json.loads(json_dump)
        if len(json_data) > 0:
            db = self._connect_mongo()
            db_with_collection = db[collection_name]
            db_with_collection.insert_many(json_data)

    def write_data_with_id_overwrite(self, collection_name, data_frame, complete_overwrite="NA"):
        """
        This method overwrites the document in DB that has a matching _id field. Under normal insert_many, batch op
        error gets thrown
        :param collection_name:
        :param data_frame:
        :param complete_overwrite: If NA, then only overwrite matching documents, otherwise expect the column name
        and value, separated by comma, against which all the matching entries will be deleted
        :return:
        """
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        if len(json_data) > 0:
            db = self._connect_mongo()
            db_with_collection = db[collection_name]
            if complete_overwrite == "NA":
                for one_json in json_data:
                    db_with_collection.delete_one({'_id': one_json['_id']})
                    db_with_collection.insert_one(one_json)
            else:
                deletion_query = complete_overwrite.split(',')
                # print(deletion_query)
                formed_deletion_query = {deletion_query[0]: deletion_query[1]}
                db_with_collection.delete_many(formed_deletion_query)
                db_with_collection.insert_many(json_data)

    def delete_collection(self, collection_name):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        count = db_with_collection.delete_many({})
        self.logger.info(str(count) + "redords deleted")

    def delete_records(self, collection_name, project_id, model_id, run_id):
        db = self._connect_mongo()
        if collection_name not in db.collection_names():
            return "NA"
        else:
            count = db[collection_name].remove({"projectid": project_id, "modelid": model_id,
                                                "runid": run_id})
        return count

    def write_error_log_data(self, collection_name, json_data, project_id, model_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(json_data)
        json_data = json.loads(data_to_write.to_json(orient="records", default_handler=str),
                               object_hook=self.datetime_parser)
        for data in json_data:
            query = [{"modelid": model_id}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def delete_log_records(self, collection_name, project_id, model_id):
        db = self._connect_mongo()
        if collection_name not in db.collection_names():
            return "NA"
        else:
            count = db[collection_name].remove({"projectid": project_id, "modelid": model_id})
        return count

    def datetime_parser(self, json_dict):
        """
        This function converts iso string present in json to iso date object
        :param json_dict: json data that is to be inserted to mongo
        :return: json with date values converted to datetime
        """
        for (key, value) in json_dict.items():
            try:
                if isinstance(value, str) and self.validate_iso_date(value):
                    json_dict[key] = dateutil.parser.parse(value)
            except (ValueError, AttributeError):
                pass
        return json_dict

    def write_data_update(self, collection_name, output_data_frame):
        datato_write = pd.DataFrame(output_data_frame)
        json_data = json.loads(datato_write.to_json(orient="records", date_format='iso'))
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        for data in json_data:
            db_with_collection.update_one({'_id': data['_id']}, {"$set": data}, upsert=True)

    def read_all_data_comparison(self, collection_name, filter_collection, project_id, model_id):
        db = self._connect_mongo()
        cursor = db[collection_name].find({"projectid": project_id})
        df = pd.DataFrame(list(cursor))
        if filter_collection in db.collection_names():
            if db[filter_collection].count() == 0:
                del df['_id']
                return df
            else:
                query = []
                query.append({"projectid": project_id})
                query.append({"modelid": model_id})
                cursor2 = db[filter_collection].find({'$and': query})
                df2 = pd.DataFrame(list(cursor2))
                if df2.shape[0] == 0:
                    del df['_id']
                    return df
        else:
            del df['_id']
            return df

        df3 = pd.DataFrame()
        for index, values in df.iterrows():
            if values['incidentid'] not in df2['defid'].values:
                df3 = df3.append(values, ignore_index=True)
        if df3.shape[0] == 0:
            return df3
        else:
            del df3['_id']
            return df3

    def read_data_project_filter(self, collection_name, project_id, filter_condition):
        start_date = dateutil.parser.parse(filter_condition[0])
        end_date = dateutil.parser.parse(filter_condition[1])
        query = []
        # print("inside mongo")
        query.append({"projectid": project_id})
        query.append({'incidentreporteddatetime': {'$gte': start_date, '$lte': end_date}})
        db = self._connect_mongo()
        cursor = db[collection_name].find({'$and': query})
        if cursor.count(True) == 0:
            return pd.DataFrame(list(cursor))
        df = pd.DataFrame(list(cursor))
        del df['_id']
        return df

    def update_similar_defects_json(self, collection_name, json_data, project_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        json_data = json.loads(json_data)
        for data in json_data:
            query = [{"defid": data['defid']}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_similar_closed_defects_json(self, collection_name, json_data, project_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        json_data = json.loads(json_data)
        for data in json_data:
            query = [{"defid_closed": data['defid_closed']}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_keywords_json(self, collection_name, json_data, project_id):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        json_data = json.loads(json_data)
        for data in json_data:
            query = [{'_id': data['_id']}, {"defid": data['defid']}, {'projectid': project_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_defects_keywords_json(self, collection_name, json_data, project_id, runid):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        json_data = json.loads(json_data)
        for data in json_data:
            query = [{'text': data['text']}, {'projectid': project_id}, {"runid": runid}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_keywords(self, collection_name, updated_keywords_data_frame, project_id, model_id):
        datato_write = pd.DataFrame(updated_keywords_data_frame)
        datato_write['projectid'] = project_id
        jsonData = json.loads(datato_write.to_json(orient="records", date_format='iso'))
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        for data in jsonData:
            query = [{'text': data['text']}, {'projectid': data['projectid']}, {"modelid": model_id}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_cluster_mapper(self, data):
        # #print("update mapper cluster")
        data_to_write = pd.DataFrame(data, index=[0])
        # #print(data_to_write)
        jsonData = json.loads(data_to_write.to_json(orient="records", date_format='iso'))
        db = self._connect_mongo()
        db_with_collection = db["avmClusterMapper"]

        for data in jsonData:
            query = [{'modelid': data['modelid']}, {'projectid': data['projectid']},
                     {'numericalClusterId': data["numericalClusterId"]}, {'clusterID': data["clusterID"]},
                     {"renamedClusterID": ""}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def update_clusters(self, collection_name, data_frame):
        datato_write = pd.DataFrame(data_frame)
        json_data = json.loads(datato_write.to_json(orient="records", date_format='iso'))
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        for data in json_data:
            query = [{'logMessage': data['logMessage']}, {'projectid': data['projectid']}, {"modelid": data["modelid"]}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def read_data_date(self, incident_category_collection, projectID, date):
        db = self._connect_mongo()
        date = dateutil.parser.parse(date)
        query = []
        query.append({"projectid": projectID})
        query.append({'incidentreporteddatetime': {'$lte': date}})
        cursor = db[incident_category_collection].find({"$and": query})
        df = pd.DataFrame(list(cursor))
        del df['_id']
        return df

    def read_data_model_project_id(self, collection_name, project_id, model_id):
        db = self._connect_mongo()
        cursor = db[collection_name].find({"modelid": model_id, "projectid": project_id})
        df = pd.DataFrame(list(cursor))
        return df

    def read_data_model_project_id_phase(self, collection_name, project_id, model_id, phase):
        db = self._connect_mongo()
        cursor = db[collection_name].find({"runid": model_id, "projectId": project_id, "phase": phase})
        df = pd.DataFrame(list(cursor))
        return df

    def read_all_data_comparison_cluster(self, incident_category_collection, message_logging_collection, project_id,
                                         model_id):
        db = self._connect_mongo()
        cursor = db[incident_category_collection].find({"projectid": project_id})
        df = pd.DataFrame(list(cursor))
        if message_logging_collection in db.collection_names():
            if db[message_logging_collection].count() == 0:
                del df['_id']
                return df
            else:
                query = []
                query.append({"projectid": project_id})
                query.append({"modelid": model_id})
                cursor2 = db[message_logging_collection].find({'$and': query})
                df2 = pd.DataFrame(list(cursor2))
                if df2.shape[0] == 0:
                    del df['_id']
                    return df
        else:
            del df['_id']
            return df

        df3 = pd.DataFrame()
        for index, values in df.iterrows():
            if values['incidentid'] not in df2['logMessage'].values:
                df3 = df3.append(values, ignore_index=True)
        if df3.shape[0] == 0:
            return df3
        else:
            del df3['_id']
            return df3

    def read_data_model_id(self, collection_name, modelID):
        db = self._connect_mongo()
        cursor = db[collection_name].find({"modelid": modelID})
        df = pd.DataFrame(list(cursor))
        return df

    def update_clusters_keywords(self, collection_name, data_frame):
        datato_write = pd.DataFrame(data_frame)
        jsonData = json.loads(datato_write.to_json(orient="records", date_format='iso'))
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        for data in jsonData:
            query = [{'text': data['text']}, {'phase': data['phase']}, {'clusterID': data['clusterID']},
                     {"modelid": data["modelid"]}]
            db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def get_unique_cluster_id(self, cluster_collection, collection_name, model_id, project_id):
        db = self._connect_mongo()
        if collection_name and cluster_collection not in db.collection_names():
            # print("Incident_HI table and cluster Log table is not present is not present and")
            return "NA"
        else:
            cursor = db[cluster_collection].distinct("clusterID", {"modelid": model_id, "projectid": project_id})

        return cursor

    def get_unique_defid(self, collection_name, project_id, model_id, release_list):
        db = self._connect_mongo()
        if collection_name not in db.collection_names():
            return "NA"
        else:
            cursor = db[collection_name].find({"projectid": project_id, "modelid": model_id,
                                               "release": {"$in": release_list}})
        df = pd.DataFrame(list(cursor))
        return df

    def update_clusters_name(self, collection_name, data_frame, data_frame_update):
        datato_write = pd.DataFrame(data_frame)
        json_data = json.loads(datato_write.to_json(orient="records", date_format='iso'))
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        datato_write_update = pd.DataFrame(data_frame_update)
        json_data_update = json.loads(datato_write_update.to_json(orient="records", date_format='iso'))
        # #print(json_data_update)
        # #print(json_data)
        for dataval in json_data_update:
            for data in json_data:
                # #print('data')
                # #print(data)
                query = [{'projectid': data['projectid']}, {"modelid": data["modelid"]}
                    , {"clusterID": data["clusterID"]}]

                db_with_collection.update_many({'$and': query}, {"$set": dataval}, upsert=True)

    def get_incident_ids(self, cluster_collection, cluster_id, model_id, project_id):
        db = self._connect_mongo()

        def extraction(data):
            inci = str(data).split("'")
            return inci[3]

        if cluster_collection not in db.collection_names():
            # print("Cluster collection is empty")
            return "NA"
        else:
            cursor = db[cluster_collection].find(
                {"modelid": model_id, "projectid": project_id, "clusterID": cluster_id}, {"logMessage": 1, "_id": 0})
            inci_ids = [extraction(a) for a in cursor]

        return inci_ids

    def is_sla(self, collection_name, project_id, incident_id):
        db = self._connect_mongo()

        if collection_name not in db.collection_names():
            # print("Collection is not present")
            return "NA"
        else:
            cursor = db[collection_name].find(
                {"incidentid": {"$in": incident_id}, "projectid": project_id, "escalated": "Yes"},
                {"_id": 0, "escalated": 1}).count()

        return cursor

    def read_model_data(self, collectio_name, project_id, model_id):
        # #print("inside mongo read")
        db = self._connect_mongo()
        query = []
        query.append({"projectid": project_id})
        query.append({'modelid': model_id})
        cursor = db[collectio_name].find({"$and": query})
        df = pd.DataFrame(list(cursor))
        # del df['_id']
        return df

    def read_model_data_runid(self, collection_name, project_id, run_id):
        db = self._connect_mongo()
        query = []
        query.append({"projectid": project_id})
        query.append({'runid': run_id})
        cursor = db[collection_name].find({"$and": query})
        df = pd.DataFrame(list(cursor))
        return df

    def read_model_data_limit(self, collectio_name, project_id, model_id, limit=-1):
        # #print("inside mongo read")
        db = self._connect_mongo()
        query = []
        query.append({"projectid": project_id})
        query.append({'modelid': model_id})
        cursor = db[collectio_name].find({"$and": query})
        df = pd.DataFrame(list(cursor))
        # del df['_id']
        if limit > 0:
            return df.head(limit)
        else:
            return df

    def save_video_data_on_fs(self, collection_name, file_id):
        video_save_path = os.environ.get("TRIAGE_MODEL").replace("\\", "/") + "/videoqualityanalyzer/" + file_id + "/"
        os.makedirs(video_save_path, exist_ok=os.path.exists(video_save_path))
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)
        fs.list()
        grid_out = fs.get(file_id=ObjectId(file_id))
        video_save_path_name = video_save_path + grid_out.filename.replace(" ", "_")
        data = grid_out.read()
        out = open(video_save_path_name, 'wb')
        out.write(data)
        out.close()
        return video_save_path, video_save_path_name

    # def save_images_on_db(self, collection_name, video_save_path, ref_id, input_param):
    #     # collection_name = "videoFrames"
    #     # get list of all images:
    #     get_image_list = glob.glob(video_save_path + "/*.jpg")
    #     db = self._connect_mongo()
    #     fs = GridFS(db, collection=collection_name)
    #     get_list_of_id_of_uploaded_images = []
    #     for image_file in get_image_list:
    #         index_to_get_image_name = os.path.split(image_file).__len__() - 1
    #         image_file_name = os.path.split(image_file)[index_to_get_image_name]
    #         file_id = fs.put(open(image_file, 'rb'), filename=image_file_name,
    #                          metadata={'videoFileId': input_param['fileId'],
    #                                    'videoFileName': input_param['videoFileName'],
    #                                    'projectid': input_param['projectid']})
    #         out = fs.get(file_id)
    #         get_list_of_id_of_uploaded_images.append(file_id)
    #
    #     analysis_result = {"imageids": get_list_of_id_of_uploaded_images,
    #                        "videoFileId": input_param['fileId'],
    #                        "videoFileName": input_param['videoFileName'],
    #                        "projectid": input_param['projectid']}
    #
    #     query = [{"videoFileId": analysis_result['videoFileId']}, {'projectid': input_param['projectid']}]
    #     db = self._connect_mongo()
    #     video_frame_upload_info = CollectionNames.VIDEO_QA_FRAMES_UPLOAD_INFO
    #     db_with_collection = db[video_frame_upload_info]
    #     db_with_collection.update_one({'$and': query}, {"$set": analysis_result}, upsert=True)

    def write_data_video_live(self, collection_name, json_dump, iteration):
        client = self._connect_mongo()
        video_process_live = client[collection_name]
        if iteration > 1:
            query = [{"videoName": json_dump['videoName']}, {'projectid': json_dump['projectid']}]

            data = video_process_live.find_one({'$and': query})
            data["refID"].append(json_dump['refID'])

            video_process_live.update_one({'$and': query}, {"$set": data}, upsert=True)
            return

        else:
            json_dump["refID"] = [json_dump["refID"]]
            video_process_live.insert_one(json_dump)
            return

    def write_data_video(self, collection_name, json_dump, firstRefID=None, iteration=0, live=False,
                         is_status_update=False, yetToCreate=False, completed=False):
        client = self._connect_mongo()
        video_process = client[collection_name]
        # this is for the video url approach to track the download.
        query2 = [{"refID": 'YetToCreate'}, {"status": "Downloading"}, {'projectid': json_dump['projectid']}]
        if yetToCreate:
            data = video_process.find_one({'$and': query2})
            data["status"] = "In Progress"
            video_process.update_one({'$and': query2}, {"$set": data}, upsert=True)
            return
        query = [{"refID": json_dump['refID']}, {'projectid': json_dump['projectid']}]
        if completed:
            data = video_process.find_one({'$and': query})
            data["status"] = "Completed"
            video_process.update_one({'$and': query}, {"$set": data}, upsert=True)
            return
        if not live:
            if not is_status_update:
                already_added = video_process.find_one({'$and': query})
                if already_added is None:
                    url_added = video_process.find_one({'$and': query2})
                    if url_added is None:
                        video_process.update_one({'$and': query}, {"$set": json_dump}, upsert=True)
                    else:
                        video_process.update_one({'$and': query2}, {'$set': json_dump}, upsert=True)
            else:
                video_process.update_one({'$and': query}, {
                    '$set': {'status': json_dump['status'], 'errorMessage': json_dump['ErrorMessage']}}, upsert=True)
        elif live == True and iteration == 1:
            query3 = [{"refID": 'YetToCreate'}, {"status": "In Progress"}, {'projectid': json_dump['projectid']}]
            video_process.update_one({'$and': query3}, {
                '$set': {'refID': firstRefID, 'errorMessage': ''}}, upsert=True)
        elif live == True and iteration > 1:
            query = [{"refID": firstRefID}, {'projectid': json_dump['projectid']}]
            video_process.update_one({'$and': query}, {"$set": json_dump}, upsert=True)
        print('write completed')

    def write_data_metavideo(self, collection_name, json_dump, firstRefID=None):
        client = self._connect_mongo()
        video_metadata = client[collection_name]
        query = [{"refID": firstRefID}, {'projectid': json_dump['projectid']}]
        data = video_metadata.find_one({'$and': query})
        for i in json_dump["scores"]:
            data["scores"].append(i)
        if not json_dump["screenanalysis"] == "":
            if not data["screenanalysis"] == "":
                for i in json_dump["screenanalysis"]:
                    data["screenanalysis"].append(i)
            else:
                data["screenanalysis"] = json_dump["screenanalysis"]
        video_metadata.update_one({'$and': query}, {"$set": data}, upsert=True)

    def write_audio_data_video(self, collection_name, json_dump, duration, iteration):
        client = self._connect_mongo()
        audio_analysis = client[collection_name]
        query = [{"refID": json_dump["refID"]}, {'projectid': json_dump['projectid']}]
        data = audio_analysis.find_one({'$and': query})
        if len(json_dump["muteSections"]) > 0:
            for i in json_dump["muteSections"]:
                i["startTime"] = i["startTime"] + (10 * (iteration - 1))
                i["endTime"] = i["endTime"] + (10 * (iteration - 1))
                data["muteSections"].append(i)
        data["muteDuration"] = data["muteDuration"] + json_dump["muteDuration"]
        if not data["muteDuration"] == 0:
            data["muteDurationPercent"] = data["muteDuration"] / duration
        audio_analysis.update_one({'$and': query}, {"$set": data}, upsert=True)

    def find_data_video(self, collection_name, json_dump):
        client = self._connect_mongo()
        video_process = client[collection_name]
        get_one = video_process.find_one(json_dump)
        return get_one

    def read_defects_with_same_module(self, collection_name, open_defect, matched_defect, project_id):
        db = self._connect_mongo()
        query1 = []
        query1.append({"projectid": project_id})
        query1.append({"defid": open_defect})
        cursor = db[collection_name].find({'$and': query1})
        df_open_defect = pd.DataFrame(list(cursor))
        query2 = []
        query2.append({"projectid": project_id})
        query2.append({"defid": matched_defect})
        cursor2 = db[collection_name].find({'$and': query2})
        df_matched_defect = pd.DataFrame(list(cursor2))
        if df_open_defect['module'].equals(df_matched_defect['module']):
            return df_matched_defect['assignedTo'].tolist()[0]
        else:
            df_matched_defect['assignedTo'] = ""
            return df_matched_defect['assignedTo'].tolist()[0]

    def save_video_data_in_db(self, collection_name, video_file_path_with_name, input_param):
        file_name_by_url_if_used = input_param['videoFileName']
        if not input_param['videoFileName'].endswith(".mp4"):
            file_name_by_url_if_used = file_name_by_url_if_used + ".mp4"
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)
        file_id = fs.put(open(video_file_path_with_name, 'rb'), filename=file_name_by_url_if_used,
                         uploadedFilename=file_name_by_url_if_used, projectid=input_param['projectid'],
                         uploadedFileDescription=input_param['videoFileDesc'])
        return str(file_id)

    def write_cj_data(self, collection_name, json_dump):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(json_dump)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        for data in json_data:
            query = [{"modelid": data['modelid']}, {'projectid': data['projectid']}]
            already_added = db_with_collection.find_one({'$and': query})
            if already_added is None:
                db_with_collection.insert_many(json_dump)
                return
            else:
                db_with_collection.update_one({'$and': query}, {"$set": data}, upsert=True)

    def save_weights_on_fs(self, collection_name, file_dir, file_name):
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)
        fs.list()
        grid_out = fs.find_one({"filename": file_name})
        data = grid_out.read()
        out = open(file_dir, 'wb')
        out.write(data)
        out.close()

    def read_dt_data(self, collectio_name, project_id):
        # #print("inside mongo read")
        db = self._connect_mongo()
        query = []
        query.append({"projectid": project_id})
        cursor = db[collectio_name].find({"$and": query})
        df = pd.DataFrame(list(cursor))
        # del df['_id']
        return df

    def read_data_model_project_id_run_id_phase(self, collection_name, project_id, model_id, run_id, phase):
        db = self._connect_mongo()
        cursor = db[collection_name].find(
            {"runid": model_id, "projectId": project_id, "runidBiz": run_id, "phase": phase})
        df = pd.DataFrame(list(cursor))
        return df

    def delete_records_jobid(self, collection_name, project_id, model_id, run_id, phase, job_id):
        db = self._connect_mongo()
        if collection_name not in db.collection_names():
            return "NA"
        else:
            count = db[collection_name].remove(
                {"runid": model_id, "projectId": project_id, "runidBiz": run_id, "phase": phase, "jobID": job_id})
        return count

    def update_data_based_on_runid(self, collection_name, data_frame, runID):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        query = {'runID': runID}
        for data in json_data:
            db_with_collection.update_one(query, {"$set": data}, upsert=False)

    def update_data_based_on_time(self, collection_name, data_frame, time):
        db = self._connect_mongo()
        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        query = {'executedOn': time}
        for data in json_data:
            db_with_collection.update_one(query, {"$set": data}, upsert=False)

    def update_data_based_on_jobid(self, collection_name, data_frame, jobid):
        db = self._connect_mongo()
        try:
            db_with_collection = db[collection_name]
        except:
            self.write_data(collection_name, data_frame)

        db_with_collection = db[collection_name]
        data_to_write = pd.DataFrame(data_frame)
        json_data = json.loads(data_to_write.to_json(orient="records"), object_hook=self.datetime_parser)
        query = {'jobID': jobid}
        for data in json_data:
            db_with_collection.update_one(query, {"$set": data}, upsert=False)

    def delete_item_based_on_jobID(self, summary_collection_name, result_collection_name, jobID):
        db = self._connect_mongo()
        db_with_collection = db[summary_collection_name]
        result = db_with_collection.delete_one({"jobID": jobID})

        # Delete result file from db
        try:
            db_with_collection = db[result_collection_name]
            db_with_collection.delete_many({"jobID": jobID})
        except:
            fs = GridFS(db, collection=result_collection_name)
            file_info = fs.find_one({'metadata.jobID': jobID})
            if file_info:
                fs.delete(file_info._id)
                print(f"File '{file_info.filename}' deleted successfully.")
            else:
                print("No matching file found for deletion.")

        return result.deleted_count

    def store_file_in_mongodb(self, collection_name, file_content, file_name, content_type):
        # Connect to MongoDB
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)

        # Find and delete existing document with the same filename
        existing_file = fs.find_one({"filename": file_name})
        if existing_file:
            fs.delete(existing_file._id)


        # Store the file in GridFS
        with fs.new_file(filename=file_name, content_type=content_type) as grid_file:
            grid_file.write(file_content)

    def store_additional_context_in_mongodb(self, collection_name, file_content, file_name, content_type, project_id):
        # Connect to MongoDB
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)

        # Find and delete existing document with the same filename
        existing_file = fs.find_one({"filename": file_name, "metadata.ProjectID": project_id})
        if existing_file:
            fs.delete(existing_file._id)

        # Store the file in GridFS with ProjectID in metadata
        with fs.new_file(filename=file_name, content_type=content_type,
                         metadata={"ProjectID": project_id}) as grid_file:
            grid_file.write(file_content)

    def read_filecontent_from_gridfs(self, collection_name, file_name):
        # Connect to MongoDB
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)

        try:
            # Read the file from GridFS by filename
            grid_file = fs.find_one({"filename": file_name})

            # Attempt to read the content of the file
            file_content = grid_file.read()
            return file_content

        except Exception as e:
            # Handle exceptions, such as file not found or general errors
            print(f"Error reading file from GridFS: {e}")
            return None

    def store_zip_in_mongodb(self, collection_name, zip_file_name, jobID):
        # Connect to MongoDB
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)

        # # Find and delete existing document with the same filename
        # existing_file = fs.find_one({"filename": zip_file_name})
        # if existing_file:
        #     fs.delete(existing_file._id)

        # Open the ZIP file and store it in MongoDB
        with open(zip_file_name, 'rb') as zip_file:
            fs.put(zip_file, filename=os.path.basename(zip_file_name), metadata={'jobID': jobID})

    def read_zip_from_gridfs(self,  collection_name, jobID):
        # Connect to MongoDB
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)

        # Find the ZIP file by jobID
        zip_file = fs.find_one({'metadata.jobID': jobID})
        return zip_file

    def read_file_from_gridfs(self, filename):
        # Connect to MongoDB
        db = self._connect_mongo()
        fs = GridFS(db, collection="Files")

        # Find the ZIP file by jobID
        file = fs.find_one({'filename': filename})
        return file

    def read_additional_context(self, projectID, collection_name):
        db = self._connect_mongo()
        fs = GridFS(db, collection=collection_name)

        # Find the ZIP file by projectID
        cursor = fs.find({'metadata.ProjectID': projectID})
        files = []
        for file in cursor:
            file_content = file.read()
            try:
                df = pd.read_csv(io.BytesIO(file_content))
            except:
                df = pd.read_excel(io.BytesIO(file_content))
            files.append(df)

        return files
