import os
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hmac
from cryptography.hazmat.primitives import constant_time


class FileDecryptor:
    def decrypt_file(self, input_path, filename, private_key_path, encryption_key_path):
        """
        Decrypt files in the specified input directory using the provided private key and encryption key.

        Args:
            input_path (str): The path to the directory containing the encrypted files.
            private_key_path (str): The path to the private key file used for decryption.
            encryption_key_path (str): The path to the encryption key file used for encryption.

        This function performs the following steps:
        - Reads the encryption key from the specified file.
        - Loads the private key from the specified file.
         - Iterates over files in the input directory.
        - Reads and parses the combined data from each file.
        - Computes the HMAC over encrypted key, IV, and ciphertext.
        - Compares computed HMAC with the received HMAC for data integrity.
        - Decrypts the symmetric key using the private key.
        - Decrypts the data using the decrypted symmetric key and IV.

        """
        private_key = self.load_private_key(private_key_path, encryption_key_path)

        # for filename in os.listdir(input_path):
        if os.path.isfile(os.path.join(input_path, filename)):
            file_path = os.path.join(input_path, filename)

            (
                combined_data,
                encrypted_symmetric_key,
                iv,
                ciphertext,
                mac,
            ) = self.read_combined_data(file_path)

            # Compute HMAC over encrypted key, IV, and ciphertext
            hmac_key = os.urandom(32)
            hmac_calculator = hmac.HMAC(hmac_key, hashes.SHA256(), backend=default_backend())
            hmac_calculator.update(encrypted_symmetric_key)
            hmac_calculator.update(iv)
            hmac_calculator.update(ciphertext)
            computed_mac = hmac_calculator.finalize()

            # Compare computed HMAC with received HMAC to ensure data integrity
            if not self.secure_compare(mac, computed_mac):
                print(f"File {filename} has been tampered with!")

            decrypted_symmetric_key = self.decrypt_symmetric_key(
                private_key, encrypted_symmetric_key
            )

            decrypted_data = self.decrypt_data(
                decrypted_symmetric_key, iv, ciphertext
            )

            return decrypted_data

        print("Decryption completed.")

    def load_private_key(self, private_key_path, encryption_key_data):
        """
        Load the private key from the specified file and decrypt it.

         Args:
            private_key_path (str): The path to the private key file.
            encryption_key_data (bytes): The encryption key used to decrypt the private key.

        Returns:
            cryptography.hazmat.backends.openssl.rsa._RSAPrivateKey: The decrypted private key.
        """
        private_key = serialization.load_pem_private_key(
            private_key_path,
            password=encryption_key_data,
            backend=default_backend(),
            )
        return private_key

    def read_combined_data(self, file_path):
        """
        Read and parse the combined data from the specified file.

        Args:
            file_path (str): The path to the file containing combined data.

        Returns:
            Tuple[bytes, bytes, bytes, bytes, bytes]: A tuple containing combined data, encrypted symmetric key,
            IV (Initialization Vector), ciphertext, and HMAC.
        """
        with open(file_path, "rb") as file:
            combined_data = file.read()
            encrypted_symmetric_key = combined_data[:256]
            iv = combined_data[256:272]
            ciphertext = combined_data[272:-32]
            mac = combined_data[-64:-32]
            session = combined_data[-32:]
            return combined_data, encrypted_symmetric_key, iv, ciphertext, mac

    def secure_compare(self, val1, val2):
        """
        Compare two values in constant time to prevent timing attacks.

        Args:
            val1 (bytes): The first value for comparison.
            val2 (bytes): The second value for comparison.

        Returns:
            bool: True if the values are equal, False otherwise.
        """
        return constant_time.bytes_eq(val1, val2)

    def decrypt_symmetric_key(self, private_key, encrypted_symmetric_key):
        """
        Decrypt the encrypted symmetric key using the private key.

        Args:
            private_key (cryptography.hazmat.backends.openssl.rsa._RSAPrivateKey): The private key used for decryption.
            encrypted_symmetric_key (bytes): The encrypted symmetric key to be decrypted.

        Returns:
            bytes: The decrypted symmetric key.
        """
        return private_key.decrypt(
            encrypted_symmetric_key,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )

    def decrypt_data(self, decrypted_symmetric_key, iv, ciphertext):
        """
        Decrypt the data using the decrypted symmetric key and IV.

        Args:
            decrypted_symmetric_key (bytes): The decrypted symmetric key.
            iv (bytes): The Initialization Vector.
            ciphertext (bytes): The encrypted data to be decrypted.

        Returns:
            bytes: The decrypted data.
        """
        cipher = Cipher(
            algorithms.AES(decrypted_symmetric_key),
            modes.CFB(iv),
            backend=default_backend(),
        )
        decryptor = cipher.decryptor()
        return decryptor.update(ciphertext) + decryptor.finalize()
