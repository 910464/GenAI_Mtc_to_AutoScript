import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend

from src.DAOLayer.MongoReadWrite import mongoReadWrite
from src.EncryptionLayer.PromptEncryption import PromptEncryption  # Import the Encryptor class from your encryption script

mongo_obj = mongoReadWrite()

class PromptDecryption:
    def __init__(self):
        self.password = os.environ.get('PROMPT_ENCRYPTOR_PASS')
        self.salt = base64.urlsafe_b64decode(os.environ.get('PROMPT_SALT'))
        self.key = self.create_key_from_password()

    def create_key_from_password(self):
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=self.salt,
            iterations=100000,
            backend=default_backend()
        )
        return base64.urlsafe_b64encode(kdf.derive(self.password.encode()))

    def decrypt_message(self, encrypted_message: str):
        fernet = Fernet(self.key)
        return fernet.decrypt(encrypted_message.encode()).decode()

    def load_and_decrypt_from_mongodb(self, collection_name, prompt_id, prompts_instance, encryptor):
        document = mongo_obj.load_prompt_from_mongodb(collection_name, prompt_id)
        if document:
            return self.decrypt_message(document['encrypted_prompt'])
        else:
            encrypted_prompts = {}
            prompt_value = getattr(prompts_instance, prompt_id, None)
            if prompt_value:
                encrypted_prompt = encryptor.encrypt_message(prompt_value)
                encrypted_prompts[prompt_id] = encrypted_prompt
                mongo_obj.save_prompt_to_mongodb(encrypted_prompts, collection_name)
                document = mongo_obj.load_prompt_from_mongodb(collection_name, prompt_id)
                return self.decrypt_message(document['encrypted_prompt'])
            else:
                return None

    def decrypt_prompt(self, label_to_decrypt, prompts_instance):
        try:
            if not self.password or not self.salt:
                raise EnvironmentError("Required environment variables are not set.")

            encryptor = PromptEncryption()
            decryptor = PromptDecryption()

            decrypted_prompt = decryptor.load_and_decrypt_from_mongodb('prompts', label_to_decrypt, prompts_instance, encryptor)

            if decrypted_prompt:
                original_prompt = getattr(prompts_instance, label_to_decrypt, None)
                if original_prompt and original_prompt != decrypted_prompt:
                    encrypted_prompt = encryptor.encrypt_message(original_prompt)
                    mongo_obj.save_prompt_to_mongodb(encrypted_prompt, 'prompts')
                    print(f"Updated MongoDB with new version of Newly encrypted {label_to_decrypt}")
                    decrypted_prompt = decryptor.load_and_decrypt_from_mongodb('prompts', label_to_decrypt,
                                                                               prompts_instance, encryptor)
                    return decrypted_prompt
                else:
                    return decrypted_prompt
            else:
                print(f"Reference prompt {label_to_decrypt} is not available in both locations.")

        except ValueError as e:
            print(e)
        except FileNotFoundError as fnf_error:
            print(fnf_error)
        except EnvironmentError as env_error:
            print(env_error)
        except Exception as general_error:
            print(f"An unexpected error occurred: {general_error}")
