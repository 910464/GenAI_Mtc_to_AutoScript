import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend

class PromptEncryption:
    def __init__(self):
        self.password = os.environ.get('PROMPT_ENCRYPTOR_PASS')
        self.salt = base64.urlsafe_b64decode(os.environ.get('PROMPT_SALT'))
        self.key = self.create_key_from_password()

    def create_key_from_password(self):
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=self.salt,
            iterations=100000,
            backend=default_backend()
        )
        return base64.urlsafe_b64encode(kdf.derive(self.password.encode()))

    def encrypt_message(self, message: str):
        fernet = Fernet(self.key)
        return fernet.encrypt(message.encode()).decode()

    def encrypt_prompts_object(self, prompts_object):
        encrypted_prompts = {}
        for attr in dir(prompts_object):
            if attr.startswith('__'):
                continue

            value = getattr(prompts_object, attr)
            if isinstance(value, str):
                encrypted_prompt = self.encrypt_message(value)
                encrypted_prompts[attr] = encrypted_prompt
        return encrypted_prompts
