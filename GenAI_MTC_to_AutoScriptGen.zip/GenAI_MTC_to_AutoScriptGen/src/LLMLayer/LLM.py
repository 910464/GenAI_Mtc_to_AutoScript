from langchain.chat_models import AzureChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain import LLMChain

from src.Utilities.config import OPENAI_API_KEY, \
    OPENAI_API_BASE, OPENAI_API_VERSION, OPENAI_API_KEY_4, OPENAI_API_BASE_4, OPENAI_API_VERSION_4, DEPLOYMENT_NAME, \
    TEMPERATURE, DEPLOYMENT_NAME_4


class LLM:

    def send_request(self, input_param, template_prompt, input_variables, input_variables_dict):

        prompt = PromptTemplate(
            input_variables=input_variables,
            template=template_prompt)

        if input_param['model_name'] == "gpt-35-turbo":
            qa_prompt = LLMChain(
                llm=AzureChatOpenAI(deployment_name=DEPLOYMENT_NAME, model_name="gpt-35-turbo", temperature=TEMPERATURE,
                                    openai_api_key=OPENAI_API_KEY,
                                    openai_api_base=OPENAI_API_BASE,
                                    openai_api_version=OPENAI_API_VERSION),
                prompt=prompt)

        elif input_param['model_name'] == "gpt-4-32k":
            qa_prompt = LLMChain(
                llm=AzureChatOpenAI(deployment_name=DEPLOYMENT_NAME_4, model_name="gpt-4-32k", temperature=TEMPERATURE,
                                    openai_api_key=OPENAI_API_KEY_4,
                                    openai_api_base=OPENAI_API_BASE_4,
                                    openai_api_version=OPENAI_API_VERSION_4),
                prompt=prompt, verbose=False)

        output_qa_prompt = qa_prompt.run(input_variables_dict)

        return output_qa_prompt

