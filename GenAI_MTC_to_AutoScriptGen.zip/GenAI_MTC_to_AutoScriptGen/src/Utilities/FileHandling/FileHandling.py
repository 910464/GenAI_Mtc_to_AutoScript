import os
import zipfile
import io


def create_zip(source_folder, zip_file_name):

    with zipfile.ZipFile(zip_file_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(source_folder):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_folder)
                zipf.write(file_path, arcname=arcname)

def write_code_to_file(content, base_dir, file_dir, file_name):

    # Create the full directory path
    full_dir = os.path.join(base_dir, file_dir)

    # Check if the directory exists, and if not, create it
    if not os.path.exists(full_dir):
        os.makedirs(full_dir)

    # Create the full file path
    full_path = os.path.join(full_dir, file_name)

    # Write the content to the file
    with open(full_path, "w") as file:
        file.write(content)


def create_zip_archive(files_data):
    zip_buffer = io.BytesIO()

    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
        for filename, file_content in files_data:
            zipf.writestr(filename, file_content)

    zip_buffer.seek(0)  # Reset the buffer position to the beginning
    return zip_buffer
