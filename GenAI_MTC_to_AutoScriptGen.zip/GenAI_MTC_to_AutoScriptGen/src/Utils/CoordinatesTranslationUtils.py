# Function to get the Web coordinates from Box Coordinates
from src.Utils.BoundingboxUtils import calculate_iou, calculate_myiou
from selenium.webdriver.common.by import By


def get_web_coordinates(result, i, x):  # i=screenshot no, x = height of each screenshot
    boxes = result[0].boxes.data
    class_names = result[0].names

    image_height, image_width = result[0].orig_shape

    refined_coordinates = []
    for box in boxes:
        x1, y1, x2, y2, confidence, class_id = box.tolist()[:6]  # Extracting the first 6 elements

        y1, y2 = y1 + x * i, y2 + x * i
        # Printing the coordinates and class name
        print("Box coordinates:", x1, y1, x2, y2)
        print("Class name:", class_names[class_id])  # class_name
        print()
        refined_coordinates.append([x1, y1, x2, y2, confidence, class_names[class_id]])

    refined_coordinates.sort(key=lambda k: k[4])
    return refined_coordinates


# Function for Getting the coordinates of all the elements on the driver window
def get_web_elements_coordinates(elements):
    bounding_boxes = []

    # Iterate over all the elements
    for element in elements:
        # Get the element's position
        position = element.rect

        if position['height'] + position['width'] + position['x'] + position['y'] != 0:
            bounding_boxes.append([element, [position['x'], position['y'], position['x'] + position['width'],
                                             position['y'] + position['height']]])

    return bounding_boxes


# Finding the element from bounding box
def get_closest_element(driver, bbox):
    elements = driver.find_elements(By.CSS_SELECTOR, '*')
    element_bounding_boxes = get_web_elements_coordinates(elements)
    closest_match = [0, 0, 0]
    for j in element_bounding_boxes:
        val = calculate_iou(bbox, j[1])
        if val > closest_match[1]:
            closest_match[0] = j[0]
            closest_match[1] = val
            closest_match[2] = j[1]

    if type(closest_match[-1]) is list and closest_match[1] > 0.98:
        return closest_match
    else:
        return []


def find_closest_matching_blocks(refined_predicted_coordinates, element_bounding_boxes):
    refined_coordinates_with_elements = []
    for i in refined_predicted_coordinates:
        closest_match = [0, 0, 0, 0]
        for j in element_bounding_boxes:
            intersection_area, box1_area, box2_area = calculate_myiou(i[:4], j[1])
            if intersection_area > closest_match[1]:
                closest_match[0] = j[0]
                closest_match[1] = intersection_area
                closest_match[2] = j[1]
                closest_match[3] = box2_area
            if intersection_area == closest_match[1]:
                print("Intersection Area : ", intersection_area, "Box2 Area : ", box2_area, "prev_box_area : ",
                      closest_match[3])
                if box2_area < closest_match[3]:
                    closest_match[0] = j[0]
                    closest_match[1] = intersection_area
                    closest_match[2] = j[1]
                    closest_match[3] = box2_area

        if type(closest_match[-2]) is list:
            refined_coordinates_with_elements.append(i + closest_match[:3])
    return refined_coordinates_with_elements


# Function to find the closest Element from the predicted coordinates
def get_closest_match_element(refined_predicted_coordinates, element_bounding_boxes, metric=None):
    refined_coordinates_with_elements = []
    for i in refined_predicted_coordinates:
        closest_match = [0, 0, 0]
        for j in element_bounding_boxes:
            val = calculate_iou(i[:4], j[1])
            if val > closest_match[1]:
                closest_match[0] = j[0]
                closest_match[1] = val
                closest_match[2] = j[1]

        if type(closest_match[-1]) is list:
            refined_coordinates_with_elements.append(i + closest_match)
        print(closest_match[1])
    return refined_coordinates_with_elements


def convert_to_prompt_dict(results):
    for block in results:
        results[block]['children'] = sorted(results[block]['children'], key=lambda x: x[0])
        for i in range(len(results[block]['children'])):
            d = {}
            try:
                d['id'] = results[block]['children'][i][1].get_attribute("id")
            except:
                pass
            try:
                d['type'] = results[block]['children'][i][1].get_attribute("type")
            except:
                pass
            try:
                d['class'] = results[block]['children'][i][1].get_attribute("class")
            except:
                pass
            try:
                d['text'] = results[block]['children'][i][1].get_attribute("text")
            except:
                pass
            try:
                # Auto Correct Predicted Classes
                d['tagName'] = results[block]['children'][i][1].get_attribute("tagName")
                if d['tagName'] == 'INPUT':
                    results[block]['children'][i][0] = "field"
                elif d['tagName'] == 'BUTTON':
                    results[block]['children'][i][0] = "button"
                elif d['tagName'] == 'A':
                    results[block]['children'][i][0] = "link"
                elif d['tagName'] == 'IMAGE':
                    results[block]['children'][i][0] = "image"
                else:
                    pass

            except:
                pass

            results[block]['children'][i][1] = d

        # Handling Duplicates
        unique_set = set(str(lst) for lst in results[block]['children'])
        unique_list = [eval(tpl) for tpl in unique_set]
        results[block]['children'] = sorted(unique_list, key=lambda x: x[0])
    return results
