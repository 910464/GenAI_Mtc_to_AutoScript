from ultralytics import YOLO
from PIL import Image
from src.Utils.CoordinatesTranslationUtils import get_web_coordinates
import cv2
import os

# Importing the YOLO Model
os.chdir('..')
project_dir = os.getcwd()
model_path = os.path.join(project_dir, 'PretrainedModels', 'web_detection_yolov8_e50s500Aug.pt')
block_model_path = os.path.join(project_dir, 'PretrainedModels', 'FuncBlock_detection_Yv8_e100s500Aug.pt')

model = YOLO(model_path)  # Getting the YOLO Object
confidence = 0.1  # Setting Confidence Threshold


# Function to get the predicted Results
def get_predicted_results(screenshot_splits, x, screenshot_splits_path, modelx=None, confid=None):
    if modelx is None:
        pass
    else:
        model = modelx
        confidence = confid

    # Iteratively Predicting with YOLO
    predicted_results = []
    predicted_images = []
    if type(screenshot_splits) != list:
        result = model.predict(screenshot_splits, conf=confidence)
        web_coordinates = get_web_coordinates(result, 0, x)  # Translating yolo coordinates to Web coordinates
        predicted_results.append([0, result, web_coordinates])

        ## Append Image
        image_data = result[0].plot()
        image_data_rgb = cv2.cvtColor(image_data, cv2.COLOR_BGR2RGB)
        predicted_images.append(Image.fromarray(image_data_rgb))
    else:
        for i, img in enumerate(screenshot_splits):
            result = model.predict(img, conf=confidence)
            web_coordinates = get_web_coordinates(result, i, x)
            predicted_results.append([i, result, web_coordinates])

            ## Append Image
            image_data = result[0].plot()
            image_data_rgb = cv2.cvtColor(image_data, cv2.COLOR_BGR2RGB)
            predicted_images.append(Image.fromarray(image_data_rgb))

    # Saving Detection Splits
    detection_splits_path = screenshot_splits_path + '/detection_splits'
    os.mkdir(detection_splits_path)
    for i, image in enumerate(predicted_images):
        image.save(f"{detection_splits_path}/detection_split_{i}.png")

    class_names = predicted_results[0][1][0].names
    return predicted_results, class_names


# Function to get the refined coordinates from the predicted results
def get_refined_coordinates(predicted_results):
    # Extracting the coordinates from predicted results
    refined_coordinates = []
    for i in predicted_results:
        if len(i[2]):
            refined_coordinates = refined_coordinates + i[2]
    return refined_coordinates
