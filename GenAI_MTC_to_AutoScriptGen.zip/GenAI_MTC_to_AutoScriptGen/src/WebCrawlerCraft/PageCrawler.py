from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from termcolor import colored
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup


def perform_action_accordingly(driver, page_soup, row):
    action = row["action"]
    object = row["object"]
    data = row["data"]
    if action == "enter":
        print("Enter some data in text box")
        input_fields = page_soup.findAll("input")
        print("debug")
    elif action == "select":
        print("Choose some data")
    elif action == "click":
        print("Click something")


class PageCrawler(object):

    def crawl_page(self, config_data_frame, root_url):
        driver = webdriver.Chrome(ChromeDriverManager().install())
        try:
            driver.get(root_url)
            # Wait for the page to fully load
            driver.execute_script("return document.readyState == 'complete';")
            # Parse the HTML content of the page using BeautifulSoup
            soup = BeautifulSoup(driver.page_source, 'html.parser')

        except WebDriverException:
            print(colored(
                "Check if the page has loaded. If not, Please sign in once manually, close the browser "
                "and rerun the program", "red"))
        page_soup = BeautifulSoup(driver.page_source, 'html.parser', from_encoding='utf-8')
        for index, row in config_data_frame.iterrows():
            perform_action_accordingly(driver, page_soup, row)
            page_soup = BeautifulSoup(driver.page_source, 'html.parser', from_encoding='utf-8')
