import os
import time
import json
import csv
import datetime
import validators
import pandas as pd
from bs4 import BeautifulSoup
from lxml import etree
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import re
from urllib.parse import urlparse
from src.Utils.XpathBuilder import XpathBuilder
from src.WireframeProcess.FunctionalBlockDetection import FunctionalBlockDetection
from src.WireframeProcess.ResultsTestcases import ResultsTestcases
#from src.WireframeProcess.AzureConnect import AzureConnect
from src.Utils.CoordinatesTranslationUtils import convert_to_prompt_dict
from src.Utils.SavingOutputUtils import create_folder



class WebPageCrawlerCraft:
    def __init__(self, url, excel_file):
        # not needed for craft
        self.url = url
        self.excel_file = excel_file
        self.driver = None

    def store_data(self, filename, data):
        with open(filename, 'w') as file:
            file.write(str(data))

    def start(self, browser_type='chrome', headless=False):
        if browser_type == 'chrome':
            # Launch the Chrome browser using Chromedriver
            chrome_options = ChromeOptions()
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("window-size=1200,1100")
            if headless:
                chrome_options.add_argument("--headless")

            # chrome_options.add_argument(
            #     "--user-data-dir=C:/Users/COG22K/AppData/Local/Google/Chrome/User Data/Default")
            self.driver = webdriver.Chrome(options=chrome_options)
        elif browser_type == 'edge':
            edge_options = EdgeOptions()
            edge_options.add_argument("--start-maximized")
            edge_options.add_argument("window-size=1200,1100")
            if headless:
                edge_options.add_argument("--headless")  # Run Edge in headless mode
            # edge_options.add_argument(
            #     r"--user-data-dir=C:\Users\SRJSNGFST\AppData\Local\Microsoft\Edge\User Data\Default")
            # Instantiate the Edge driver
            self.driver = webdriver.Edge(options=edge_options)

    def crawl(self, action_object_data, inter_file, headless=False):
        if headless:
            driver_type = 'headless'
        else:
            driver_type = 'head'
        result_path_detections = create_folder('./Results/detections')
        print("result_path_detections: ", result_path_detections)
        # # Navigate to the URL
        # self.driver.get(self.url)
        # time.sleep(10)
        current_url = self.url
        next_url = self.url
        # time.sleep(50)
        # Wait for the page to fully load
        self.driver.execute_script("return document.readyState == 'complete';")
        ##
        html = etree.HTML(self.driver.page_source)
        ##
        # Parse the HTML content of the page using BeautifulSoup
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')

        # Loop through the action, object and test data
        for i, row in action_object_data.iterrows():
            time.sleep(5)
            if i == 0:
                print('-')
                # you can check the URL update and keep fetching the new objects
                # ------------------------ This block is used to capture the functional blocks ------------------------
                # results_path = './Results'
                # if not os.path.exists(results_path):
                #     os.mkdir(results_path)
                # result_path_detections = create_folder('./Results/detections')
                # print(result_path_detections)
                # results = FunctionalBlockDetection.detect_functional_blocks(FunctionalBlockDetection, self.driver,
                #                                                             result_path_detections, driver_type)
                # # Step 4. Modify the results to a portable format ----------------------
                # modified_results = convert_to_prompt_dict(results[0])
                # with open(result_path_detections + '/Element_Blocks_data.json', 'w') as fp:
                #     json.dump(modified_results, fp, indent=4)
                # ------------------------ End of first block
                # fun_obj = FunctionalBlockDetection()
                # obj = ResultsTestcases()
                # results = fun_obj.detect_functional_blocks(self.driver, result_path_detections)
                # modified_results = obj.convert_to_prompt(results[0])
                # az_con = AzureConnect()
                # resp = az_con.azure_connect(modified_results)
                # self.store_data('InitClass.py', resp)
                # ------------------------ End of Function block ------------------------
            elif current_url != self.driver.current_url:
                # ------------------------ This block is used to capture the functional blocks ------------------------
                print('-')
                # results_path = './Results'
                # if not os.path.exists(results_path):
                #     os.mkdir(results_path)
                # result_path_detections = create_folder('./Results/detections')
                # print(result_path_detections)
                # results = FunctionalBlockDetection.detect_functional_blocks(FunctionalBlockDetection, self.driver,
                #                                                             result_path_detections, driver_type)
                # # Modify the results to a portable format ----------------------
                # modified_results = convert_to_prompt_dict(results[0])
                # with open(result_path_detections + '/Element_Blocks_data.json', 'w') as fp:
                #     json.dump(modified_results, fp, indent=4)
                # ------------------------ End of first block
                # fun_obj = FunctionalBlockDetection()
                # obj = ResultsTestcases()
                # results = fun_obj.detect_functional_blocks(self.driver, result_path_detections)
                # modified_results = obj.convert_to_prompt(results[0])
                # az_con = AzureConnect()
                # resp2 = az_con.azure_connect(modified_results)
                # self.store_data("class" + str(i) + ".py", resp2)
                # ------------------------ End of Function block ------------------------
            page = row['page']
            action = row['Action']
            obj = row['Object']
            test_data = row['Data']
            wait_time = 10
            print(f"Action:{action}, Object:{obj}, Data:{test_data}")
            wait = WebDriverWait(self.driver, wait_time)
            # time.sleep(9)
            if str(action).startswith('Navigate') or str(action).startswith('Launch'):
                # Navigate to the URL
                if validators.url(test_data):
                    self.driver.get(test_data)
                    current_url = test_data
                    next_url = test_data
                    page = self.extract_page_name(test_data)
                    self.record_page_object_details(page, 'Navigate', obj, test_data, self.driver, '', '', inter_file, '',
                                                '')
            elif action == 'Click' or action == 'Uncheck':
                if str(obj).endswith('button'):
                    obj = str(obj).replace('button', '').strip()
                    # removed button for now at ending, in future need to address this
                get_live_obj = XpathBuilder.create_xpath_from_link_text(XpathBuilder, soup, obj, self.driver, obj)
                final_xpath = ''
                # print('current_url: ', current_url)
                # print('next_url: ', next_url)
                # if below magic is no more working, then use the final shastra
                try:
                    if str(current_url) == str(next_url):
                        get_last_xpath = self.record_page_get_last_xpath(inter_file)
                        ele_last_xp = wait.until(EC.visibility_of_element_located((By.XPATH, get_last_xpath)))
                        if ele_last_xp.location['x'] == 0 and ele_last_xp.location['y'] == 0:
                            ele_last_xp = ele_last_xp.find_element(By.XPATH, '..')
                            print('Retracted to one step back to parent node')
                        self.driver.execute_script("arguments[0].style.border='3px solid red'", ele_last_xp)
                        min_dist = 0
                        for xp_nr in get_live_obj:
                            xp_nr = str(xp_nr).rpartition("/")[0]
                            ele_xp_nr = wait.until(EC.visibility_of_element_located((By.XPATH, xp_nr)))
                            dist = XpathBuilder.calculate_distance(XpathBuilder, ele_last_xp, ele_xp_nr)
                            # print('dist: ', dist)
                            if min_dist == 0:
                                final_xpath = xp_nr
                                min_dist = dist
                            elif min_dist > dist:
                                final_xpath = xp_nr
                                min_dist = dist
                    else:
                        final_xpath = str(get_live_obj[0]).rpartition("/")[0]
                except Exception as e:
                    final_xpath = str(get_live_obj[0]).rpartition("/")[0]
                print("Web Element: ", obj)
                # print('xpath: ', str(get_live_obj))
                print("Xpath: ", final_xpath)
                # self.driver.find_element(By.XPATH, final_xpath).click()
                check_for_visible_element = wait.until(EC.visibility_of_element_located((By.XPATH, final_xpath)))
                page = self.extract_page_name(self.driver.current_url)
                self.record_page_object_details(page, action, obj, test_data, self.driver, check_for_visible_element,
                                                final_xpath, inter_file, '', '')
                # check_for_visible_element.click()
                current_url = self.driver.current_url
                self.driver.execute_script("arguments[0].click();", check_for_visible_element)
                next_url = self.driver.current_url
            elif action == 'Enter' or action == 'Populate' or action == 'Upload':
                if test_data:
                    if str(obj).startswith('mandatory field') or 'mandatory field' in str(obj):
                        print('process fields')
                        form_df = self.detect_form_elements(self.driver)
                        print(form_df)
                        self.crawl(form_df, inter_file)
                        # process here list of action, object and test data
                    else:
                        try:
                            check_for_visible_element = self.driver.find_element(By.CSS_SELECTOR,
                                                                                 f"[placeholder='{obj}']")
                            page = self.extract_page_name(self.driver.current_url)
                            self.record_page_object_details(page, action, obj, test_data, self.driver,
                                                            check_for_visible_element,
                                                            f"//*[contains(@placeholder, '{obj}')]", inter_file, '', '')
                            check_for_visible_element.send_keys(str(test_data))

                        except :
                            xp, get_nearest_input = XpathBuilder.get_nearest_input(XpathBuilder, soup, obj, self.driver,
                                                                                   action)
                            if get_nearest_input == "element is disabled":
                                print("Bypass: element is disabled")
                            else:
                                print('check if input is enabled: ',get_nearest_input.is_enabled())
                                if get_nearest_input.is_enabled():
                                    # raise ValueError(f"No test data provided for row {i + 1}.")
                                    page = self.extract_page_name(self.driver.current_url)
                                    self.record_page_object_details(page, action, obj, test_data, self.driver,
                                                                    get_nearest_input, xp, inter_file, '', '')
                                    get_nearest_input.clear()
                                    get_nearest_input.send_keys(str(test_data))
            elif action == 'assert_text' or action == 'Validate' or action == 'Verify':
                condition = row['Condition']
                # add the xpath builder code
                # get_live_td = XpathBuilder.create_xpath_from_link_text(XpathBuilder, soup, test_data,
                #                                                        self.driver, obj)
                # final_xpath_of_td = str(get_live_td[0]).rpartition("/")[0]
                # check_for_visible_td_element = self.driver.find_element(By.XPATH, final_xpath_of_td)
                # page = self.extract_page_name(self.driver.current_url)
                # self.record_page_object_details(page, action, obj, test_data, self.driver,
                #                                 check_for_visible_td_element,
                #                                 final_xpath_of_td, inter_file, '', '')
                if condition:
                    # condition is present in extracted data, process likewise
                    if condition == 'is displayed' or condition == 'is not displayed':
                        # add the code for validation on either object or page
                        # check for condition value
                        condition_value = row['Condition_Value']
                        if condition_value:
                            # both condition and condition value present, store details
                            page = self.extract_page_name(self.driver.current_url)
                            self.record_page_object_details(page, action, obj, test_data, self.driver,
                                                            '', '', inter_file, condition,
                                                            condition_value)

                            # validate current date in datepicker box
                            if condition_value == 'current date':
                                current_date = datetime.date.today().strftime('%mm/%dd/%yyyy')
                                datepicker_value = check_for_visible_td_element.get_attribute('value')
                                if datepicker_value == current_date:
                                    print("Current date or  is displayed in the datepicker box.")
                                else:
                                    print("Current date is not displayed in the datepicker box.")

                            # verify disabled dates in datepicker dropdown menu
                            if condition_value == 'disabled dates':
                                dropdown = self.driver.find_element(By.XPATH, 'xpath_of_datepicker_dropdown')
                                dropdown.click()
                                date_elements = dropdown.find_elements(By.XPATH, 'xpath_of_date_elements')
                                disabled_dates = []
                                for date_element in date_elements:
                                    if not date_element.is_enabled():
                                        disabled_dates.append(date_element.text)
                                if len(disabled_dates) > 0:
                                    print("Disabled dates in the datepicker dropdown menu:", disabled_dates)
                                else:
                                    print(
                                        "All other dates except today's date are disabled in the datepicker dropdown menu.")
                else:
                    # condition is not present, so most likely it's in object, detect and extract and process
                    if 'displayed' in str(obj):
                        # the condition is in object, process
                        condition = ''
                        if str(obj).endswith('is displayed'):
                            condition = 'is displayed'
                        elif str(obj).endswith('is not displayed'):
                            condition = 'is not displayed'
                        condition_value = 'page/header'
                        page = self.extract_page_name(self.driver.current_url)
                        self.record_page_object_details(page, action, obj, test_data, self.driver,
                                                        '', '', inter_file, condition,
                                                        condition_value)
            elif action == 'Select':
                if test_data and str(test_data) != 'nan':
                    # print(h'Test Data Entry: ', test_data)
                    get_live_td = XpathBuilder.create_xpath_from_link_text(XpathBuilder, soup, test_data,
                                                                           self.driver, obj)
                    final_xpath_of_td = str(get_live_td[0]).rpartition("/")[0]
                    check_for_visible_td_element = self.driver.find_element(By.XPATH, final_xpath_of_td)
                    page = self.extract_page_name(self.driver.current_url)
                    self.record_page_object_details(page, action, obj, test_data, self.driver,
                                                    check_for_visible_td_element,
                                                    final_xpath_of_td, inter_file, '', '')
                    check_for_visible_td_element.click()
                    # added to resolve overlay issue due to which objects gets un-clickable
                    # self.driver.execute_script("arguments[0].click();", check_for_visible_td_element)
                else:
                    get_live_obj = XpathBuilder.create_xpath_from_link_text(XpathBuilder, soup, obj, self.driver, obj)
                    if get_live_obj:
                        final_xpath = str(get_live_obj[0]).rpartition("/")[0]
                        final_xpath = str(final_xpath) + "[text()=\"" + obj + "\"]"
                        check_for_visible_element = self.driver.find_element(By.XPATH, final_xpath)
                        page = self.extract_page_name(self.driver.current_url)
                        self.record_page_object_details(page, action, obj, test_data, self.driver,
                                                        check_for_visible_element,
                                                        final_xpath, inter_file, '', '')
                        check_for_visible_element.click()
                    else:
                        pass
            else:
                print(f"Non executable step action '{action}' for row {i}.")

    def stop(self):
        # Close the browser
        self.driver.quit()
        self.driver = None

    def record_page_object_details(self, page, action, obj, test_data, driver, check_for_visible_element, xpath,
                                   file_name, condition, condition_value):
        get_url = driver.current_url
        rows = []
        cols = []
        cols.append('url')
        cols.append('page')
        cols.append('action')
        cols.append('object')
        cols.append('data')
        rows.append(get_url)
        rows.append(page)
        rows.append(action)
        rows.append(obj)
        rows.append(test_data)
        # for attrib in check_for_visible_element.get_property('attributes'):
        #     cols.append(attrib['name'])
        #     rows.append(attrib['value'])
        #     print(cols, ", ", rows)
        if action == 'Navigate':
            get_all_attrib_dict = ''
            cols.append('TagName')
            rows.append('')
            cols.append('ID')
            rows.append('')
            cols.append('Class')
            rows.append('')
            cols.append('All_Attributes')
            rows.append(get_all_attrib_dict)
            cols.append('Xpath')
            rows.append(xpath)
            cols.append('Condition')
            rows.append('')
            cols.append('Condition_Value')
            rows.append('')
        elif action == 'Validate' or action == 'Verify':
            get_all_attrib_dict = ''
            cols.append('TagName')
            rows.append('')
            cols.append('ID')
            rows.append('')
            cols.append('Class')
            rows.append('')
            cols.append('All_Attributes')
            rows.append(get_all_attrib_dict)
            cols.append('Xpath')
            rows.append('')
            cols.append('Condition')
            rows.append(condition)
            cols.append('Condition_Value')
            rows.append(condition_value)
        else:
            get_all_attrib_dict = self.driver.execute_script(
                'var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) '
                '{ items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;',
                check_for_visible_element)
            cols.append('TagName')
            rows.append(check_for_visible_element.get_attribute('tagName'))
            cols.append('ID')
            rows.append(check_for_visible_element.get_attribute('id'))
            cols.append('Class')
            rows.append(check_for_visible_element.get_attribute('class'))
            cols.append('All_Attributes')
            rows.append(get_all_attrib_dict)
            cols.append('Xpath')
            rows.append(xpath)
            cols.append('Condition')
            rows.append('')
            cols.append('Condition_Value')
            rows.append('')
        df = pd.DataFrame(columns=cols)
        df.loc[len(df)] = rows
        filename = file_name
        df.to_csv(filename, mode='a', header=not os.path.isfile(filename), index=False)
        return True

    def detect_form_elements(self, driver):
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        form = soup.find('form')
        if form:
            # Initialize a list to store form elements
            form_elements = []
            actions = []
            # Find visible labels within the form
            labels = form.find_all('label')

            for label in labels:
                label_text = label.text.strip()
                associated_input = label.find_next('input')
                if label.find_next('select') is None:
                    input_type = associated_input.get('type')
                    if input_type == 'radio':
                        action = 'Select'
                    else:
                        action = 'Enter'
                else:
                    select_index = label.find_all_next().index(label.find_next('select'))
                    input_index = label.find_all_next().index(label.find_next('input'))
                    if int(select_index) < int(input_index):
                        input_type = 'select'
                        associated_input = label.find_next('select')
                        action = 'Select'
                    else:
                        input_type = associated_input.get('type')
                        action = 'Enter'
                # print(f"label_text: {label_text}, ...........associated_input: {associated_input}")
                associated_input_web = []
                if associated_input.get('id'):
                    associated_input_web = self.driver.find_element(By.ID, associated_input.get('id'))
                else:
                    associated_input_web = self.driver.find_element(By.XPATH, self.xpath_soup(associated_input))
                if label_text and label_text != 'Male' and label_text != 'Female' and associated_input and associated_input_web.is_displayed():
                    # Store the label and associated input type in the list
                    form_elements.append((label_text.split('\n')[0], input_type, action))
                elif label_text and label_text == 'Gender':
                    form_elements.append((label_text.split('\n')[0], input_type, action))

            # Create a DataFrame from the form elements list
            df = pd.DataFrame(form_elements, columns=["Label", "InputType", "Action"])

            # Print the DataFrame
            read_datasheet = r"C:\Users\COGUD4\Desktop\CNO_ScriptGen\CNO_ScriptGen\DataSheet.xlsx"
            datasheet = pd.read_excel(read_datasheet)
            values = []

            for label in df['Label']:
                if label in datasheet.columns:
                    value = datasheet[label].iloc[0]
                    values.append(value)
                else:
                    values.append('NoTestDataProvided')
            # label_to_value = {label: datasheet[label] for label in df['Label'] if label in datasheet.columns}
            # df['value']= df['Label'].map(label_to_value)
            df['value'] = values
            # map this data with detected form elements and assign the data in above
            print(df)
            df.rename(columns={'Label': 'Object', 'value': 'Data'}, inplace=True)
            df['page'] = 'formPage'
            print('updated field list:')
            df = df[df.Data != 'NoTestDataProvided']
            print(df)
            return df
        else:
            print("No form found on the page.")
            return "No form found on the page."

    def extract_page_name(self, url):
        parsed_url = urlparse(url)
        if parsed_url.path:
            page_name = re.sub(r'\W+', '_', parsed_url.path.split('/')[-1])
            if page_name:
                return page_name
            else:
                return "landing_page"
        return "landing_page"

    def record_page_get_last_xpath(self, inter_file):
        xpath = pd.read_csv(inter_file).iloc[-1]['Xpath']
        if xpath:
            return xpath
        else:
            return pd.read_csv(inter_file).iloc[-2]['Xpath']

    def xpath_soup(self, element):
        components = []
        child = element if element.name else element.parent
        for parent in child.parents:
            siblings = parent.find_all(child.name, recursive=False)
            components.append(
                child.name
                if siblings == [child] else
                '%s[%d]' % (child.name, 1 + siblings.index(child))
            )
            child = parent
        components.reverse()
        return '/%s' % '/'.join(components)
