import os
import re
import pandas as pd
from langchain import LLMChain
import json
from pathlib import Path
from typing import Callable, Dict, List, Optional, Union
from langchain.docstore.document import Document
from langchain.document_loaders.base import BaseLoader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.document_loaders import JSONLoader
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.document_loaders import DataFrameLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from langchain.document_loaders import PyPDFLoader
from langchain.document_loaders import DirectoryLoader
import chromadb
from langchain.vectorstores import Chroma

from langchain.document_loaders.csv_loader import CSVLoader

def extract_java_data(java_file_path):
    # Read the Java file
    with open(java_file_path, 'r', encoding='utf-8') as file:
        java_code = file.read()

    # Extract package name, class name, and method names using regular expressions
    package_name = re.search(r'package\s+(.*?);', java_code)
    class_name = re.search(r'public\s+class\s+(\w+)', java_code)
    class_name_ab = re.search(r'public abstract\s+class\s+(\w+)', java_code)
    method_names = re.findall(r'public\s+\w+?\s+(\w+?)\(', java_code)
    if java_file_path.endswith("TestConfigurations.java"):
        print('log')
    # Return None if any of the required data is missing
    if not (package_name and (class_name or class_name_ab) and method_names):
        if not method_names and (class_name or class_name_ab):
            method_names = re.findall(r'public\s+Object\[\]\[\]\s+(\w+)\s*\(.*\)\s*{', java_code)
        else:
            return None

    package_name = package_name.group(1)
    if class_name is not None:
        class_name = class_name.group(1)
    else:
        class_name = class_name_ab.group(1)
    return package_name, class_name, method_names


def scan_java_files(base_dir):
    data = {'package_name': [], 'class_name': [], 'method_name': []}

    for root, _, files in os.walk(base_dir):
        for file in files:
            if file.endswith(".java"):
                file_path = os.path.join(root, file)
                print(file_path)
                # Extract Java data from the file
                java_data = extract_java_data(file_path)

                if java_data:
                    package_name, class_name, method_names = java_data
                    if package_name.startswith("com.cognizant") and method_names:
                        data['package_name'].append(package_name)
                        data['class_name'].append(class_name)
                        data['method_name'].append(', '.join(method_names))

    # Create DataFrame from the dictionary
    df = pd.DataFrame(data)
    return df


if __name__ == "__main__":
    # persist_directory = "./embed_data"
    # client = chromadb.PersistentClient(path=persist_directory)
    # base_directory = "C:/Users/SRJSNGFST/Downloads/CRAFT/Cognizant-Reusable-Automation-Framework-for-Testing-master/keywordDriven-maven-testng-framework"  # Replace with the base directory of your Java code
    # result_df = scan_java_files(base_directory)
    # pd.set_option("display.max_rows", None)
    # pd.set_option("display.max_columns", None)
    # pd.set_option("display.width", None)
    # df = pd.DataFrame(result_df)
    # result_df.to_csv("java_code_analysis.csv", index=False)  # Save the result to a CSV file
    # print(df)

    # embeddings = OpenAIEmbeddings()

    loader = CSVLoader(file_path="java_code_analysis.csv")
    documents = loader.load()
    # load the data in documents to store in chromadb
    # documents = df.to_dict(orient="records")
    # Convert DataFrame to JSON
    # df_loader = DataFrameLoader(data_frame=df)
    # documents = df_loader.load()
    embeddings = HuggingFaceEmbeddings()
    # load it into Chroma
    db = Chroma.from_documents(documents, embeddings, persist_directory=persist_directory)
    db.persist()
