from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from langchain.document_loaders import PyPDFLoader
from langchain.document_loaders import DirectoryLoader

from langchain.document_loaders.csv_loader import CSVLoader
from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain.embeddings import HuggingFaceEmbeddings, SentenceTransformerEmbeddings
from langchain.vectorstores import Qdrant
from langchain.vectorstores import FAISS

import pandas as pd

persist_directory = "./embed_data"
loader = CSVLoader(file_path="java_code_analysis.csv")
documents = loader.load()
# print(documents)

embeddings = HuggingFaceEmbeddings()
# load it into Chroma
# db = Chroma.from_documents(documents=documents, embeddings=embeddings, persist_directory=persist_directory)
# db.persist()

# load it into FAISS
db = FAISS.from_documents(documents, embeddings)

query = "Get all methods of Script Helper class"
docs = db.similarity_search(query)
print(docs[0].page_content)

