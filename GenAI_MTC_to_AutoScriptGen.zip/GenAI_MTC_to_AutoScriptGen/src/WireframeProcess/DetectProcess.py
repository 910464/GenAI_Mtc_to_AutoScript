# Opening Headless Edge using Selenium Webdriver
import os
from screeninfo import get_monitors

from selenium.webdriver.common.by import By

from src.Utils.CoordinatesTranslationUtils import get_web_elements_coordinates, get_closest_match_element, \
    find_closest_matching_blocks
from src.Utils.ImageProcessingUtils import split_screenshot, take_headful_screenshots
from src.Utils.SavingOutputUtils import create_folder
from src.Utils.SavingOutputUtils import highlight_and_screenshot, save_list_in_txt
from src.Utils.YoloUtils import get_predicted_results, get_refined_coordinates

'''
# Set Edge options to enable full page screenshot
edge_options = Options()
edge_options.add_argument("--headless")  # Run Chrome in headless mode (optional)

# Instantiate the Edge driver
driver = webdriver.Edge(options=edge_options)

'''


class DetectProcess:

    def __init__(self):
        self.f = ''

    def detect_elements(self, driver, results_path='./Results/', model=None, conf=None, detection_type=None,
                        driver_type=None):
        # Setting the path
        detection_path = create_folder(results_path + f'{detection_type}_detections')

        # Saving the Screenshot
        screenshots_path = detection_path + "/Screenshots"
        screenshot_path = screenshots_path + '/screenshot.png'
        os.mkdir(screenshots_path)

        # Save the splits
        screenshot_splits_path = screenshots_path + '/ScreenshotSplits'
        os.mkdir(screenshot_splits_path)

        if driver_type == 'Headless':
            # Adjusting the Window Size
            width = 1280
            height = 512
            driver.set_window_size(width, height)  # Adjust the width and height as needed

            total_height = driver.execute_script("return document.documentElement.scrollHeight")
            driver.set_window_size(width, total_height)  # Setting height of the window to total Scrollable Height

            driver.save_screenshot(screenshot_path)

            # Splitting the screenshot
            x = height  # Replace with your desired value
            screenshot_splits = split_screenshot(screenshot_path, x)

            for i, image in enumerate(screenshot_splits):
                image.save(f"{screenshot_splits_path}/screenshot_splits_{i}.png")

        else:
            driver.maximize_window()
            x = driver.execute_script("return window.innerHeight")
            width = driver.execute_script("return window.innerWidth")
            screenshot_splits = take_headful_screenshots(driver, screenshot_splits_path, x, width)

        # Get the predicted_results from Screenshot
        predicted_results, class_names = get_predicted_results(screenshot_splits, x, screenshot_splits_path, model,
                                                               conf)
        refined_predicted_coordinates = get_refined_coordinates(predicted_results)

        # print('Refined : ', refined_predicted_coordinates)
        # Finding the coordinates of the Web Elements
        elements = driver.find_elements(By.CSS_SELECTOR, '*')
        element_bounding_boxes = get_web_elements_coordinates(elements)

        # Finding the closest match elements from the predicted results
        if detection_type == 'block':
            closest_match_elements = get_closest_match_element(refined_predicted_coordinates, element_bounding_boxes)
            # closest_match_elements = find_closest_matching_blocks(refined_predicted_coordinates, element_bounding_boxes)
        else:
            closest_match_elements = get_closest_match_element(refined_predicted_coordinates, element_bounding_boxes)

        save_list_in_txt(detection_path, closest_match_elements)

        # Highlighting and taking screenshots from the driver
        highlight_and_screenshot(closest_match_elements, driver, class_names, detection_path, driver_type)

        # Logging the first in detected elements
        try:
            print('Closest Match Element [0] : ')
            print(closest_match_elements[0])
        except:
            pass

        return [[i[5], i[-3], i[-1]] for i in closest_match_elements]