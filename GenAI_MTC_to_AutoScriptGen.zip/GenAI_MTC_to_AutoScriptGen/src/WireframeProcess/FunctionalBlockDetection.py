import json
import time
import os
from ultralytics import YOLO
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

from src.Utils.SavingOutputUtils import save_dict_to_json, save_list_to_file
from src.WireframeProcess.DetectProcess import DetectProcess


class FunctionalBlockDetection:

    def __init__(self):
        # Defining the paths to the models
        project_dir = os.getcwd()
        self.element_detection_model_path = os.path.join(project_dir, 'PretrainedModels',
                                                         'web_detection_yolov8_e50s500Aug.pt')
        self.block_detection_model_path = os.path.join(project_dir, 'PretrainedModels',
                                                       'web_detection_yolov8_e100s500Aug2.pt')
        # self.element_detection_model_path = './PretrainedModels/web_detection_yolov8_e50s500.pt'
        # self.block_detection_model_path = './PretrainedModels/FuncBlock_detection_Yv8_e100s500Aug.pt'
        # Getting the models and setting the confidence
        self.element_detection_model = YOLO(self.element_detection_model_path)  # Getting the YOLO Object
        self.confidence_element = 0.1  # Setting Confidence Threshold
        self.block_detection_model = YOLO(self.block_detection_model_path)
        self.confidence_block = 0.3

    def is_box_inside(self, box1, box2):
        xmin1, ymin1, xmax1, ymax1 = box1
        xmin2, ymin2, xmax2, ymax2 = box2

        if xmin2 <= xmin1 and ymin2 <= ymin1 and xmax2 >= xmax1 and ymax2 >= ymax1:
            return True

    def get_elements_inside_blocks(self, blocks, elements):
        block_dict = {}
        free_elements = []
        for block in blocks:
            block_children = []
            for element in elements:
                if self.is_box_inside(element[-1], block[-1]):
                    block_children.append(element)
                else:
                    free_elements.append(element)
            block_dict[str(block[1])] = {'type': block[0], 'coor': block[-1], 'children': block_children}

        return block_dict, free_elements

    def detect_functional_blocks(self, driver, save_path, driver_type=None):
        check_in = FunctionalBlockDetection()
        blocks = DetectProcess.detect_elements(DetectProcess, driver, save_path, check_in.block_detection_model,
                                               check_in.confidence_block, 'block', driver_type)
        elements = DetectProcess.detect_elements(DetectProcess, driver, save_path, check_in.element_detection_model,
                                                 check_in.confidence_element, 'element',
                                                 driver_type)

        result = check_in.get_elements_inside_blocks(blocks, elements)

        print('/n-------------- Final Results --------------')
        print('/n ---------- Blocks ------ ')
        print(result[0])
        print('/n ---- Free elements --- ')
        print(result[1])

        return result

################### ##########################
# edge_options = Options()
# edge_options.add_argument("--headless")  # Run Edge in headless mode

# Instantiate the Edge driver
# driver = webdriver.Edge(options=edge_options)

# chrome_options = Options()
# chrome_options.add_argument("--start-maximized")
# chrome_options.add_argument("--user-data-dir=C:/Users/SRJSNGFST/AppData/Local/Google/Chrome/User Data/Default")
# driver = webdriver.Chrome(options=chrome_options)


# website_url = 'https://www.incometax.gov.in/iec/foportal/'  # # Replace with the starting URL website_url =   # 'https://www.incometax.gov.in/iec/foportal/''https://facebook.com/' #  #  # Replace with the starting URL
# website_url = 'https://qualityinsights.cognizant.com/qualityinsightbots/#/'
# driver.get(website_url)
# time.sleep(10)


# Main Function
# detect_functional_blocks(driver)
