import json
import time
from src.WireframeProcess.FunctionalBlockDetection import FunctionalBlockDetection
from selenium import webdriver
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.chrome.options import Options as ChromeOptions


# # Setting Up Driver
# edge_options = Options()
# edge_options.add_argument("--headless")  # Run Edge in headless mode
#
# # Instantiate the Edge driver
# driver = webdriver.Edge(options=edge_options)

class ResultsTestcases:
    def __init__(self):
        self.x = 'driver subject to change from this location'
        # # Setting Up Edge Driver
        # self.edge_options = EdgeOptions()
        # self.edge_options.add_argument("--headless")  # Run Edge in headless mode

        # Instantiate the Edge driver
        # self.edge_driver = webdriver.Edge(options=self.edge_options)

        # # Setting Up Chrome Driver
        # self.chrome_options = ChromeOptions()
        # self.chrome_options.add_argument("--headless")
        # # self.chrome_options.add_argument("--start-maximized")
        # self.chrome_options.add_argument(
        #     "--user-data-dir=C:/Users/SRJSNGFST/AppData/Local/Google/Chrome/User Data/Default")
        # self.chrome_driver = webdriver.Chrome(options=self.chrome_options)

    def convert_to_prompt(self, results):
        for block in results:
            results[block]['children'] = sorted(results[block]['children'], key=lambda x: x[0])
            for i in range(len(results[block]['children'])):
                d = {}
                try:
                    d['id'] = results[block]['children'][i][1].get_attribute("id")
                except:
                    pass
                try:
                    d['type'] = results[block]['children'][i][1].get_attribute("type")
                except:
                    pass
                try:
                    d['class'] = results[block]['children'][i][1].get_attribute("class")
                except:
                    pass
                try:
                    d['tagName'] = results[block]['children'][i][1].get_attribute("tagName")
                except:
                    pass
                results[block]['children'][i][1] = d
        return results


# obj = ResultsTestcases()
# # website_url = 'https://amazon.com/' #'https://www.facebook.com/login/'  # 'https://www.incometax.gov.in/iec/foportal/'  # # Replace with the starting URL website_url =   # 'https://www.incometax.gov.in/iec/foportal/''https://facebook.com/' #  #  # Replace with the starting URL
# website_url = 'https://qualityinsights.cognizant.com/qualityinsightbots/#/'
# obj.chrome_driver.get(website_url)
# time.sleep(30)
#
# # Get Result
# fun_obj = FunctionalBlockDetection()
# results = fun_obj.detect_functional_blocks(obj.chrome_driver)
# modified_results = obj.convert_to_prompt(results[0])
# print(modified_results)
# from src.WireframeProcess.AzureConnect import AzureConnect
# az_con = AzureConnect()
# resp = az_con.azure_connect(modified_results)
# with open('Element_Blocks_data.json', 'w') as fp:
#     json.dump(modified_results, fp, indent=4)
